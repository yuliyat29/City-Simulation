<template>
  <main class="app">
    <div class="topbar-wrapper">
      <topbar />
    </div>

    <div class="content">
      <div class="sidebar-wrapper">
        <sidebar />
      </div>

      <router-view />
    </div>
  </main>
</template>

<script>
import Sidebar from "@/partials/Sidebar.vue";
import Topbar from "@/partials/Topbar.vue";
import "@fortawesome/fontawesome-free/css/all.css";

export default {
  name: "App",
  components: {
    Sidebar,
    Topbar,
  },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-decoration: none;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.app {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  position: relative;
}

.content {
  background-color: #f4f4f4;
  height: 100%;
  display: flex;
}

.sidebar-wrapper {
  width: 114px;
  height: 100%;
  color: white;
  background-color: transparent;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  position: fixed;
  top: 112px;
  z-index: 998;
}

.topbar-wrapper {
  position: fixed;
  width: 100%;
  height: 110px;
  z-index: 998;
}

</style>
<script setup></script>
