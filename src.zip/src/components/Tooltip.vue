<template>
  <div class="wrapper" :style="{ top: mouse.mouseY, left: mouse.mouseX }">
    <div class="top">
      <p>
        <i v-if="oldBlock.type === 'RESIDENTIALBLOCK' && oldBlock.type !== block.type" class="fas fa-house"></i>
        <i v-if="oldBlock.type === 'WATERBLOCK' && oldBlock.type !== block.type" class="fas fa-water"></i>
        <i v-if="oldBlock.type === 'PARKBLOCK' && oldBlock.type !== block.type" class="fas fa-tree"></i>
        {{ oldBlock.type !== block.type ? getOldBlockTypeName : null }}
        <strong v-if="oldBlock && oldBlock.type !== block.type"> / </strong>
        <i v-if="block.type === 'RESIDENTIALBLOCK'" class="fas fa-house"></i>
        <i v-if="block.type === 'WATERBLOCK'" class="fas fa-water"></i>
        <i v-if="block.type === 'PARKBLOCK'" class="fas fa-tree"></i>
        {{ getBlockTypeName }}
      </p>

      <div class="coordinates">
        <p>X: {{ block.x }}</p>
        <p>Y: {{ block.y }}</p>
      </div>
    </div>
    <div class="bottom">
      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">Number of People:</p>
        <p>
          <strong v-if="oldBlock.numberOfPeople && oldBlock.numberOfPeople != block.numberOfPeople">{{
            formatNumber(oldBlock.numberOfPeople)
          }}</strong>
          <strong v-if="oldBlock.numberOfPeople && oldBlock.numberOfPeople != block.numberOfPeople"> / </strong>
          <strong
            :class="
              oldBlock.numberOfPeople > block.numberOfPeople || (!block.numberOfPeople && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.numberOfPeople < block.numberOfPeople
                ? 'inc'
                : null
            "
            >{{ !block.numberOfPeople && oldBlock.type === 'RESIDENTIALBLOCK' ? 0 : block.numberOfPeople ? formatNumber(block.numberOfPeople) : null }} 
              {{ (oldBlock.numberOfPeople && oldBlock.numberOfPeople != block.numberOfPeople && block.numberOfPeople) ? `(${formatNumber(block.numberOfPeople - oldBlock.numberOfPeople)})` : null }} 
          </strong
          >
        </p>
      </div>

      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">
          Building Height (Floors):
        </p>
        <p>
          <strong v-if="oldBlock.height && oldBlock.height != block.height">{{ formatNumber(oldBlock.height) }}</strong>
          <strong v-if="oldBlock.height && oldBlock.height != block.height"> / </strong>
          <strong
            :class="
              oldBlock.height > block.height || (!block.height && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.height < block.height
                ? 'inc'
                : null
            "
            >{{ !block.height && oldBlock.type === "RESIDENTIALBLOCK" ? 0 : block.height ? formatNumber(block.height) : null }}
            {{ (oldBlock.height && oldBlock.height != block.height && block.height) ? `(${formatNumber(block.height - oldBlock.height)})` : null }} 
          </strong
          >
        </p>
      </div>

      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">
          Cost of Rent (CHF/m²):
        </p>
        <p>
          <strong v-if="oldBlock.costOfRent && oldBlock.costOfRent != block.costOfRent">{{
            formatNumber(oldBlock.costOfRent?.toFixed(2))
          }}</strong>
          <strong v-if="oldBlock.costOfRent && oldBlock.costOfRent != block.costOfRent"> / </strong>
          <strong
            :class="
              oldBlock.costOfRent > block.costOfRent || (!block.costOfRent && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.costOfRent < block.costOfRent
                ? 'inc'
                : null
            "
            >{{ !block.costOfRent && oldBlock.type === 'RESIDENTIALBLOCK' ? 0 : block.costOfRent ? formatNumber(block.costOfRent?.toFixed(2) ): null }}
            {{ (oldBlock.costOfRent && oldBlock.costOfRent != block.costOfRent && block.costOfRent) ? `(${formatNumber((block.costOfRent - oldBlock.costOfRent)?.toFixed(2))})` : null }} 
          </strong>
        </p>
      </div>

      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">
          Land Price (CHF):
        </p>
        <p>
          <strong v-if="oldBlock.costOfLand && oldBlock.costOfLand != block.costOfLand">{{
            formatNumber(oldBlock.costOfLand?.toFixed(2))
          }}</strong>
          <strong v-if="oldBlock.costOfLand && oldBlock.costOfLand != block.costOfLand"> / </strong>
          <strong
            :class="
              oldBlock.costOfLand > block.costOfLand || (!block.costOfLand && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.costOfLand < block.costOfLand
                ? 'inc'
                : null
            "
            >{{ !block.costOfLand && oldBlock.type === 'RESIDENTIALBLOCK' ? 0 : block.costOfLand ? formatNumber(block.costOfLand?.toFixed(2) ): null }}
            {{ (oldBlock.costOfLand && oldBlock.costOfLand != block.costOfLand && block.costOfLand) ? `(${formatNumber((block.costOfLand - oldBlock.costOfLand)?.toFixed(2))})` : null }} 
          </strong>
        </p>
      </div>

      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">
          Construction Cost (CHF):
        </p>
        <p>
          <strong v-if="oldBlock.constructionCost && oldBlock.constructionCost != block.constructionCost">{{
            formatNumber(oldBlock.constructionCost?.toFixed(2))
          }}</strong>
          <strong v-if="oldBlock.constructionCost && oldBlock.constructionCost != block.constructionCost"> / </strong>
          <strong
            :class="
              oldBlock.constructionCost > block.constructionCost || (!block.constructionCost && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.constructionCost < block.constructionCost
                ? 'inc'
                : null
            "
            >{{ !block.constructionCost && oldBlock.type === 'RESIDENTIALBLOCK' ? 0 : block.constructionCost ? formatNumber(block.constructionCost?.toFixed(2)) : null }}
            {{ (oldBlock.constructionCost && oldBlock.constructionCost != block.constructionCost && block.constructionCost) ? `(${formatNumber((block.constructionCost - oldBlock.constructionCost)?.toFixed(2))})` : null }} 
          </strong>
        </p>
      </div>

      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">
          Transportation Cost (CHF):
        </p>
        <p>
          <strong v-if="oldBlock.transportationCost && oldBlock.transportationCost != block.transportationCost">{{
            formatNumber(oldBlock.transportationCost?.toFixed(2))
          }}</strong>
          <strong v-if="oldBlock.transportationCost && oldBlock.transportationCost != block.transportationCost"> / </strong>
          <strong
            :class="
              oldBlock.transportationCost > block.transportationCost || (!block.transportationCost && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.transportationCost < block.transportationCost
                ? 'inc'
                : null
            "
            >{{ !block.transportationCost && oldBlock.type === 'RESIDENTIALBLOCK' ? 0 : block.transportationCost ? formatNumber(block.transportationCost?.toFixed(2)) : null }}
            {{ (oldBlock.transportationCost && oldBlock.transportationCost != block.transportationCost && block.transportationCost) ? `(${formatNumber((block.transportationCost - oldBlock.transportationCost)?.toFixed(2))})` : null }} 
          </strong>
        </p>
      </div>

      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">
          Construction Cost Limit (CHF):
        </p>
        <p>
          <strong v-if="oldBlock.constructionCostLimit && oldBlock.constructionCostLimit != block.constructionCostLimit">{{
            formatNumber(oldBlock.constructionCostLimit?.toFixed(2))
          }}</strong>
          <strong v-if="oldBlock.constructionCostLimit && oldBlock.constructionCostLimit != block.constructionCostLimit"> / </strong>
          <strong
            :class="
              oldBlock.constructionCostLimit > block.constructionCostLimit || (!block.constructionCostLimit && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.constructionCostLimit < block.constructionCostLimit
                ? 'inc'
                : null
            "
            >{{ !block.constructionCostLimit && oldBlock.type === 'RESIDENTIALBLOCK' ? 0 : block.constructionCostLimit ? formatNumber(block.constructionCostLimit?.toFixed(2)) : null }}
            {{ (oldBlock.constructionCostLimit && oldBlock.constructionCostLimit != block.constructionCostLimit && block.constructionCostLimit) ? `(${formatNumber((block.constructionCostLimit - oldBlock.constructionCostLimit)?.toFixed(2))})` : null }} 
          </strong>
        </p>
      </div>

      <div>
        <p v-if="block.type === 'RESIDENTIALBLOCK' || oldBlock.type === 'RESIDENTIALBLOCK'">
          Rent Limit (CHF):
        </p>
        <p>
          <strong v-if="oldBlock.rentLimit && oldBlock.rentLimit != block.rentLimit">{{
            formatNumber(oldBlock.rentLimit?.toFixed(2))
          }}</strong>
          <strong v-if="oldBlock.rentLimit && oldBlock.rentLimit != block.rentLimit"> / </strong>
          <strong
            :class="
              oldBlock.rentLimit > block.rentLimit || (!block.rentLimit && oldBlock.type === 'RESIDENTIALBLOCK')
                ? 'dec'
                : oldBlock.rentLimit < block.rentLimit
                ? 'inc'
                : null
            "
            >{{ !block.rentLimit && oldBlock.type === 'RESIDENTIALBLOCK' ? 0 : block.rentLimit ? formatNumber(block.rentLimit?.toFixed(2)) : null }}
            {{ (oldBlock.rentLimit && oldBlock.rentLimit != block.rentLimit && block.rentLimit) ? `(${formatNumber((block.rentLimit - oldBlock.rentLimit)?.toFixed(2))})` : null }} 
          </strong>
        </p>
      </div>
        
        <div>
        <p>
          Distance From Center (Blocks):
        </p>
        <p>
          <strong>{{ formatNumber(block.distanceFromCenter) }}</strong>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Tooltip",
  props: {
    block: {},
    oldBlock: {},
    isComparisonActive: false,
    mouse: {
      mouseX: "0px",
      mouseY: "0px",
    },
  },
  methods:{
    formatNumber(value) {
      if (value === null || value === undefined) return '';

      // Convert the number to a string and split it into integer and decimal parts
      let [integerPart, decimalPart] = value.toString().split('.');

      // Add the thousands separators to the integer part
      integerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, "'");

      // Concatenate the integer part with the decimal part if it exists
      return decimalPart ? `${integerPart}.${decimalPart}` : integerPart;
    }
  },
  computed: {
    getBlockTypeName() {
      switch (this.block.type) {
        case "RESIDENTIALBLOCK":
          return "Residential";
        case "WATERBLOCK":
          return "Water";
        case "PARKBLOCK":
          return "Park";
        default:
          return "Unknown Block Type";
      }
    },
    getOldBlockTypeName() {
      // if(!this.isComparisonActive) return;
      switch (this.oldBlock.type) {
        case "RESIDENTIALBLOCK":
          return "Residential";
        case "WATERBLOCK":
          return "Water";
        case "PARKBLOCK":
          return "Park";
        default:
          return null;
      }
    },
  },
};
</script>

<style scoped>
.wrapper {
  position: absolute;
  background-color: #292931ce;
  padding: 25px 20px;
  z-index: 1;
  border: 1px solid #292931;
  border-radius: 10px;
  color: rgb(255, 255, 255);
  user-select: none;
  overflow: auto;
}

.top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: nowrap;
  margin-bottom: 10px;
  gap: 30px;
}

.bottom {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  gap: 10px;
  text-align: left;
  margin-top: 25px;
}

.bottom div {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: nowrap;
}

.coordinates {
  display: flex;
  justify-content: end;
  gap: 15px;
  flex-wrap: nowrap;
}

.dec {
  color: #ff0000;
}

.inc {
  color: #00ff00;
}
</style>
