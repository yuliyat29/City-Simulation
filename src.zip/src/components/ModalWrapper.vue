<template>
  <div class="modal-overlay" v-if="visible">
    <div class="modal">
      <div class="modal-header">
        <button @click="closeModal"><i class="fas fa-times fa-xl"></i></button>
      </div>
      <div class="modal-body">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    closeModal() {
      this.$emit('close');
    }
  }
};
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2;
}

.modal {
  background-color: white;
  width: 60%;
  max-width: 600px;
  border-radius: 8px;
  padding: 20px;
  margin-top: 70px;
}

.modal-header {
  display: flex;
  justify-content: end;
  align-items: center;

}

.modal-header h2 {
  margin: 0;
}

.modal-header button {
  background: none;
  border: none;
  cursor: pointer;
}

.modal-body {
  padding: 20px 0;
}

.modal-footer {
  text-align: right;
  padding-top: 20px;
}

.modal-footer button {
  padding: 8px 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>
