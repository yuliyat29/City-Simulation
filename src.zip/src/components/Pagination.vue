<template>
  <div class="pagination">
    <button @click="prevPage" :disabled="currentPage === 1" class="pagination__button">
      <i class="fas fa-chevron-left"></i> </button>

    <ul class="pagination__list">
      <li v-for="page in displayedPages" :key="page" class="pagination__item">
        <button @click="goToPage(page)" class="pagination__button pagination__button--active" :style="page === currentPage ? {background: 'rgb(2, 60, 122)', color: 'white'} : null">
          {{ page }}
        </button>
      </li>
    </ul>

    <button @click="nextPage" :disabled="currentPage === totalPages" class="pagination__button">
      <i class="fas fa-chevron-right"></i> </button>
  </div>
</template>

<script>
export default {
  name: 'Pagination',
  props: {
    totalItems: {
      type: Number,
      required: true,
    },
    itemsPerPage: {
      type: Number,
      default: 16,
    },
  },
  data() {
    return {
      currentPage: parseInt(this.$route.query.page) || 1, 
    };
  },
  computed: {
    totalPages() {
      return Math.ceil(this.totalItems / this.itemsPerPage);
    },
    displayedPages() {
      const totalToShow = Math.min(5, this.totalPages);
      const midpoint = Math.ceil(totalToShow / 2); 
      
      let start = Math.max(1, this.currentPage - midpoint + 1);
      let end = Math.min(this.totalPages, this.currentPage + midpoint - 1);
      
      start = Math.max(1, Math.min(start, this.totalPages - totalToShow + 1));
      end = Math.min(this.totalPages, Math.max(end, start + totalToShow - 1));
      
      return Array.from({ length: totalToShow }, (_, i) => start + i);
    },
  },
  watch: {
    currentPage(newPage) {
      this.$emit('page-changed', newPage);
    },
  },
  methods: {
    prevPage() {
      const newPage = Math.max(1, this.currentPage - 1); 
      this.currentPage = newPage;
      this.$router.push({ query: { page: newPage } });
    },
    nextPage() {
      const newPage = Math.min(this.totalPages, this.currentPage + 1); 
      this.currentPage = newPage;
      this.$router.push({ query: { page: newPage } });
    },
    goToPage(page) {
      this.currentPage = page;
      this.$router.push({ query: { page } });
    },
  },
};
</script>

<style scoped>
.pagination {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-family: sans-serif;
}

.pagination__button {
  background-color: transparent; 
  border: none;
  border-radius: 4px;
  padding: 0.75rem 1rem;
  cursor: pointer;
  color: #333; 
  transition: color 0.2s ease;
  font-size: 16px; 
}

.pagination__button:hover {
  color: #666; 
}

.pagination__button:disabled {
  color: #ccc; 
  cursor: not-allowed; 
}

.pagination__button.active,
.pagination__button--active {
  background-color: #eee;
  color: #000;
}

.pagination__list {
  display: flex;
  list-style: none;
  padding: 0;
  margin: 0;
}

.pagination__item {
  margin: 0 0.5rem;
}
</style>
