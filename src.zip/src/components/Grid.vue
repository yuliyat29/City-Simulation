<template>
  <div class="grid-container" @mousedown="startSelecting" @mousemove="selecting" @mouseup="stopSelecting" @mouseleave="stopSelecting">
    <div class="square" :style="{ transform: `rotate(${-cameraRotation.alpha}rad)`}">
      <div v-for="(row, rowIndex) in grid" :key="rowIndex" class="grid-row">
        <div v-for="(cell, cellIndex) in row" :key="cellIndex"
          :class="['grid-cell', 
          { 'selected': cell.selected, 
            'residential': cell.type === 'RESIDENTIALBLOCK', 
            'water': cell.type === 'WATERBLOCK', 
            'park': cell.type === 'PARKBLOCK' 
          }]"
          @mousedown.prevent="toggleCell(rowIndex, cellIndex)"
          @mouseenter="mouseEnterCell(rowIndex, cellIndex)">
          <i v-if="cell.type === 'RESIDENTIALBLOCK'" class="fas fa-house" :style="{ transform: `rotate(${cameraRotation.alpha}rad)`}"></i>
          <i v-if="cell.type === 'WATERBLOCK'" class="fas fa-water" :style="{ transform: `rotate(${cameraRotation.alpha}rad)`}"></i>
          <i v-if="cell.type === 'PARKBLOCK'" class="fas fa-tree" :style="{ transform: `rotate(${cameraRotation.alpha}rad)`}"></i>
        </div>
      </div>
    </div>
    <div class="icons">
      <i class="fas fa-bus-simple" style="color: white"></i>
      <i class="fa-solid fa-person-digging"></i>
      <i class="fa-solid fa-building"></i>
      <i class="fa-solid fa-cube"></i>
    </div>
    <div class="input-container" id="transportation-cost">
      <input type="number" v-model="transportationCostInput" placeholder="Transportation Cost">
      <button 
        :class="transportationButtonClass" 
        :disabled="!isValidInput(transportationCostInput)" 
        @click="updateTransportationCost">{{ transportationButtonText }}
      </button>
    </div>
    <div class="input-container" id="construction-cost">
      <input type="number" v-model="constructionCostInput" placeholder="Construction Cost Limit">
      <button 
        :class="constructionButtonClass" 
        :disabled="!isValidInput(constructionCostInput)" 
        @click="updateConstructionCost">{{ constructionButtonText }}
      </button>
    </div>
    <div class="input-container" id="rent-limit">
      <input type="number" v-model="rentLimitInput" placeholder="Rent Limit">
      <button 
        :class="rentButtonClass" 
        :disabled="!isValidInput(rentLimitInput)" 
        @click="updateRentLimit">{{ rentButtonText }}
      </button>
    </div>
    <div class="input-container" id="blockType">
      <select type="BTYPE" v-model="newBlockType" class="drop-menu-type">
        <option value="" disabled> Select Block Type</option>
        <option value="WATERBLOCK"> Water</option>
        <option value="RESIDENTIALBLOCK"> Residential</option>
        <option value="PARKBLOCK"> Park</option>
      </select>
      <button @click="updateType">Update</button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    simulation: {
      type: Object,
      default: () => ({})
    },
    citySpec: {
      type: Object,
      default: () => ({})
    },
    cameraRotation: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      newBlockType: '',
      transportationCostInput: '',
      constructionCostInput: '',
      rentLimitInput: '',
      grid: [],
      gridSize: 0,
      isSelecting: false,

      transportationCostInput: '',
      constructionCostInput: '',
      rentLimitInput: ''
    };
  },
  watch: {
    citySpec: {
      immediate: true,
      handler(newCitySpec) {
        this.initGrid();
      },
    },
    simulation: {
      immediate: true,
      handler(newSimulation) {
        this.initGrid();
      },
    },
    cameraRotation: {
      handler(newCameraRotation) {
      },
      immediate: true,
    }
  },
  mounted() {
    this.initGrid();
  },
  computed: {
    transportationButtonClass() {
      return this.isValidInput(this.transportationCostInput) ? '' : 'invalid';
    },
    transportationButtonText() {
      return this.isValidInput(this.transportationCostInput) ? 'Update' : 'Invalid';
    },
    constructionButtonClass() {
      return this.isValidInput(this.constructionCostInput) ? '' : 'invalid';
    },
    constructionButtonText() {
      return this.isValidInput(this.constructionCostInput) ? 'Update' : 'Invalid';
    },
    rentButtonClass() {
      return this.isValidInput(this.rentLimitInput) ? '' : 'invalid';
    },
    rentButtonText() {
      return this.isValidInput(this.rentLimitInput) ? 'Update' : 'Invalid';
    }
  },
  methods: {
    initGrid() {
      this.grid = [];

      if (this.citySpec && this.citySpec.radius !== undefined) {
        this.gridSize = this.citySpec.radius;
        for (let i = -this.gridSize; i <= this.gridSize; ++i) {
          const row = [];
          for (let j = -this.gridSize; j <= this.gridSize; ++j) {
            const block = this.getBlockAtCoordinates(i, -j);
            row.push({
              text: `${i}, ${-j}`,
              selected: false,
              transportationCost: block?.transportationCost || 0,
              type: block?.type || 'PARKBLOCK'
            });
          }
          this.grid.push(row);
        }
      }
    },
    getBlockAtCoordinates(x, z) {
      if (!this.citySpec || !this.citySpec.tileInstanceGroups) return null;

      for (const [key, block] of Object.entries(this.simulation.city.blocks)) {
        if (block.x === x && block.y === z) {
          return block;
        }
      }
      return null;
    },
    async updateTransportationCost() {
      try {
        const selectedBlocks = this.grid
          .flatMap((row, rowIndex) =>
            row.map((cell, cellIndex) => ({
              cell,
              z: cellIndex - this.gridSize,
              x: rowIndex - this.gridSize
            }))
          )
          .filter(({ cell }) => cell.selected);

        const xCoordinates = selectedBlocks.map(({ x }) => x);
        const yCoordinates = selectedBlocks.map(({ z }) => -z);

        const payload = {
          simulationId: this.simulation._id,
          xCoordinates,
          yCoordinates,
          newTransportationCost: this.transportationCostInput,
        };

        await fetch(
          "http://localhost:8080/simulations/updateTransportationCost",
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            credentials: "include",
          }
        );
        this.$emit('simulation-updated');
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    async updateConstructionCost() {
      try {
        const selectedBlocks = this.grid
          .flatMap((row, rowIndex) =>
            row.map((cell, cellIndex) => ({
              cell,
              z: cellIndex - this.gridSize,
              x: rowIndex - this.gridSize
            }))
          )
          .filter(({ cell }) => cell.selected);

        const xCoordinates = selectedBlocks.map(({ x }) => x);
        const yCoordinates = selectedBlocks.map(({ z }) => -z);

        const payload = {
          simulationId: this.simulation._id,
          xCoordinates,
          yCoordinates,
          newConstructionCostLimit: this.constructionCostInput,
        };

        await fetch(
          "http://localhost:8080/simulations/updateConstructionCost",
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            credentials: "include",
          }
        );
        this.$emit('simulation-updated');
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    async updateType() {
      try {
        const selectedBlocks = this.grid
          .flatMap((row, rowIndex) =>
            row.map((cell, cellIndex) => ({
              cell,
              z: cellIndex - this.gridSize,
              x: rowIndex - this.gridSize
            }))
          )
          .filter(({ cell }) => cell.selected);

        const xCoordinates = selectedBlocks.map(({ x }) => x);
        const yCoordinates = selectedBlocks.map(({ z }) => -z);

        const payload = {
          simulationId: this.simulation._id,
          xCoordinates,
          yCoordinates,
          newBlockType: this.newBlockType,
        };

        await fetch(
          "http://localhost:8080/simulations/updateBlockTypes",
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            credentials: "include",
          }
        );
        this.$emit('simulation-updated');
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    async updateRentLimit() {
      try {
        const selectedBlocks = this.grid
          .flatMap((row, rowIndex) =>
            row.map((cell, cellIndex) => ({
              cell,
              z: cellIndex - this.gridSize,
              x: rowIndex - this.gridSize
            }))
          )
          .filter(({ cell }) => cell.selected);

        const xCoordinates = selectedBlocks.map(({ x }) => x);
        const yCoordinates = selectedBlocks.map(({ z }) => -z);

        const payload = {
          simulationId: this.simulation._id,
          xCoordinates,
          yCoordinates,
          newRentLimit: this.rentLimitInput,
        };

        await fetch(
          "http://localhost:8080/simulations/updateRentLimit",
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            credentials: "include",
          }
        );
        this.$emit('simulation-updated');
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    toggleCell(rowIndex, cellIndex) {
      this.grid[rowIndex][cellIndex].selected = !this.grid[rowIndex][cellIndex].selected;
    },
    startSelecting(event) {
      if (event.button === 0) { // Left mouse button
        this.isSelecting = true;
      }
    },
    stopSelecting() {
      this.isSelecting = false;
    },
    selecting(event) {
      if (this.isSelecting) {
        const element = document.elementFromPoint(event.clientX, event.clientY);
        const cellElement = element.closest('.grid-cell');
        if (cellElement) {
          const rowIndex = parseInt(cellElement.getAttribute('data-row'), 10);
          const cellIndex = parseInt(cellElement.getAttribute('data-cell'), 10);
          if (!isNaN(rowIndex) && !isNaN(cellIndex)) {
            this.toggleCell(rowIndex, cellIndex);
          }
        }
      }
    },
    mouseEnterCell(rowIndex, cellIndex) {
      if (this.isSelecting) {
        this.toggleCell(rowIndex, cellIndex);
      }
    },
    isValidInput(value) {
      if (value === '') return true;
      const number = parseFloat(value);
      return !isNaN(number) && number >= 0;
    },
  }
};
</script>

<style scoped>
.grid-row {
  display: flex;
}

.grid-cell {
  max-height: min(3vw, 3vh);
  max-width: min(3vw, 3vh);

  margin: 0.5px;
  width: 25px;
  height: 25px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  user-select: none;
  cursor: pointer;
}

.grid-container{
  bottom: min(75vh, 30px);
}

.input-container {
  position: absolute;
  left: 30px;
}

input {
  width: 200px;
  right: 50px;
  margin: 5px;
}

#transportation-cost {
  bottom: 150px;
  display: flex;
  flex-direction: row;
}

#construction-cost {
  bottom: 100px;
  display: flex;
  flex-direction: row;
}

#rent-limit {
  bottom: 52.5px;
  display: flex;
  flex-direction: row;
}

#blockType {
  display: flex;
  flex-direction: row;
  bottom: 0px;
}

.drop-menu-type {
  margin: 5px;
  border-radius: 5px;
}

select{
  width: 200px;
  height: 40px;
  font-size: 14px;

}

.square {
  display: flex;
  flex-direction: column;
  align-items: center;
  position: absolute;
  top: 10px;
  left: 30px;
  background-color: white;
}

.selected.residential {
  background-color: #deb887;
}

.selected.water {
  background-color: lightskyblue;
}

.selected.park {
  background-color: green;
}

.selected {
  background-color: transparent;
  transition: background-color 0.3s;
}

.selected {
  background-color: rgba(255, 0, 0, 0.5);
}


.cell-info {
  position: absolute;
  top: 0;
  left: 0;
  background-color: transparent;
  padding: 12px;
  width: 40px;
  height: 40px;
}

input, button {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 14px;
}

button {
  background-color: black;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: green;
}

button.invalid:disabled {
  background-color: red;
  cursor: not-allowed;
}

.icons {
  display: flex;
  flex-direction: column;
  position: absolute;
  bottom: min(75vh, 15px);
  gap: 30px;
  color: white;
  align-items: center;
}
</style>
