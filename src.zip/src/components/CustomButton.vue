<template>
  <button
    @click="handleClick"
    @dblclick.prevent="handleDoubleClick"
    :class="buttonClass"
    :disabled="disabled"
    :style="styleOverride"
  >
    <i v-if="iconClass" :class="iconClass"></i>
    <span v-if="buttonText">{{ buttonText }}</span>
  </button>
</template>

<script>
export default {
  props: {
    iconClass: String,
    buttonText: {
      type: String,
      default: "",
    },
    buttonClass: {
      type: String,
      default: "button",
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    styleOverride: {
      type: Object,
      default: () => ({}),
    },
  },
  methods: {
    handleClick(event) {
      if (!this.timer) {
        this.timer = setTimeout(() => {
          clearTimeout(this.timer);
          this.timer = null;
          this.$emit('button-clicked', event);
        }, 300);
      }
    },
    handleDoubleClick(event) {
      clearTimeout(this.timer);
      this.timer = null;
      this.$emit('button-dblclicked', event);
    },
  },
  data() {
    return {
      timer: null,
    };
  },
};
</script>

<style scoped>
.button {
  background-color: #292931;
  padding: 0.5rem 1rem;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: large;
}

.button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.button:hover:enabled {
  background-color: #29294a;
}

.circleIconButton {
  width: 70px;
  height: 70px;
  background-color: #292931;
  color: white;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: x-large;
}
</style>
