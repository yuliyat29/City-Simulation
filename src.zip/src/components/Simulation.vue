<template>
  <div id="vizual" v-if="citySpec">
    <MetroBlocksScene
    :city-spec="citySpec"
    @tile-select="handleTileSelect"
    @tile-deselect="handleTileDeselect"
    @click="getMousePosition"
    @camera-move="handleCameraMove"
    />
  </div>
  <div id="params" v-if="citySpec">
      <ul>
        <li>
          <ul>
            Simulation Status
            <i v-if="!simulation.isPublic" class="fas fa-lock"></i>
            <i v-else class="fas fa-lock-open"></i>
          </ul>
          <strong>{{ simulation.isPublic == false ? "Private" : "Public" }}</strong>
        </li>
        <li>
          <ul>
            Population Size
            <i class="fas fa-users"></i>
          </ul>
          <p>
            <strong v-if="oldSimulation?.populationSize && oldSimulation?.populationSize != simulation?.populationSize">{{ formatNumber(this.oldSimulation?.populationSize) }}</strong>
            <strong v-if="oldSimulation?.populationSize && oldSimulation?.populationSize != simulation?.populationSize"> / </strong>
            <strong :class="oldSimulation?.populationSize < simulation?.populationSize ? 'inc' : oldSimulation?.populationSize > simulation?.populationSize ? 'dec' : null">{{ formatNumber(this.simulation?.populationSize) }}</strong>
          </p>
        </li>
        <li>
          <ul>
            Transportation Cost
            <i class="fas fa-bus-simple"></i>
          </ul>
          <p>
            <strong>CHF</strong>
            <strong v-if="oldSimulation?.transportationCost && oldSimulation?.transportationCost != simulation?.transportationCost">{{ formatNumber(this.oldSimulation?.transportationCost) }}</strong>
            <strong v-if="oldSimulation?.transportationCost && oldSimulation?.transportationCost != simulation?.transportationCost"> / </strong>
            <strong :class="oldSimulation?.transportationCost < simulation?.transportationCost ? 'inc' : oldSimulation?.transportationCost > simulation?.transportationCost ? 'dec' : null">{{ formatNumber(this.simulation?.transportationCost) }}</strong>
          </p>
        </li>
        <li>
          <ul>
            Construction Cost Limit
            <i class="fa-solid fa-person-digging"></i>
          </ul>
          <p>
            <strong>CHF</strong>
            <strong v-if="oldSimulation?.constructionCostLimit && oldSimulation?.constructionCostLimit != simulation?.constructionCostLimit">{{ formatNumber(this.oldSimulation?.constructionCostLimit) }}</strong>
            <strong v-if="oldSimulation?.constructionCostLimit && oldSimulation?.constructionCostLimit != simulation?.constructionCostLimit"> / </strong>
            <strong :class="oldSimulation?.constructionCostLimit < simulation?.constructionCostLimit ? 'inc' : oldSimulation?.constructionCostLimit > simulation?.constructionCostLimit ? 'dec' : null">{{ formatNumber(this.simulation?.constructionCostLimit) }}</strong>
          </p>  
        </li>
        <li>
          <ul>
            Rent Limit
            <i class="fa-solid fa-building"></i>
          </ul>
          <p>
            <strong>CHF</strong>
            <strong v-if="oldSimulation?.rentLimit && oldSimulation?.rentLimit != simulation?.rentLimit">{{ formatNumber(this.oldSimulation?.rentLimit) }}</strong>
            <strong v-if="oldSimulation?.rentLimit && oldSimulation?.rentLimit != simulation?.rentLimit"> / </strong>
            <strong :class="oldSimulation?.rentLimit < simulation?.rentLimit ? 'inc' : oldSimulation?.rentLimit > simulation?.rentLimit ? 'dec' : null">{{  formatNumber(this.simulation?.rentLimit) }}</strong>
          </p>
        </li>
          <li>
            <ul>
              Average Wage
              <i class="fas fa-franc-sign"></i>
            </ul>
            <p>
              <strong>CHF</strong>
              <strong v-if="oldSimulation?.wage && oldSimulation?.wage != simulation?.wage">{{ formatNumber(this.oldSimulation?.wage) }}</strong>
              <strong v-if="oldSimulation?.wage && oldSimulation?.wage != simulation?.wage"> / </strong>
              <strong :class="oldSimulation?.wage < simulation?.wage ? 'inc' : oldSimulation?.wage > simulation?.wage ? 'dec' : null">{{ formatNumber(this.simulation?.wage) }}</strong>
            </p>
          </li>
      </ul>
  </div>
  <tooltip
      :block="block"
      :oldBlock="oldBlock"
      :mouse="mouse"

      v-if="block"
  />
</template>

<script setup>
import MetroBlocksScene from "@usi-si-teaching/metroblocks";
import "@usi-si-teaching/metroblocks/style";
import Tooltip from "../components/Tooltip.vue";
</script>

<script>
import { ref } from "vue";

const selectedTile = ref(null);

const buildingTile = {
  name: "Building Tile",
  type: "BuildingResidential",
  meshNameToPath: {
    buildingBase: "Building_base.glb",
    buildingFloor: "Building_floor.glb",
    buildingRoof: "Building_roof.glb",
    palm1: "Palm_tree_01.glb",
    palm2: "Palm_tree_02.glb",
    tree1: "Tree_01.glb",
    tree2: "Tree_02.glb",
    tree3: "Tree_03.glb",
  },
  randomProps: {
    propsMeshes: [
      "palm1",
      "palm2",
      "tree1",
      "tree2",
      "tree3",
      "tree3",
      "tree3",
      "tree3",
    ],
    maxCount: 5,
  },
  hasBuilding: true,
  building: {
    floors: [],
  },
};

const parkTile = {
  name: "Park Tile",
  type: "Park",
  meshNameToPath: {
    palm: "Palm_tree_01.glb",
    bench: "Park_bench.glb",
    tree: "Tree_01.glb",
    picnic: "Pic-nic_table.glb",
    hotdog: "Hot_dog_stand.glb",
  },
  randomProps: {
    propsMeshes: ["palm", "bench", "tree", "picnic", "hotdog"],
    maxCount: 20,
  },
};

const waterTile = {
  name: "Water Tile",
  type: "Water",
  meshNameToPath: {
    palm1: "Palm_tree_01.glb",
    palm2: "Palm_tree_02.glb",
  },
  randomProps: {
    propsMeshes: ["palm1", "palm2"],
    maxCount: 2,
  },
};

const generateCitySpec = (simulation) => {
  try {
    if (!simulation.city) {
      console.error(
        "Simulation city data is undefined. Simulation:",
        simulation
      );
      return null;
    }

    const cityData = simulation.city.blocks;
    const maxX = Math.max(
      ...Object.values(cityData).map((tileData) => Math.abs(tileData.x))
    );
    const maxY = Math.max(
      ...Object.values(cityData).map((tileData) => Math.abs(tileData.y))
    );
    const maxDistanceFromCenter = Math.max(maxX, maxY);
    const radius = maxDistanceFromCenter;

    const tileSpecs = [];

    const tileInstanceGroups = Object.entries(cityData).map(
      ([key, tileData]) => {
        let currentTileSpec =
          tileData.type === "RESIDENTIALBLOCK"
            ? { ...buildingTile }
            : tileData.type === "WATERBLOCK"
            ? { ...waterTile }
            : { ...parkTile };

        if (tileData.type === "RESIDENTIALBLOCK") {
          const floorCount = tileData.height - 2;

          currentTileSpec.building = {
            floors: [
              { type: "Single", mesh: "buildingBase" },
              { type: "Stacked", mesh: "buildingFloor", count: floorCount },
              { type: "Single", mesh: "buildingRoof" },
            ],
          };

          currentTileSpec = {
            ...currentTileSpec,
            name: `${currentTileSpec.name} ${key}`,
          };

          tileSpecs.push(currentTileSpec);

          const instances = [
            {
              position: { x: tileData.x, z: tileData.y },
              floorCount: floorCount,
            },
          ];

          return {
            tileSpecName: currentTileSpec.name,
            instances: instances,
          };
        } else if (
          tileData.type === "WATERBLOCK" ||
          tileData.type === "PARKBLOCK"
        ) {
          currentTileSpec = {
            ...currentTileSpec,
            name: `${currentTileSpec.name} ${key}`,
          };

          tileSpecs.push(currentTileSpec);

          const instances = [
            {
              position: { x: tileData.x, z: tileData.y },
            },
          ];

          return {
            tileSpecName: currentTileSpec.name,
            instances: instances,
          };
        }
      }
    );

    return {
      id: "generated-city",
      name: "generated city",
      radius: radius,
      tileSpecs: tileSpecs,
      tileInstanceGroups: tileInstanceGroups,
    };
  } catch (error) {
    console.error("Error parsing city data:", error);
    return null;
  }
};

export default {
  name: "Simulation",
  props: {
    simulation: {},
    oldSimulation: {},
  },
  data() {
    return {
      block: false,
      oldBlock: false,
      currentTile: null,
      mouse: {
        mouseX: "0px",
        mouseY: "0px",
      },
    };
  },
  computed: {
    citySpec() {
      return generateCitySpec(this.simulation);
    }
  },
  watch: {
    oldSimulation() {
      this.handleTileSelect(this.currentTile);
    },
    simulation: {
      handler(simulation) {
        const citySpec = generateCitySpec(simulation);
        this.$emit('citySpecComputed', citySpec);
      },
      immediate: true,
    },
  },
  methods: {
    formatNumber(value) {
      if (value === null || value === undefined) return '';

      // Convert the number to a string and split it into integer and decimal parts
      let [integerPart, decimalPart] = value.toString().split('.');

      // Add the thousands separators to the integer part
      integerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, "'");

      // Concatenate the integer part with the decimal part if it exists
      return decimalPart ? `${integerPart}.${decimalPart}` : integerPart;
    },
    async getSelectedBlock(params) {
      const id = this.$route.params.simulationId;
      try {
        const response = await fetch(
          "http://localhost:8080/simulations/getBlockByCoordinates",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              x: params.position.x,
              y: params.position.z,
              simulationId: id,
            }),
            credentials: "include",
          }
        );
        if (response.ok) {
          const blockData = await response.json();
          this.block = blockData; // Update the block data property
        } else {
          console.error("Failed to fetch block:", response.statusText);
        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    async getOldSelectedBlock(params) {
      const id = this.oldSimulation._id;
      try {
        const response = await fetch(
          "http://localhost:8080/simulations/getOldBlockByCoordinates",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              x: params.position.x,
              y: params.position.z,
              simulationId: id,
            }),
            credentials: "include",
          }
        );
        if (response.ok) {
          const blockData = await response.json();
          this.oldBlock = blockData;
        } else {
          console.error("Failed to fetch block:", response.statusText);
        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    handleCameraMove(cameraRotation) {
      this.cameraRotation = {
        alpha: cameraRotation.alpha,
      };
      this.$emit('cameraMoveUpdate', this.cameraRotation);
    },
    handleTileDeselect() {
      this.currentTile = null;
      selectedTile.value = null;
      this.block = false;
    },
    async handleTileSelect(params) {
      this.currentTile = params;
      this.getSelectedBlock(params);
      if (this.oldSimulation._id) {
        this.getOldSelectedBlock(params);
      }
      else {
        this.oldBlock = false;
      }
    },
    getMousePosition(event) {
      this.mouse.mouseX = event.layerX - 100 + "px";
      this.mouse.mouseY = event.layerY - 140 + "px";
    },
  },
};
</script>

<style scoped>
#vizual {
  width: 100%;
  height: 100%;
  position: absolute;
}

#params {
  position: absolute;
  top: 125px;
  right: 0.5vh;
  text-align: right;
  color: white;
  font-size: 1em;
  user-select: none;
  width: 230px;
}

#params ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

#params li {
  display: grid;
  margin-bottom: 5px;
  margin-right: 15px;
}

ul li {
  display: flex;
  justify-content: flex-end;
  gap: 5px;
}

ul li p {
  display: flex;
  gap: 4px;
  justify-content: right;
}

.dec {
  color: #ff0000;
}

.inc {
  color: #00ff00;
}
</style>
