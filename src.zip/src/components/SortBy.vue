<template>
  <div class="sort-by">
    <select class="sort-select" v-model="selectedSort" @change="handleSortChange">
      <option value="" disabled selected>Sort by:</option>
      <option v-for="option in options" :key="option.value" :value="option.value">{{ option.label }}</option>
    </select>
  </div>
</template>

<script>
export default {
  name: 'SortBy',
  props: {
    options: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      selectedSort: '',
    };
  },
  methods: {
    handleSortChange() {
      this.$emit('sort-changed', this.selectedSort);
    },
  }
};
</script>

<style scoped>
.sort-by {
  margin-bottom: 20px;
}

.sort-select {
  padding: 12px 32px 12px 16px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
  cursor: pointer;
  width: 200px;
  background-color: #fff;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
}

.sort-select:focus {
  outline: none;
  
}

.sort-select option {
  font-size: 16px;
}

.sort-select option[selected] {
  background-color: #f1f1f1;
}

</style>
