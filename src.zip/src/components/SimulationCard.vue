<template>
  <div class="simulation-card">
    <custom-button
        icon-class="fas fa-trash-can"
        @button-clicked="deleteSim"
        button-class="card-button delete-button"
    />
    <!-- Edit Button -->
    <custom-button
      icon-class="fas fa-edit"
      @click="modalVisible = true"
      button-class="card-button edit-button"
    /> 
    <span id="custom-tooltip">copied!</span>
    <custom-button
        icon-class="fas fa-share"
        @button-clicked="share"
        @button-dblclicked="unshare"
        button-class="card-button share-button"
        :styleOverride="simulation.isPublic ? { backgroundColor: '#023C7A'} : {}"
    />
   
    
    <router-link
      :to="{ name: 'simulation', params: { simulationId: simulation._id } }" class="simulation-card"
    >
      <div class="top">
        <div class="backdrop">
          <h3>{{ simulation.simulationName }}</h3>
        </div>
        <img :src="simulation.image || require('@/assets/city.png')" alt="city" />
      </div>
      <div class="bottom">
        <div class="item">
          <span>City population: </span>
          <span class="value">
            <i class="fas fa-users"></i>
            {{ formatNumber(this.simulation.populationSize) }}
          </span>
        </div>

        <div class="item">
          <span>Transportation Cost: </span>
          <span class="value">
            <i class="fas fa-bus-simple"></i>
            {{ formatNumber(this.simulation.transportationCost) }} CHF
          </span>
        </div>

        <div class="item">
          <span>Monthly Income: </span>
          <span class="value">
            <i class="fas fa-franc-sign"></i>
            {{ formatNumber(this.simulation.wage) }} CHF
          </span>
        </div>
      </div>
    </router-link>
  </div>
  
  <simulation-form-modal
    :visible="modalVisible"
    @close="modalVisible = false"
    @submitted="$emit('submitted')"
    :simulation="this.simulation"
    edit
    />

</template>

<script>

import ModalWrapper from "@/components/ModalWrapper.vue";
import InputField from "@/components/InputField.vue";
import CustomButton from "@/components/CustomButton.vue";
import SimulationFormModal from "@/partials/SimulationFormModal.vue";

export default {
  components: {
    CustomButton,
    ModalWrapper,
    InputField,
    SimulationFormModal,
  },
  props: {
    simulation: {
      type: Object,
      default: {},
    },
  },
  data() {
    return {
      modalVisible: false,
    };
  },
  methods: {
    formatNumber(value) {
      if (value === null || value === undefined) return '';

      // Convert the number to a string and split it into integer and decimal parts
      let [integerPart, decimalPart] = value.toString().split('.');

      // Add the thousands separators to the integer part
      integerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, "'");

      // Concatenate the integer part with the decimal part if it exists
      return decimalPart ? `${integerPart}.${decimalPart}` : integerPart;
    },
    async share(e) {
      let href;
      if (e.target.tagName.localeCompare("BUTTON") === 0) {
        href = new URL(e.target.nextSibling.href);
        e.target.previousSibling.style.display = "inline";
        setTimeout( function() {
          e.target.previousSibling.style.display = "none";
        }, 1000);
      } else {
        href = new URL(e.target.parentElement.nextSibling.href);
        e.target.parentElement.previousSibling.style.display = "inline";
        setTimeout( function() {
          e.target.parentElement.previousSibling.style.display = "none";
        }, 1000);
      }
      try {
        const res = await fetch("http://localhost:8080/simulations/makePublic", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({id: this.simulation._id}),
          credentials: "include",
        });
        if (res.ok) {
          this.simulation.isPublic = true;
          const link = await res.json();
          await navigator.clipboard.writeText(link.link);
        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    async unshare() {
      try {
        const res = await fetch("http://localhost:8080/simulations/makePrivate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({"id": this.simulation._id}),
          credentials: "include",
        });
        if (res.ok) {
          this.simulation.isPublic = false;
        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    async deleteSim() {
      try {
        const res = await fetch("http://localhost:8080/simulations/deleteSimulation", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({"id": this.simulation._id}),
          credentials: "include",
        });
        if (res.ok) {
          this.$emit('deleteSim');
        }
      } catch(error) {
        console.error("Failed to send request:", error);  
      }  
    },
  },
};
</script>

<style scoped>

.simulation-card{
  display: flex;
  flex-direction: column;
  background-color: #fff;
  border-radius: 15px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.top {
  display: flex;
  flex-direction: column;
  color: black;
  position: relative;
  z-index: 0;
}

.bottom {
  display: flex;
  flex-direction: column;
  color: black;
  padding: 10px 15px
}

.top img {
  width: 380px;
  height: 300px;
  border-radius: 15px 15px 0 0;
  object-fit: cover;
}

.top h3 {
  margin-top: 10px;
  margin-bottom: 10px;
  font-size: 24px;
  font-weight: 500;
}

.backdrop {
  background-color: #fff;
  opacity: 0.7;
  padding: 6px;
  width: 100%;
  text-align: center;
  position: absolute;
  top: 50%;
  transform: translate(0%, -50%);
  transition: .35s;
}


.simulation-card:hover .backdrop{
  opacity: 0;
}


.item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
  margin-bottom: 10px;
  font-size: 18px;
}

.item span {
  margin-right: 10px;
}

.item i {
  margin-right: 5px;
}

.simulation-card {
  position: relative;
}

.card-button {
  z-index: 1;
  position: absolute;
  top: 10px;
  width: 46px;
  height: 46px;
  font-size: 18px;
  color: white;
  padding: 10px;
  border-radius: 50%;
  border: none;
  cursor: pointer;
}

.share-button {
  right: 65px;
  background-color: #292931;
}

.edit-button {
  right: 10px;
  background-color: #292931;
}

.delete-button {
  right: 120px;
  background-color: #292931;
}

.share-button:hover {
  background-color: #3e3e4a;
}

.edit-button:hover {
  background-color: #3e3e4a;
}

.delete-button:hover {
  background-color: #3e3e4a;
}

#custom-tooltip {
  display: none;
  z-index: 1;
  position: absolute;
  top: 18px;
  right: 118px;
  padding: 5px 12px;
  background-color: #000000ab;
  border-radius: 4px;
  color: #fff;
}

</style>
