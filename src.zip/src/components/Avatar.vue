<template>
  <!-- <router-link :to="{ name: 'profile' }" class="avatar-link"> -->
    <div :class="{ 'avatar': true, 'avatar-square': square }" :style="{ width: size + 'px', height: size + 'px' }" >
      <img :src="imageUrl || require('@/assets/profile.png')" :alt="altText" class="avatar-image" />
    </div>
  <!-- </router-link> -->
</template>

<script>
export default {
  props: {
    imageUrl: {
      type: String,
    },
    altText: {
      type: String,
      default: 'User Avatar'
    },
    size: {
      type: Number,
      default: 40
    },
    square: {
      type: Boolean,
      default: false
    },
  }
}
</script>

<style scoped>
/* .avatar-link {
  text-decoration: none;
  cursor: pointer;
} */

.avatar {
  border-radius: 50%;
  overflow: hidden;
  transition: box-shadow 0.5s ease-in-out;
}

.avatar:hover {
  box-shadow: 0 0 10px 2px rgba(0,0,0,.8);
}

.avatar-image {
  width: 100%;
  height: 100%;
}

.avatar-square {
  border-radius: 20%;
}
</style>
