<template>
  <div class="wrapper">
    <div class="label" v-if="label" for="input">{{ label }}</div>
    <input :type="type" :value="value" :placeholder="placeholder" @input="handleInput">
    <div class="error-message">{{ errorMessages[0] }}</div>
  </div>
</template>

<script>
import validate from '@/utils/validator';

export default {
  props: {
    type: {
      type: String,
      default: 'text'
    },
    value: {
      type: [String, Number],
      default: '',
    },
    placeholder: String,
    label: String,
    validationRules: {
      type: [String],
      default: () => [],
    },
  },
  data() {
    return {
      errorMessages: [],
    };
  },
  methods: {
    handleInput(event) {
      this.errorMessages = validate(event.target.value, this.validationRules);
      this.$emit('update:value', event.target.value);
      this.$emit('update:error', this.errorMessages);
    },
  },
  mounted() {
    this.$emit('update:error', validate(this.value, this.validationRules));
  },
}
</script>


<style scoped>
input {
  width: 100%;
  height: 50px;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: medium;
}
input:focus {
  outline: none;
  border-color: #007bff;
}

.error-message {
  font-size: 1rem;
  height: 1rem;
  margin-top: 5px;
  color: #ff0019;
  font-weight: bold;
}

.label {
  font-size: 1.02rem;
  margin-bottom: 5px;
}

</style>
