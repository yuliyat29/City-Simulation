<template>
    <!-- <ul>
    <li v-for="user in users" v-bind:key="user._id">{{ user.name, user.email}}</li>
</ul> -->
<router-link :to="'/profile/' + userId" class="card-link">
    <div class="user-card">
                <avatar :imageUrl="profilePhoto" :alt-text="name" :size=80 :square="true" />
                <div class="info">
                    <div class="userName">
                        <span> {{ userName.length > 26 ? userName.slice(0, 26) + "..." : userName }} </span>
                    </div>
                    <div class="userEmail">
                        <span> {{ userEmail.length > 26 ? userEmail.slice(0, 26) + "..." : userEmail }} </span>
                    </div>
                </div>
    </div>
</router-link>
</template>

<script>

import Avatar from '@/components/Avatar.vue';

export default {
    components: { Avatar },
    props: {
        userName: "",
        profilePhoto: "",
        userId: "",
        userEmail: ""
    }
}
</script>


<style scoped>
.user-card {
    display: flex;
    flex-direction: row;
    gap: 15px;
    background-color: #fff;
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    min-width: 360px;
    width: calc((100% - 100px )/ 4);
    padding: 20px;
}

.info {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    width: 100%;
    max-width: 220px;
    white-space: nowrap;
    overflow: hidden;
    text-align: left;
}

.userName {
    font-weight: bold;
}

.card-link {
    text-decoration: none;
    cursor: pointer;
    color: black;
}

.avatar:hover {
    box-shadow: none;
}
</style>