import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: HomeView,
    meta: { requiresAuth: true },
  },
  {
    path: "/profile/:userId",
    name: "user-profile",
    component: () => import(/* webpackChunkName: "profile" */ "../views/UserProfileView.vue"),
    meta: { requiresAuth: true },
  },
  {
    path: "/simulations",
    name: "simulations",
    component: () =>
      import(
        /* webpackChunkName: "simulations" */ "../views/SimulationListView.vue"
      ),
    meta: { requiresAuth: true },
  },
  {
    path: "/simulations/shared/:simulationId",
    name: "shared-simulation",
    component: () =>
      import(
        /* webpackChunkName: "shared-simulation" */ "../views/SharedSimulationView.vue"
      ),
    meta: { requiresAuth: false },

  },
  {
    path: "/simulations/:simulationId",
    name: "simulation",
    component: () =>
      import(
        /* webpackChunkName: "simulation" */ "../views/SimulationView.vue"
      ),
    meta: { requiresAuth: true },
  },
  {
    path: "/users",
    name: "users",
    component: () =>
      import(/* webpackChunkName: "users" */ "../views/UserListView.vue"),
    meta: { requiresAuth: true },
  },
  {
    path: "/profile",
    name: "profile",
    component: () =>
      import(/* webpackChunkName: "add" */ "../views/ProfileView.vue"),
    meta: { requiresAuth: true },
  },
  {
    path: "/login",
    name: "login",
    component: () => import("../views/LoginView.vue"),
  },
];

async function fetchAuthenticationStatus() {
  try {
    const response = await fetch(
      "http://localhost:8080/users/isAuthenticated",
      { credentials: "include" }
    );
    return response.json();
  } catch (error) {
    console.error("Error fetching authentication status:", error);
    return false;
  }
}

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

router.beforeEach(async (to, from, next) => {
  const isAuthenticated = await fetchAuthenticationStatus();
  if (to.meta.requiresAuth) {
    try {
      if (isAuthenticated) {
        next();
      } else {
        next("/login");
      }
    } catch (error) {
      console.error("Error checking authentication status:", error);
      next("/login");
    }
  } else if (to.name === "login") {
    if (isAuthenticated) {
      next("/");
    } else {
      next();
    }
  } else {
    next();
  }
});

export default router;
