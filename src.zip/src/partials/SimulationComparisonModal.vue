<template>
  <modal-wrapper :visible="visible" @close="closeModal">
    <div class="wrapper">
      <h1 class="modal-title">Old versions</h1>
      <div v-for="simulation in simulations" :key="simulation.id" class="card" @click="handleClick(simulation._id)">
          <div class="params">
            <div><i class="fas fa-users"></i> {{ simulation.populationSize }}</div>
            <div><i class="fas fa-bus-simple"></i> {{ simulation.transportationCost }}</div>
            <div><i class="fa-solid fa-person-digging"></i> {{ simulation.constructionCostLimit }}</div>
            <div><i class="fa-solid fa-building"></i> {{ simulation.rentLimit }}</div>
            <div><i class="fas fa-franc-sign"></i> {{ simulation.wage }}</div>
          </div>
          {{ formatTimeBeforeNow(simulation.updateDate) }} 
      </div>
    </div>
  </modal-wrapper>
</template>

<script>
import ModalWrapper from "@/components/ModalWrapper.vue";

export default {
  name: "SimulationComparisonModal",
  components: {
    ModalWrapper,
  },
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      simulations: {
        type: Array,
        default: [],
      },
    };
  },
  mounted() {
    this.getSimulations();
  },
  watch: {
    visible() {
      this.getSimulations();
    },
  },
  methods: {
    closeModal() {
      this.$emit("close");
    },
    async getSimulations() {
      try {
        const response = await fetch(
          `http://localhost:8080/simulations/getUserOldSimulations/${this.$route.params.simulationId}`,
          { credentials: "include" }
        );
        if (response.ok) {
          const simulations = await response.json();
          this.simulations = simulations
        } else {
          console.error("Failed to fetch block:", response.statusText);
        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    formatTimeBeforeNow(date) {
      const diff = new Date(new Date() - new Date(date));
      if (diff.getMinutes() < 60) return `${diff.getMinutes()} minutes ago`;
      else if (diff.getHours() < 24) return `${diff.getHours()} hours ago`;
      else diff.getDate() < 30 ? `${diff.getDate()} days ago` : `${diff.getMonth()} months ago`;
    },
    handleClick(id) {
      this.$emit('clicked', id);
      this.closeModal();
    },
  },
};
</script>

<style scoped>
.modal-title {
  text-align: center;
  margin-bottom: 15px;
  font-size: 2rem;
  color: #353935;
}

.card {
  display: flex;
  justify-content: space-between;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 15px;
  margin-bottom: 10px;
}

.card:hover {
  background-color: #f0f0f0;
}

.params {
  display: flex;
  justify-content: space-between;
  gap: 30px
}

.params div {
  display: flex;
  gap: 8px;
  align-items: center;
  justify-content: center;
}

.wrapper {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
</style>
