<template>
  <modal-wrapper :visible="visible" @close="closeModal">
    <h2 class="modal-title">
      {{ edit ? "Edit Simulation" : "Create New Simulation" }}
    </h2>
    <div class="form-wrapper">
      <form @submit.prevent="submitForm">
        <input-field
          @update:value="transportationCost.value = $event"
          @update:error="transportationCost.errorMessages = $event"
          :value="transportationCost.value"
          :validation-rules="['required()', 'range(1, 2000)', 'isNumber()']"
          placeholder="Transportation Cost"
          :label=" 'Transportation Cost' "
        />
        <input-field
          @update:value="constructionCostLimit.value = $event"
          @update:error="constructionCostLimit.errorMessages = $event"
          :value="constructionCostLimit.value"
          :validation-rules="['required()', 'range(1, 200000)', 'isNumber()']"
          placeholder="Construction Cost Limit"
          :label=" 'Construction Cost Limit' "
        />
        <input-field
          @update:value="rentLimit.value = $event"
          @update:error="rentLimit.errorMessages = $event"
          :value="rentLimit.value"
          :validation-rules="['required()', 'range(10, 40000)', 'isNumber()']"
          placeholder="Rent Limit"
          :label="'Rent  Limit' "
        />
        <input-field
          @update:value="wage.value = $event"
          @update:error="wage.errorMessages = $event"
          :value="wage.value"
          :validation-rules="['required()', 'range(7000, 16000)', 'isNumber()']"
          placeholder="Wage"
          :label=" 'Wage' "
        />
        <input-field
          @update:value="simulationName.value = $event"
          @update:error="simulationName.errorMessages = $event"
          :value="simulationName.value"
          :validation-rules="[
            'required()',
            'minLength(3)',
            'maxLength(50)',
            'isValidName()',
          ]"
          placeholder="Simulation Name"
          :label=" 'Simulation Name' "
        />

        <custom-button button-text="Submit" :disabled="isBlocked" />
      </form>
    </div>
  </modal-wrapper>
</template>

<script>
import ModalWrapper from "@/components/ModalWrapper.vue";
import InputField from "@/components/InputField.vue";
import CustomButton from "@/components/CustomButton.vue";

export default {
  name: "SimulationFormModal",
  components: {
    ModalWrapper,
    InputField,
    CustomButton,
  },
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
    edit: Boolean,
    simulation: {
      type: Object,
      default: {},
    },
  },
  data() {
    return {
      transportationCost: {
        value: "",
        errorMessages: [],
      },
      constructionCostLimit: {
        value: "",
        errorMessages: [],
      },
      rentLimit: {
        value: "",
        errorMessages: [],
      },
      wage: {
        value: "",
        errorMessages: [],
      },
      simulationName: {
        value: "",
        errorMessages: [],
      },
    };
  },
  watch: {
    simulation: {
      immediate: true,
      handler(newVal) {
        if (this.edit) {
          this.transportationCost.value = newVal.transportationCost || "";
          this.constructionCostLimit.value = newVal.constructionCostLimit || "";
          this.rentLimit.value = newVal.rentLimit || "";
          this.wage.value = newVal.wage || "";
          this.simulationName.value = newVal.simulationName || "";
        }
      },
    },
  },
  computed: {
    isBlocked() {
      return (
        this.transportationCost.errorMessages.length > 0 ||
        this.constructionCostLimit.errorMessages.length > 0 ||
        this.rentLimit.errorMessages.length > 0 ||
        this.wage.errorMessages.length > 0 ||
        this.simulationName.errorMessages.length > 0
      );
    },
    formData() {
      const data = {
        simulationName: this.simulationName.value,
        transportationCost: this.transportationCost.value,
        constructionCostLimit: this.constructionCostLimit.value,
        rentLimit: this.rentLimit.value,
        wage: this.wage.value,
      };
      if (this.edit)
        data._id = this.$route.params.simulationId || this.simulation._id;
      return data;
    },
  },
  methods: {
    closeModal() {
      this.$emit("close");
      this.resetForm();
    },
    async submitForm() {
      try {
        const res = await fetch(
          this.edit
            ? "http://localhost:8080/simulations/updateSimulation"
            : "http://localhost:8080/simulations/addSimulation",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(this.formData),
            credentials: "include",
          }
        );
        if (res.ok){
          this.$emit("submitted");
          this.closeModal();
        }
        else {
            alert("Simulation could not be saved, maybe it's too big. \ Please try again with different parameters."); 
        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    resetForm() {
      this.transportationCost.value = this.edit ? this.simulation.transportationCost : "";
      this.constructionCostLimit.value = this.edit ? this.simulation.constructionCostLimit : "";
      this.rentLimit.value = this.edit ? this.simulation.rentLimit : "";
      this.wage.value = this.edit ? this.simulation.wage : "";
      this.simulationName.value = this.edit ? this.simulation.simulationName : "";
    },
  },
};
</script>

<style scoped>
.modal-title {
  text-align: center;
  margin-bottom: 40px;
  font-size: 2rem;
  color: #353935;
}

.form-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
}

form {
  display: flex;
  flex-direction: column;
  gap: 20px;
  width: 100%;
  padding: 0px 40px;
}
</style>
