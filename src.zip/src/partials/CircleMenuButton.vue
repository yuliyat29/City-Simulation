<template>
  <div class="circular-menu">
    <button class="menu-item" @click="$emit('edit-clicked')" v-if="isOpen" :class="{ 'slide-in-1': isOpen }" ><i class="fas fa-edit"></i></button>
    <button class="menu-item" @click="$emit('compare-clicked')" v-if="isOpen" :class="{ 'slide-in-2': isOpen }" :style="isCompareActive ? {background: 'rgb(2, 60, 122)'} : null"><i class="fas fa-code-compare"></i></button>
    <button class="menu-item" @click="$emit('grid-clicked')" v-if="isOpen" :class="{ 'slide-in-3': isOpen }" ><i class="fa-sharp fa-solid fa-border-all"></i></button>
    <button class="main-button" @click="toggleMenu"><i class="fas fa-bars"></i></button>
  </div>
</template>


<script>
export default {
  data() {
    return {
      isOpen: false,
    };
  },
  props: {
    isCompareActive: Boolean,
    isShareActive: Boolean,
  },
  methods: {
    toggleMenu() {
      this.isOpen = !this.isOpen;
    },
    handleShare() {
      this.isShareActive ? this.unshare() : this.share();
    },
    async share() {
      const simulationId = this.$route.params.simulationId;
      try {
        const res = await fetch("http://localhost:8080/simulations/makePublic", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({id: simulationId}),
          credentials: "include",
        });
        if (res.ok) {
          const {link} = await res.json();
          console.log(link);
          navigator.clipboard.writeText(link);
          this.$emit("share", true);

        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
    async unshare() {
      const simulationId = this.$route.params.simulationId;
      try {
        const res = await fetch("http://localhost:8080/simulations/makePrivate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({id: simulationId}),
          credentials: "include",
        });
        if (res.ok) {
          this.$emit("share", false);
        }
      } catch (error) {
        console.error("Failed to send request:", error);
      }
    },
  },
};
</script>

<style>
.circular-menu {
  position: absolute;
  bottom: 30px;
  right: 30px;
  z-index: 2;
}

.main-button {
  width: 70px;
  height: 70px;
  background-color: #292931;
  color: white;
  border: none;
  border-radius: 50%;
  cursor: pointer;
}

.menu-item {
  background-color: #292931;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 8px 12px;
  margin-bottom: 5px;
  cursor: pointer;
  position: absolute;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.menu-item-open {
  transform: translate(0, 0);
}

.main-button:hover, .menu-item:hover {
  transform: scale(1.05);
  transition: transform 0.2s;
}

.menu-item:nth-child(1) {
  bottom: 0px;
  right: 105px;
}

.menu-item:nth-child(2) {
  bottom: 75px;
  right: 75px;
}

.menu-item:nth-child(3) {
  bottom: 105px;
  right: 0px;
}

.slide-in-1 {
  animation: slideIn1 0.3s ease;
}

.slide-in-2 {
  animation: slideIn2 0.3s ease;
}

.slide-in-3 {
  animation: slideIn3 0.3s ease;
}


@keyframes slideIn1 {
  from {
    bottom: 30px;
    right: 30px;
    opacity: 0;
  }
  to {
    bottom: 0px;
    right: 105px;
    opacity: 1;
  }
}

@keyframes slideIn2 {
  from {
    bottom: 30px;
    right: 30px;
    opacity: 0;
  }
  to {
    bottom: 75px;
    right: 75px;
    opacity: 1;
  }
}

@keyframes slideIn3 {
  from {
    bottom: 30px;
    right: 30px;
    opacity: 0;
  }
  to {
    bottom: 105px;
    right: 0px;
    opacity: 1;
  }
}

i {
  font-size: min(3vh, 3vw, 1.2em);
}

.menu-label {
  font-size: 0.8rem;
  margin-top: 4px;
}

</style>