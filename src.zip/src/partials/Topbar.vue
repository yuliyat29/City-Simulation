<template>
  <div class="topbar">
    <img src="../assets/usi-logo.png" class="logo" alt="logo" />
    <span>{{ $store.state.simulationName }}</span>
    <div class="container">
      <div class="utils">
        <i class="fas fa-info-circle" @click="visible = true"></i>
        <i
          :class="bell ? 'fas fa-bell' : 'fas fa-bell-slash'"
          @click="bell = !bell"
        ></i>
        <i class="fas fa-cog"></i>
      </div>
      <div class="divider"></div>
      <router-link :to="{ name: 'profile' }" class="avatar-link">
        <avatar :imageUrl="$store.state.imageURL" :alt-text="name" />
      </router-link>
    </div>
  </div>
  <modal-wrapper :visible="visible" @close="closeModal">
    <h2 class="title">Information</h2>
    <p class="text">
      <strong>Use these settings to get started with your first simulation!</strong> <br/><br/>
      <strong>Movement:</strong> Use the AWSD keys to navigate the simulation. <br/><br/>
      <strong>Rotation:</strong> Click and drag to rotate the simulation view. <br/><br/>
      <strong>Zoom:</strong> Pinch with two fingers to zoom in and out. <br/>
      To get started and see how everything works, try using the followingexample parameters: 
      <ul>
        <li><strong>Transportation cost:</strong> 1200 </li>
        <li><strong>Construction Cost Limit:</strong> 5000</li>
        <li><strong>Rent Limit:</strong> 2500 </li>
        <li><strong>Wage:</strong> 11000</li>
        <li><strong>Simulation Name:</strong> Some Name</li>
      </ul>
    </p>
  </modal-wrapper>
</template>

<script>
import Avatar from "@/components/Avatar.vue";
import ModalWrapper from "@/components/ModalWrapper.vue";

export default {
  components: {
    Avatar,
    ModalWrapper,
  },
  data() {
    return {
      profilePhoto: "",
      selectedIndex: 0,
      menuItems: [
        { name: "Home", route: "/", icon: "fas fa-home menu-icon" },
        {
          name: "About",
          route: "/about",
          icon: "fas fa-info-circle menu-icon",
        },
        { name: "Users", route: "/users", icon: "fas fa-users menu-icon" },
        { name: "Add", route: "/add", icon: "fas fa-plus menu-icon" },
        {
          name: "Simulations",
          route: "/simulations",
          icon: "fas fa-chart-line menu-icon",
        },
      ],
      visible: false,
      bell: false,
    };
  },
  async mounted() {},
  methods: {
    closeModal() {
      this.visible = false;
    },
  },
};
</script>

<style scoped>
.topbar {
  width: 100%;
  height: 110px;
  background-color: #292931;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-right: 24px;
}

.container {
  display: flex;
  align-items: center;
  gap: 24px;
}

.utils {
  display: flex;
  align-items: center;
  gap: 20px;
  color: white;
  font-size: 20px;
}

.divider {
  height: 40px;
  width: 2px;
  background-color: white;
}

.title {
  color: white;
}

.logo {
  height: 100%;
  filter: invert(100%);
}

span {
  text-align: center;
  color: white;
  font-size: 2em;
}

.avatar-link {
  text-decoration: none;
  cursor: pointer;
}

.title {
  font-size: 24px;
  font-weight: 700;
  color: #333;
  text-align: center;
}

.text {
  margin-top: 20px;
}

.text ul {
  margin-left: 20px;
  margin-top: 15px;
}
</style>
