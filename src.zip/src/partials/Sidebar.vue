<template>
  <nav class="sidebar">
    <ul>
      <router-link v-for="(item, index) in menuItems" :key="index" :to="item.route" exact>
        <div class="item_wrapper">
          <i :class="item.icon"></i>
          <li :class="{ 'active': selectedIndex === index }">{{ item.name }}</li>
        </div>
      </router-link>
    </ul>
  </nav>
</template>

<script>
export default {
  data() {
    return {
      selectedIndex: 0,
      menuItems: [
        {name: 'Home', route: '/', icon: 'fas fa-home menu-icon'},
        {name: 'Users', route: '/users', icon: 'fas fa-users menu-icon'},
        {name: 'Simulations', route: '/simulations', icon: 'fas fa-chart-line menu-icon'},
      ]
    };
  }
};
</script>

<style scoped>
.sidebar {
  width: 100%;
  height: calc(100vh - 116px);
  background-color: #292931;
  color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 0 50px 50px 0;
  padding-right: 12px;
}

.sidebar ul {
  height: 100%;
  list-style-type: none;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
}

.item_wrapper {
  display: flex;
  flex-direction: column;
  color: white;
  align-items: center;
  gap: 12px;
}

.menu-icon {
  font-size: 24px;
}

</style>
