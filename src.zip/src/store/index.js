import { createStore } from "vuex";

export default createStore({
  state: {
    simulationName: "",
    imageURL: ""
  },
  getters: {
  },
  mutations: { //Setters
    setSimulationName(state, name) {
      state.simulationName = name;
    },
    clearSimulationName(state) {
      state.simulationName = "";
    },
    setImageURL(state, name) {
      state.imageURL = name;
    },

  },
  actions: { //Methods

  },
  modules: {},
});
