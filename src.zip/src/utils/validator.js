class Validator {
  static required(value) {
    if (value === '') {
      return 'Value is required';
    }
  }

  static min(value, min) {
    if (value < min) {
      return `Value must be greater than ${min}`;
    }
  }

  static max(value, max) {
    if (value > max) {
      return `Value must be less than ${max}`;
    }
  }

  static minLength(value, min) {
    if (value.length < min) {
      return `Value must have at least ${min} characters`;
    }
  }

  static maxLength(value, max) {
    if (value.length > max) {
      return `Value must have at most ${max} characters`;
    }
  }

  static range(value, min, max) {
    if (value < min || value > max) {
      return `Value must be between ${min} and ${max}`;
    }
  }

  static isNumber(value) {
    if (isNaN(value)) {
      return 'Value must be a number';
    }
  }

  static isValidName(value) {
    const pattern = /^[a-zA-Z0-9 ]+$/;
    if (!pattern.test(value)) {
      return 'Value must contain letters, spaces and numbers only';
    }
  }

  static validate(value, rules) {
    const errors = [];
    for (const rule of rules) {
      const [methodName, args] = rule.split('(');
      const method = methodName.trim();
      if (args) {
        const argValues = args.slice(0, -1).split(',').map(arg => parseFloat(arg.trim()));
        const error = Validator[method](value, ...argValues);
        if (error) {
          errors.push(error);
        }
      } else {
        const error = Validator[method](value);
        if (error) {
          errors.push(error);
        }
      }
    }
    return errors;
  }
}

const validate = (value, rules) => {
  return Validator.validate(value, rules);
}

export default validate;