<template>
  <div id="container" style="position: relative">
    <Simulation
      v-if="simulation"
      @citySpecComputed="handleCitySpecComputed" 
      @cameraMoveUpdate="handleCameraMoveUpdate"
      :simulation="simulation"
      :old-simulation="oldSimulation"
    />
    <div v-else>Loading...</div>

    <circle-menu-button
      @edit-clicked="modalVisible = true"
      @share="simulation.isPublic = $event"
      @grid-clicked="toggleGrid"
      @compare-clicked="handleComparisonButtonClick"
      :is-share-active="simulation.isPublic"
      :is-compare-active="isCompareActive"
    />

    <simulation-form-modal
      :visible="modalVisible"
      @close="modalVisible = false"
      @submitted="getSimulation"
      :simulation="this.simulation"
      edit
    />

    <simulation-comparison-modal
      :visible="comparisonModalVisible"
      @close="comparisonModalVisible = false"
      @clicked="handleComparisonSimClick"
    />
    
    <Grid class="grid-wrapper"
      v-if="gridVisible"
      @citySpecComputed="handleCitySpecComputed" 
      @simulation-updated="getSimulation"
      @cameraMoveUpdate="handleCameraMoveUpdate"
      :city-spec="this.citySpec"
      :simulation="this.simulation"
      :camera-rotation="this.cameraRotation"
    />
  </div>
</template>

<script>
import Simulation from "@/components/Simulation.vue";
import CustomButton from "@/components/CustomButton.vue";
import SimulationFormModal from "@/partials/SimulationFormModal.vue";
import Grid from "@/components/Grid.vue";
import CircleMenuButton from "@/partials/CircleMenuButton.vue";
import SimulationComparisonModal from "@/partials/SimulationComparisonModal.vue";

export default {
  name: "SimulationView",
  components: {
    Simulation,
    CustomButton,
    SimulationFormModal,
    Grid,
    CircleMenuButton,
    SimulationComparisonModal,
  },

  data() {
    return {
      simulation: {},
      citySpec: {},
      cameraRotation: {},
      oldSimulation: {},
      modalVisible: false,
      gridVisible: false,
      simulationId: this.$route.params.simulationId,
      isCompareActive: false,
      comparisonModalVisible: false,
    };
  },
  mounted() {
    this.getSimulation();
  },
  methods: {
    async getSimulation() {
      try {
        const res = await fetch(
          `http://localhost:8080/simulations/${this.simulationId}`,
          {
            credentials: "include",
          }
        );
        if (!res.ok) {
          throw new Error("Failed to fetch simulation");
        }
        const simulation = await res.json();
        this.simulation = simulation;
        this.$store.commit("setSimulationName", simulation.simulationName);
      } catch (error) {
        console.error("Error fetching simulation by ID:", error);
        throw error;
      }
    },
    clearSimulationName() {
      this.$store.commit("clearSimulationName");
    },
    toggleGrid() {
      this.gridVisible = !this.gridVisible;
    },
    handleCitySpecComputed(citySpec) {
      this.citySpec = citySpec;
      console.log(this.citySpec)
    },
    handleCameraMoveUpdate(cameraRotation) {
      this.cameraRotation = cameraRotation;
    },
    async handleComparisonSimClick(id) {
      this.isCompareActive = true;
      try {
        const res = await fetch(
          `http://localhost:8080/simulations/getOldSimulation/${id}`,
          { credentials: "include" }
        );
        if (!res.ok) {
          throw new Error("Failed to fetch old simulation");
        }
        const oldSimulation = await res.json();
        this.oldSimulation = oldSimulation;
      } catch (error) {
        console.error("Error fetching old simulation by ID:", error);
        throw error;
      }
    },
    handleComparisonButtonClick() {
      if(this.isCompareActive){
        this.isCompareActive = false;
        this.oldSimulation = false;
      } else this.comparisonModalVisible = true;
    },
  },
  beforeRouteLeave(to, from, next) {
    this.clearSimulationName();
    next();
  },
};
</script>

<style scoped>
#container {
  width: 100%;
  height: 100%;
}

.circleIconButton {
  position: absolute;
  bottom: 20px;
  right: 20px;
}

.gridIconButton {
  position: absolute;
  bottom: 20px;
  right: 100px;
}

.grid-wrapper {
  position: absolute;
  left: 8em;
  top: 140px;
}

h1 {
  text-align: center;
}
</style>
