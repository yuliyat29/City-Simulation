<template>
  <div class="container">
    <div class="add">
      <custom-button
        @button-clicked="modalVisible = true"
        button-class="circleIconButton"
        icon-class="fas fa-plus"
      />
    </div>
    <div class="top-wrapper">
      <h1>My Simulations:</h1>
      <sort-by
        class="sort-by"
        :options="[
            { label: 'Biggest first', value: {param: 'populationSize', order: 'DESC'}},
            { label: 'Smallest first', value: {param: 'populationSize', order: 'ASC'}},
            { label: 'Newest first', value: {param: 'updateDate', order: 'DESC'}},
            { label: 'Oldest first', value: {param: 'updateDate', order: 'ASC'}},
        ]"
        @sort-changed="this.sort = $event; getSimulationsList()"
      />
    </div>
    <div class="sim-wrapper">
      <ul>
        <li v-for="simulation in simulations" :key="simulation._id">
          <simulation-card
            :simulation="simulation"
            @submitted="getSimulationsList"
            @deleteSim="getSimulationsList"
          />
        </li>
      </ul>
    </div>
    <div class="bottom-wrapper">
      <pagination
        :total-items="this.simulationsCount"
        :items-per-page="itemsPerPage"
        @page-changed="this.currentPage = $event; getSimulationsList()"
      />
    </div>

    <simulation-form-modal
      :visible="modalVisible"
      @close="modalVisible = false"
      @submitted="onSimulationCreated"
    />
  </div>
</template>

<script>
import SimulationCard from "@/components/SimulationCard.vue";
import ModalWrapper from "@/components/ModalWrapper.vue";
import InputField from "@/components/InputField.vue";
import CustomButton from "@/components/CustomButton.vue";
import SimulationFormModal from "@/partials/SimulationFormModal.vue";
import SortBy from "@/components/SortBy.vue";
import Pagination from "@/components/Pagination.vue";


export default {
  name: "SimulationListView",
  components: {
    SimulationCard,
    ModalWrapper,
    InputField,
    CustomButton,
    SimulationFormModal,
    SortBy,
    Pagination,
  },
  data() {
    return {
      simulations: [],
      simulationsCount: 1,
      itemsPerPage: 8,
      currentPage: this.$route.query.page || 1,
      sort: {
        param: "populationSize",
        order: "ASC",
      },
      modalVisible: false,
    };
  },
  async mounted() {
    this.countSimulations();
    this.getSimulationsList();
  },
  methods: {
    async getSimulationsList() {
      try {
        const response = await fetch("http://localhost:8080/simulations/my", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            param: this.sort?.param,
            isAsc: this.sort?.order === "ASC" ? true : false,
            offset: (this.currentPage - 1) * this.itemsPerPage,
            limit: this.itemsPerPage,
          }),
          credentials: "include",
        });

        if (response.ok) {
          this.simulations = await response.json();
        }
      } catch (error) {
        console.error("Failed to fetch simulations:", error);
      }
    },
    async countSimulations() {
      try {
        const response = await fetch(
          "http://localhost:8080/simulations/countSimulations",
          { credentials: "include" }
        );
        if (response.ok) {
          this.simulationsCount = await response.json();
        }
      } catch (error) {
        console.error("Failed to fetch simulations count:", error);
      }
    },
    onSimulationCreated() {
      this.simulationsCount += 1;
      this.getSimulationsList();
    },
  },
};
</script>

<style scoped>
.container {
  padding: 140px 50px 0 50px;
  width: 100%;
  margin-left: 100px;
  overflow-y: auto;
}

ul {
  list-style-type: none;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 25px;
}

li {
  margin-bottom: 25px;
}

.sim-wrapper {
  margin-top: 25px;
}

.add {
  position: fixed;
  top: 90vh;
  right: 50px;
  z-index: 997;
}

.top-wrapper {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.top-wrapper h1 {
  font-size: 36px;
  font-weight: 700;
  color: #333;
}

.top-wrapper .sort-by {
  margin-top: 18px;
}

.bottom-wrapper {
  margin-top: 30px;
  width: 100%;
  display: flex;
  justify-content: center;
  margin-bottom: 25px;
}
</style>
