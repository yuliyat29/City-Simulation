<template>
  <div class="container">
    <h1>User List:</h1>
    <!-- <user-list :users="users"/> -->
      <ul class="user-wrapper">
        <li v-for="user in users" :key="user.id" class="user-card">
          <user-card :user-name="user.name" :profile-photo="user.profilePhoto" :user-id="user.id"  :user-email="user.email"  @submitted="fetchAllUsers()"/>
        </li>
      </ul>
    <div class="bottom-wrapper">
      <pagination
        :total-items="this.userCount || 1"
        :items-per-page="itemsPerPage"
        @page-changed="this.currentPage = $event; fetchAllUsers()"
      />
    </div>
  </div>
</template>


<script>
import UserCard from "@/components/UserCard.vue";
import Pagination from "@/components/Pagination.vue";

export default {
  name: "UserListView",
  components: {
    UserCard,
    Pagination 
  },
  data() {
    return {
      users: [],
      userCount: 1,
      itemsPerPage: 16,
      currentPage: this.$route.query.page || 1
    }
  },
  // This is called by Vue every time the component is mounted.
  async mounted() {
    this.countUsers();
    this.fetchAllUsers();
    this.userCount += 1;

  },

  methods: {
    async fetchAllUsers() {
      try {
        const response = await fetch("http://localhost:8080/users/getAllExceptMe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            offset: (this.currentPage - 1) * this.itemsPerPage,
            limit: this.itemsPerPage,
          }),
          credentials: "include",
        });
        if (response.ok) {
          this.users = await response.json();
        }
      } catch (error) {
        console.error("Failed to fetch users:", error);
      }
    },
    async countUsers() {
      try {
        const response = await fetch("http://localhost:8080/users/countUsers",
          { credentials: "include" }
        );
        if (response.ok) {
          this.userCount = await response.json();
        }

      } catch (error) {
        console.error("Failed to fetch users count:", error);
      }
    },
    // onUserCreated() {
    //   this.userCount += 1;
    //   this.fetchAllUsers();
    // },
   }

  };

</script>


<style scoped>
.container {
  padding: 140px 50px;
  margin-left: 100px;
  overflow-y: auto;
  width: 100%;
}

.user-wrapper {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  width: 100%;
  list-style: none;
}

.user-card {
  margin-top: 30px;
}

.bottom-wrapper {
  margin-top: 30px;
  width: 100%;
  display: flex;
  justify-content: center;
  margin-bottom: 25px;
}
</style>