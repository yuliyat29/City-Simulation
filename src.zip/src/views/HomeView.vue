<template>
  <div class="home">
    <h1>{{ user ?  `Welcome back, ${user.name?.split(' ')[0]}!` : "Welcome to the SimUrbs!"}}</h1>

    <div>
      <h2> Statistics </h2>
      <div class="statistics-wrapper">
        <div class="stat-card">
          <p><i class="fas fa-user"></i> {{ userCount ? userCount+1 : 1 }}</p>
        </div>

        <div class="stat-card">
          <p><i class="fas fa-city"></i> {{ simulationNumber }}</p>
        </div>
      </div>
    </div>

    <div>
      <h2>Last simulations</h2>
      <div class="sim-wrapper">
        <ul>
          <li v-for="simulation in simulations" :key="simulation._id">
            <simulation-card
              :simulation="simulation"
              @submitted="getSimulationsList"
              @deleteSim="getSimulationsList"
            />
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import UserCard from "@/components/UserCard.vue";
import SimulationCard from "@/components/SimulationCard.vue";


export default {
  name: 'HomeView',
  components: {
    UserCard,
    SimulationCard,
  },
  data() {
    return {
      user: {},
      simulations: [],
      simulationNumber: 0,
      currentPage: 1,
      itemsPerPage: 4,
      limit: 4,
      offset: 0,
      sort: {
        param: "updateDate",
        order: "DESC",
      },
      userCount: 1,
    }

  },
  mounted() {
    this.getUser();
    this.getSimulationsList();
    this.countUsers();
    this.fetchSimulationData();
  },

  methods: {
    async getUser() {
      try {
        const res = await fetch('http://localhost:8080/users/getMe', {
          method: 'GET',
          credentials: 'include',
        });
        if (res.ok) {
          const user = await res.json();
          this.user = user;
        }
      } catch (error) {
        console.error('Failed to send request:', error);
      }
    },

    async getSimulationsList() {
      try {
        const response = await fetch("http://localhost:8080/simulations/my", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            param: this.sort?.param,
            isAsc: this.sort?.order === "ASC" ? true : false,
            offset: (this.currentPage - 1) * this.itemsPerPage,
            limit: this.itemsPerPage,
          }),
          credentials: "include",
        });

        if (response.ok) {
          this.simulations = await response.json();
        }
      } catch (error) {
        console.error("Failed to fetch simulations:", error);
      }
    },

    async countUsers() {
      try {
        const response = await fetch("http://localhost:8080/users/countUsers",
          { credentials: "include" }
        );
        if (response.ok) {
          this.userCount = await response.json();
        }

      } catch (error) {
        console.error("Failed to fetch users count:", error);
      }
    },

    async fetchSimulationData() {
            try {
                const response = await fetch('http://localhost:8080/simulations/countSimulations', {
                    method: "GET",
                    headers: { "Content-Type": "application/json" },
                    credentials: "include",
                });
                const data = await response.json();
                this.simulationNumber = data;
            }
            catch (error) {
                console.error('Error fetching simulation data:', error);
            }
        }

  },
}
</script>


<style scoped>
  .home {
    height: 100%;
    width: 100%;
    margin-top: 140px;
    margin-left: 150px;
    margin-right: 40px;
    overflow-y: auto;
  }

  .users-wrapper {
    margin-top: 20px;

  }

  .simulations-wrapper {
    margin-top: 20px;

  }

  ul {
  list-style-type: none;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 25px;
}

li {
  margin-bottom: 25px;
}

.sim-wrapper {
  margin-top: 25px;
}

.statistics-wrapper {
  display: flex;
  justify-content: space-evenly; 
  gap: 25px;
}

.stat-card {
  width: calc(50% - 100px);
  margin-top: 30px;
  padding: 50px 20px;
  font-size: 24px;
  background-color: #f5f5f5;
  border-radius: 15px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.stat-card p {
  display: flex;
  gap: 8px;
  justify-content: center;
}

h2 {
  margin-top: 50px;
  text-align: center;
  font-size: xx-large;
  color: #333;
}

.stat-card:hover {
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
  transition: 0.1s;
  transform: scale(1.05);
}
  
</style>
