<template>
  <div class="backdrop">
    <div class="container">
      <img src="@/assets/usi-logo.png" alt="Usi logo"/>
  
      <div class="wrapper">
        <p>Hello!</p>
        <p>You're almost there! Click the button below to sign in.</p>
        <custom-button @button-clicked="handleButtonClick" button-text="Login"/>
      </div>
    </div>
  </div>
</template>

<script>
import CustomButton from '@/components/CustomButton'

export default {
  components: {
    CustomButton
  },
  methods: {
    handleButtonClick() {
      window.location.href = "http://localhost:8080/oauth2/authorization/switch-edu-id";
    }
  },
};
</script>

<style scoped>
.backdrop {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  width: 100vw;
  z-index: 999;
  background-color: aliceblue;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
  max-width: 600px;
}

.wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 20px;
  border: 2px solid #ccc;
  border-radius: 10px;
  padding: 20px;
}

img {
  height: 200px;
}



</style>

