<template>
    <div class="profile">

        <div class="profile-details">
            <div class="avatar">
                <Avatar :imageUrl="profile.photo" size="200"/>
            </div>
            <div class="card">
                <div class="card-content">
                    <h2 class="card-title">Name</h2>
                    <div class="card-value">{{ profile.name }}</div>
                </div>
            </div>

            <div class="card">
                <div class="card-content">
                    <h2 class="card-title">Total Simulations</h2>
                    <div class="card-value">{{ simulation.number }}</div>
                </div>
            </div>

            <div class="card">
                <div class="card-content">
                    <h2 class="card-title">E-mail</h2>
                    <div class="card-value">{{ profile.email }}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Avatar from '@/components/Avatar.vue';

export default {
    components: {
        Avatar
    },
    data() {
        return {
            userId: this.$route.params.userId,
            profile: {
                name: '',
                email: '',
                photo: ''
            },
            simulation: {
                number: ''
            }
        };
    },
    mounted() {
    this.creatUser().then(response => {
        if (response.ok) {
            this.fetchProfileData().then(() => {
                this.fetchSimulationData();
            });
        }
    });
},
    methods: {
        async creatUser() {
            try {
                const response = await fetch('http://localhost:8080/users/createUser', { credentials: "include" });
                return response;
            } catch (error) {
                console.error('Error creating a new user:', error);
            }
        },
        async fetchProfileData() {
            try {
                const response = await fetch(`http://localhost:8080/users/${this.userId}`, { credentials: "include" });

                const data = await response.json();

                this.profile.name = data.name;
                this.profile.email = data.email;
                this.profile.photo = data.profilePhoto;

            } catch (error) {
                console.error('Error fetching profile data:', error);
            }
        },
        async fetchSimulationData() {
            try {
                console.log(this.profile.email)
                const response = await fetch('http://localhost:8080/simulations/countUserSimulations', {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: this.profile.email,
                    credentials: "include",
                });
                const data = await response.json();
                this.simulation.number = data;
            }
            catch (error) {
                console.error('Error fetching simulation data:', error);
            }
        }
    }
};
</script>

<style scoped>
.profile {
    display: flex;
    flex-direction: row;
    align-items: left;
    width: 100%;
    margin-left: 150px;
    margin-top: 140px;
}

.profile-details {
    display: flex;
    flex-direction: column;
    margin-top: 20px;
}

.avatar {
    margin-bottom: 20px;
}
.avatar:hover {
  box-shadow: none;
}

.card {
    margin: 20px;
    background-color: #fff;
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.card-content {
    padding: 20px;
}

.card-title {
    font-size: 18px;
    margin-bottom: 10px;
}

.card-value {
    font-size: 14px;
    font-weight: bold;
}
</style>