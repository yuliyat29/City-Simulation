<template>
  <div id="container" style="position: relative">
    <Simulation v-if="simulation" :simulation="simulation" />
    <div v-else>Loading...</div>
    
    <!-- Replace with error component -->
    <div v-if="error" class="errorMessage">{{ error }}</div> 

  </div>
</template>

<script>
import Simulation from "@/components/Simulation.vue";

export default {
  name: "SharedSimulationView",
  components: {
    Simulation,
  },

  data() {
    return {
      simulation: {},
      modalVisible: false,
      simulationId: this.$route.params.simulationId,
      error: null,
    };
  },
  mounted() {
    this.getSimulation();
  },
  methods: {
    async getSimulation() {
      try {
        const res = await fetch(`http://localhost:8080/simulations/shared/${this.simulationId}`);
        if (!res.ok) {
          throw new Error("Failed to fetch simulation");
        }
        const simulation = await res.json();
        this.simulation = simulation;
        this.$store.commit("setSimulationName", simulation.simulationName);
      } catch (error) {
        console.error("Error fetching simulation by ID:", error);
        if (error) {
          this.error = "Simulation not found";
        }
        throw error;
      }
    },
    clearSimulationName() {
      this.$store.commit("clearSimulationName");
    },
    beforeRouteLeave(to, from, next) {
      this.clearSimulationName();
      next();
    },
  },
};
</script>

<style scoped>
#container {
  width: 100%;
  height: 100%;
}

.circleIconButton {
  position: absolute;
  bottom: 20px;
  right: 20px;
}

h1 {
  text-align: center;
}
.errorMessage {
  text-align: center;
  color: red;
  font-size: 5em;
  margin-top: 200px;
}
</style>
