# User Story 2.1: as a user, I can simulate a city using the closed model.

## Description
As a user, I can simulate a city using the open model, for which the city size is endogenous.
In other word, the user can set the size of the city and all the parameters will be computed.
The basic simulation parameters available to the user are the transportation cost and the monthly income. All the
other parameters are advanced and they cannot be modified by the user, though the UI should show their
value. The values for the parameters must be limited on specific ranges, configurable in the backend.

## Implementation
- [ ] User can simulate an open model (endogenous) city
- [ ] The user can input a fixed size version of the city
    - [ ] The variables are computed using this size and the formula provided
    - [ ] user can change the transportation cost
    - [ ] user can change the monthly income
- [ ] all parameter, changeable or not, must be seen in the UI
    - [ ] parameters must have a unit of measure
    - [ ] parameters should have specific ranges

## Dependency

## Changed classes

## Note
Update the UI
Add field to the model
Remember to consider the shared city functionality

## Q&A


# User Story 2.2: as a user, I can simulate a city using the closed model.

## Description
In the closed model, the target population is an available parameter.
This mean that if a user change the maximum population all the parameter using that value should
be computed again and so the simulation should react accordingly

For this user story, you’re supposed to
work with the instructor to solve the model as from the specific requirement document that will be released
on April 19. You will need to finish User story 1 before starting this. Beware: this is very difficult and you
need approval from the instructor if you want to implement this user story.

## Implementation
- [ ] User can simulate a closed model city
- [ ] The user can input a maximum population parameter for the city
    - [ ] The variables are computed using this value and the formula provided
- [ ] all parameter, changeable or not, must be seen in the UI
    - [ ] parameters must have a unit of measure
    - [ ] parameters should have specific ranges
    - [ ] non inputed parameters should remain in their ranges if the input changes

## Dependency

## Changed classes
add fields in the model

## Note
non inputed parameters should remain in their ranges if the input changes
Update the UI
Add field to the model
Remember to consider the shared city functionality

## Q&A
generic HELP like suggested


# User Story 2.3: As a user, I can specify changes to the transportation cost for certain parcels in a city

## Description
This task tells us to implement a way to reduce costs of public transportation depending on certain zones of the city,
for example the Central Business District (CBD, a.k.a. central zone). It requires us to understand how the open
(and possibly closed) city models operate.

## Implementation
- [ ] Implementing Transportation
  - [ ] Creating Transportation class
  - [ ] Create fields for transportation costs
- [ ] Implementing Zones
  - [ ] Create fields for grouping up blocks to create Zones
  - [ ] Relate zones and the costs of the transportation (modifiers)
- [ ] User can modify Simulation to add the costs for transportation
  - [ ] Add in the frontend the possibility of modifying transportation cost
  - [ ] Also add in the frontend the possibility of specifying which zones have their costs modified
- [ ] User can modify the range of the zones

## Dependency
User Story 1 and 2: City simulation with open (and closed) model.

User Story 9: Comparison mode

## Changed classes
Most of the Simulation classes. Maybe adding a new class for Transportation, that specifies the types, the costs and
the range in which they operate. Block class could also be used to create zones, which are a group of blocks located
in a certain part of the city

## Note
This feature introduces the concept of transportation and the ability to modify its costs based on zones, modifying the
Simulation further

## Q&A: Questions to the professor/TAs and their respective answer
Question to do to the TA/Professor and respective answers

Would it be better to implement the zones inside the Block class or create a separate class that is a map of Blocks?

For transportation, are there different types (like taxis, trains) or for the sake of simplicity we'll just have one
type?


# User Story: 2.4. As a user , I can specify a global upper limit for construction costs.

## Description
The user can set an overall upper limit for construction costs.
The construction cost is based on two things: land cost and building height (number of floors).
When we set a new upper limit for construction, the only thing that will change for
the building will be the height of the building, that is, the number of floors.
We also know how many people are in the building. In other words, the construction
cost of buildings above the new upper limit will be changed and their costs will be
determined as the new upper limit, and since the building will remain in the same
location, we will change the number of floors. When we reduce the number of floors,
the people living on those floors will basically be kicked out of the simulation.


## Implementation
- [ ] For Backend.
  - [ ] Write a function in simulation generation class set new upper limit for construction costs
    - [ ] in this function set population size in case some people when kicked out from city
-[ ] For Frontend.
  -[ ] Give a chance to user to set new upper limit for entire city
## Dependency
Similar implementation as user story 5 only difference is doing this in specific zone

## Changed classes
Doesnt need to change classes so far.

## Note
Use the notion for user story 5

## Q&A
Question to do to the TA/Professor and respective answers


# User Story 2.5: As a user, I can specify a local limits for construction costs.

## Description
The user can set a general upper limit for construction costs in a specific area.
The construction cost is based on two things: land cost and building height
(number of floors). When we set a new upper limit for construction, the only thing that
will change for the building will be the height of the building, that is, the number of
floors. We also know how many people are in the building. In other words, the
construction cost of buildings above the new upper limit will be changed and their
costs will be determined as the new upper limit, and since the building will remain
in the same location, we will change the number of floors. When we reduce the number
of floors, the people living on those floors will basically be kicked out of the
simulation.

## Implementation
- [ ] For Backend.
  - [ ] Write a function in simulation generation class set new upper limit for construction costs in specific area
    - [ ] in this function set population size in case some people when kicked out from city
-[ ] For Frontend.
  -[ ] Give a chance to user to set new upper limit for entire city
## Dependency
Similar implementation as user story 4 only difference is doing this in entire zone

## Changed classes
Doesnt need to change classes so far.

## Note
Dont start this user story before have done with user story 4

## Q&A
Question to do to the TA/Professor and respective answers

# User Story 2.6: As a user , I can specify a global limit for rent

## Description
Users should be able to set a maximum limit on the monthly rent per square meter for a given city.
This ensures that rents remain within certain bounds, as mandated by legislation or user preference.


## Implementation
-[ ] Develop a feature to allow users to specify a global limit for rent.
  -[ ] Implement backend logic to enforce the specified rent limit.
  -[ ] Integrate the rent limit feature with existing simulation parameters.
  -[ ] Test the feature to ensure it functions as expected.

## Dependency
The operation will be same as user story 7 only changes will be affected area size.

## Changed classes
classes that will are have been changed

## Note
This feature introduces a new type of simulation parameter that users
can adjust to control rent limits within the simulation environment. It aims to provide flexibility and realism in simulating rental markets.
## Q&A
Question to do to the TA/Professor and respective answers

# User Story 2.7:  As a user, I can specify local limits for rent

## Description
UUsers should have the ability to set local limits for rent in specific areas of the
city, such as areas designated for social housing. This allows for more granular control over rental rates within different zones of the city.

## Implementation
-[ ]  Develop a feature to enable users to specify local limits for rent.
  -[ ] Define the criteria for identifying areas within the city where local rent limits apply (e.g., social housing zones).
  -[ ] Implement backend logic to enforce local rent limits within designated areas.
  -[ ] Integrate the local rent limit feature with existing simulation parameters and city zoning data.
  -[ ] Test the feature to ensure it accurately enforces local rent limits and interacts correctly with other simulation components.

## Dependency
The operation will be same as user story 6 only changes will be affected area size is entire city.

## Changed classes
classes that will are have been changed

## Note
This feature introduces a new type of simulation parameter that allows users to set local rent limits
for specific areas within the city. It enhances the simulation's realism by reflecting the diversity of rental markets within different zones.
## Q&A
Question to do to the TA/Professor and respective answers



# User Story: 2.8 As a user, I can specify zoning restrictions for the city

## Description
With the concept of zones, we want to add specific restrictions related to a group of blocks, such as in which ones
there is the presence of parks, forests or water.

## Implementation
- [ ] Add a new parameter into simulation related to zone restrictions
  - [ ] specify the types of blocks within said zone
    - [ ] add Forest type Blocks

## Dependency
User Story 9: Comparison mode

User Story 3: Transportation within zones

User Story 1,2: Open (and closed) city model

## Changed classes
Simulation, Zones, Blocks

## Note
This feature introduces a new type of simulation parameter that users can adjust, in this case the restrictions of the
zones and what they contain

## Q&A
Should there be only restrictions or also permissions related to Block types?


# User Story 2.9: as a user, I can edit the simulation parameters of a city in a comparison mode.
In comparison mode, when the new simulation is generated, the visualization shows also statistics about
how the results of the simulation changed, e.g., the difference in the resulting population or the average
rent per month. When inspecting a building block / parcel, the user can also see which parameters changed
(e.g., if the number of floors has changed).

## Description
brief description of the task.

## Implementation
- [ ] implement a comparison mode, city should not change with new values
- [ ] implement the visualization of both the statistics, the one after the change and those before it
  - [ ] the statistics of the whole city should be visible is no block are selected
  - [ ] the statistics of a block should be visible if a block is selected

## Dependency
All, in particular the one that change some parameters

## Changed classes
frontend...

## Note
city should not be changed by others if private

## Q&A
Q: for what extend other users can see city statistics?

Q: other representation other than simple numbers?