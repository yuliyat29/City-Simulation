package ch.usi.inf.bsc.sa4.lab02spring.service;


import ch.usi.inf.bsc.sa4.lab02spring.model.User;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@DisplayName("The User Service")
public class UserServiceTests {

    @Autowired
    UserService userService;

    @DisplayName("After getting user by ID")
    @Nested
    class WhenGettingUserById {

        User user;

        @BeforeEach
        void setUp() {
            user = userService.createUser("John Doe", "john.doe@example.com");
        }

        @AfterEach
        void tearDown() {
            userService.cleanAllUsers();
        }

        @DisplayName("GET /users/{userId} - User Found by ID")
        @Test
        void testGetById_UserFoundById() {
            String userId = user.getId().toString();
            Optional<User> foundUser = userService.getById(userId);
            assertTrue(foundUser.isPresent(), "User should be found by ID");
            assertEquals(user, foundUser.get(), "Found user should match expected user");
        }

        @DisplayName("GET /users/{userId} - User Not Found by ID")
        @Test
        void testGetById_UserNotFoundById() {
            String userId = "nonexistentId";
            Optional<User> foundUser = userService.getById(userId);
            assertTrue(foundUser.isEmpty(), "User should not be found by nonexistent ID");
        }

        @DisplayName("GET /users/{userId} - User Not Found by Invalid ID Format")
        @Test
        void testGetById_UserNotFoundByInvalidIdFormat() {
            String invalidId = "invalidObjectIdFormat";
            Optional<User> foundUser = userService.getById(invalidId);
            assertTrue(foundUser.isEmpty(), "User should not be found by invalid ID format");
        }
    }

    @DisplayName("After getting user by email")
    @Nested
    class WhenGettingUserByEmail {

        User user;
        @BeforeEach
        void setUp() {
            user = userService.createUser("John Doe", "john.doe@example.com");
        }

        @AfterEach
        void tearDown() {
            userService.cleanAllUsers();
        }

        @DisplayName("GET /users/getByEmail - User Found by Email")
        @Test
        void testGetByEmail_UserFoundByEmail() {
            String email = user.getEmail();
            Optional<User> foundUser = userService.getByEmail(email);
            assertTrue(foundUser.isPresent(), "At least one user should be found by email");
        }

        @DisplayName("GET /users/getByEmail - User Not Found by Email")
        @Test
        void testGetByEmail_UserNotFoundByEmail() {
            String email = "nonexistent@example.com";
            Optional<User> foundUser = userService.getByEmail(email);
            assertTrue(foundUser.isEmpty(), "User should not be found by nonexistent email");
        }

        @DisplayName("GET /users/getByEmail - User Not Found by Invalid Email Format")
        @Test
        void testGetByEmail_UserNotFoundByInvalidEmailFormat() {
            String invalidEmail = "invalid@example.com";
            Optional<User> foundUser = userService.getByEmail(invalidEmail);
            assertTrue(foundUser.isEmpty(), "User should not be found by invalid email format");
        }
    }

    @Nested
    @DisplayName("Try to clear users when empty")
    class ClearAllEmpty {
        @DisplayName("Clear when Empty")
        @Test
        public void testClearAllEmpty() {
            userService.cleanAllUsers();

            List<User> allUsers = userService.getAll();
            assertTrue(allUsers.isEmpty(), "Repository should be empty after cleanAllUsers()");
        }
    }

    @Nested
    @DisplayName("Try to clear users")
    class ClearAllUsers {

        @BeforeEach
        void setUp() {
            userService.createUser("John Doe", "john.doe@example.com");

            userService.createUser("Jane Smith", "jane.smith@example.com");

            userService.createUser("Alice Johnson", "alice.johnson@example.com");
        }

        @DisplayName("Clear Users")
        @Test
        public void testClearAllUsers() {
            userService.cleanAllUsers();

            List<User> allUsers = userService.getAll();
            assertTrue(allUsers.isEmpty(), "Repository should be empty after cleanAllUsers()");
        }
    }

    @Nested
    @DisplayName("Trying to delete User")
    class DeletingUser {

        User user1;
        User user2;
        User user3;

        @BeforeEach
        void setUp() {

           user1 = userService.createUser("John Doe", "john.doe@example.com");

           user2 = userService.createUser("Jane Smith", "jane.smith@example.com");

           user3 = userService.createUser("Alice Johnson", "alice.johnson@example.com");

        }

        @AfterEach
        void tearDown() {
            userService.cleanAllUsers();
        }

        @DisplayName("Deleting a specific user")
        @Test
        public void testDeletingUser() {
            userService.deleteUser(user1);

            List<User> allUsers = userService.getAll();
            boolean userExists1 = allUsers.stream().anyMatch(user ->
                    user.equals(user1)
            );
            boolean userExists2 = allUsers.stream().anyMatch(user ->
                    user.equals(user2)
            );
            boolean userExists3 = allUsers.stream().anyMatch(user ->
                    user.equals(user3)
            );

            assertFalse(userExists1, "User1 is not contained in the list of users");
            assertTrue(userExists2, "User2 is contained in the list of users");
            assertTrue(userExists3, "User3 is contained in the list of users");
        }

        @DisplayName("Deleting a newly created user")
        @Test
        public void testDeleteNewlyCreated() {
            User newUser = userService.createUser("New User", "newuser@new");
            userService.deleteUser(newUser);

            List<User> allUsers = userService.getAll();
            boolean userExists1 = allUsers.stream().anyMatch(user ->
                    user.equals(user1)
            );
            boolean userExists2 = allUsers.stream().anyMatch(user ->
                    user.equals(user2)
            );
            boolean userExists3 = allUsers.stream().anyMatch(user ->
                    user.equals(user3)
            );
            boolean userExistsNew = allUsers.stream().anyMatch(user ->
                    user.equals(newUser)
            );

            assertTrue(userExists1, "User1 is contained in the list of users");
            assertTrue(userExists2, "User2 is contained in the list of users");
            assertTrue(userExists3, "User3 is contained in the list of users");
            assertFalse(userExistsNew, "NewUser is not contained in the list of users");
        }

        @DisplayName("Deleting a non-existed user")
        @Test
        public void testDeleteUserNonExistent() {
            User nonUser = userService.createUser("None User", "noneUser@none");
            userService.deleteUser(nonUser);

            List<User> allUsers = userService.getAll();
            boolean userExists1 = allUsers.stream().anyMatch(user ->
                    user.equals(user1)
            );
            boolean userExists2 = allUsers.stream().anyMatch(user ->
                    user.equals(user2)
            );
            boolean userExists3 = allUsers.stream().anyMatch(user ->
                    user.equals(user3)
            );
            boolean userNone = allUsers.stream().anyMatch(user ->
                    user.equals(nonUser)
            );

            assertTrue(userExists1, "User1 is contained in the list of users");
            assertTrue(userExists2, "User2 is contained in the list of users");
            assertTrue(userExists3, "User3 is contained in the list of users");
            assertFalse(userNone, "None is not contained in the list of users");
        }

    }

    @DisplayName("before creating a user")
    @Nested
    class  beforeUserCreation {
        User newUser;

        @DisplayName(" user should be empty")
        @Test
        public void testEmptyUser(){
            assertNull(newUser);
        }
    }

    @DisplayName(" after creating a new user ")
    @Nested
    class WhenCreatingANewUser {

        User newUser;

        String fullName;
        String email;

        @BeforeEach
        void setup() {
            fullName = "John Doe";
            email = "john.doe@example.com";
            this.newUser = userService.createUser(fullName, email);
        }

        @AfterEach
        void tearDown() {
            userService.cleanAllUsers();
        }

        @DisplayName(" the new user should be non null")
        @Test
        public void testNotNull() {
            assertNotNull(this.newUser);
        }

        @DisplayName(" the new user should have specified fullName")
        @Test
        public void testFullName() {
            assertEquals(fullName, newUser.getName() );
        }

        @DisplayName(" the new user should have specified email")
        @Test
        public void testEmail() {
            assertEquals(email, newUser.getEmail() );
        }

        @DisplayName(" the new user should have empty profilePhoto")
        @Test
        public void testProfilePhoto(){
            assertEquals("", newUser.getProfilePhoto() );
        }

        @DisplayName(" the new user should be contained in the list of users")
        @Test
        public void testUserContained() {
            List<User> allUsers = userService.getAll();
            var userExists = allUsers.stream().anyMatch(user ->
                    user.equals(newUser)
            );
            assertTrue(userExists, "new user is not contained in the list of users");
        }
    }

    @DisplayName("After getting all users except me when")
    @Nested
    class WhenGotAllExceptMeButEmpty  {
        int sizeForUser = 1;

        @DisplayName("list is empty")
        @Test
        public void testGetAllExceptMeOnEmptyList() {
            String email = "tyshcn@usi.ch";
            List<User> allUsers = userService.getAllExceptMe(email,sizeForUser,0);

            assertEquals(0, allUsers.size());
        }
    }

    @DisplayName("After getting all users except me")
    @Nested
    class WhenGotAllExceptMe {
        int sizeForUser = 5;

        @BeforeEach
        void setUp() {
            userService.createUser("Michael Brown", "michael@example.com");
            userService.createUser("Sally Brown", "sally@example.com");
        }

        @AfterEach
        void tearDown() {
            userService.cleanAllUsers();
        }

        @DisplayName("In the list of users")
        @Test
        public void testAllUsers() {
            String email = "tyshcn@usi.ch";
            List<User> allUsers = userService.getAllExceptMe(email,sizeForUser,0);
            User me = new User("Nikita Tyshchyk", "tyshcn@usi.ch", "");

            boolean userExists = allUsers.stream().anyMatch(user ->
                    user.equals(me)
            );

            assertEquals(2, allUsers.size());
            assertFalse(userExists, "Actually me exists in the list");
        }

        @DisplayName("In the list of users where I am")
        @Test
        public void testAllUsersExceptMe() {
            String email = "tyshcn@usi.ch";
            User me = userService.createUser("Nikita Tyshchyk", "tyshcn@usi.ch");
            List<User> allUsers = userService.getAllExceptMe(email, sizeForUser,0);

            boolean userExists = allUsers.stream().anyMatch(user ->
                    user.equals(me)
            );

            assertEquals(2, allUsers.size());
            assertFalse(userExists, "Actually me exists in the list");
        }

        @DisplayName("Test if there really exist user")
        @Test
        public void testUserExists() {
            String email = "tyshcn@usi.ch";
            List<User> allUsers = userService.getAllExceptMe(email,sizeForUser,0);
            User user = allUsers.get(1);

            assertEquals("sally@example.com", user.getEmail());
        }

    }

    @DisplayName("After getting empty list")
    @Nested
    class WhenGotAllEmpty {
        @DisplayName("Should return empty")
        @Test
        public void testUsersEmpty() {
            userService.cleanAllUsers();
            List<User> allUsers = userService.getAll();
            assertEquals(0, allUsers.size(), "Expected empty users");
        }
    }

    @DisplayName("After getting allUsers")
    @Nested
    class WhenGotAllUsers {
        @BeforeEach
        void setUp() {

            userService.createUser("John Doe", "john.doe@example.com");

            userService.createUser("Jane Smith", "jane.smith@example.com");

            userService.createUser("Alice Johnson", "alice.johnson@example.com");

        }

        @DisplayName("All existing users should be contained in the list of users")
        @Test
        public void testUsersContained() {
            List<User> allUsers = userService.getAll();
            assertEquals(3, allUsers.size(), "Expected number of users is met");
        }

        @DisplayName("The new user should be contained in the list of users")
        @Test
        public void testNewUserContained() {
            User newUser = userService.createUser("New User", "new.user@example.com");

            List<User> allUsers = userService.getAll();
            boolean userExists = allUsers.stream().anyMatch(user ->
                    user.equals(newUser)
            );
            assertTrue(userExists, "New user is contained in the list of users");
        }

    }

    @DisplayName("After user uploaded picture")
    @Nested
    class UserUploadProfilePic {

        @BeforeEach
        void setUp() {
            User user1 = new User("Example User","example.example@example.com", "");
            userService.storeUser(user1);

            User user2 = new User("Test User","test.test@test.com", "https://exampl.com/old.jpg");
            userService.storeUser(user2);

        }

        @AfterEach
        void tearDown() {
            userService.cleanAllUsers();
        }

        @DisplayName("User should be able to upload his profile picture")
        @Test
        public void testUploadProfilePic() {
            User updatedUser1 = userService.uploadProfilePhoto("https://example.com/profile_picture.jpg", "example.example@example.com");
            User updatedUser2 = userService.uploadProfilePhoto("https://test.com/new.jpg", "test.test@test.com");
            Optional<User> updatedUserOptional = Optional.ofNullable(userService.uploadProfilePhoto("https://example.com/profile_picture.jpg", "example.example@example.com"));

            assertTrue(updatedUserOptional.isPresent());
            assertNotNull(updatedUser1);
            assertEquals("example.example@example.com", updatedUser1.getEmail());
            assertEquals("https://example.com/profile_picture.jpg", updatedUser1.getProfilePhoto());
            assertNotNull(updatedUser2);
            assertEquals("test.test@test.com", updatedUser2.getEmail());
            assertEquals("https://test.com/new.jpg", updatedUser2.getProfilePhoto());

            assertThrows(NoSuchElementException.class, () -> {
                userService.uploadProfilePhoto("https://example.com/profile_picture.jpg", "nonexisting.user@example.com");
            });
        }

    }

    @DisplayName("after counting all users except given")
    @Nested
    class AfterCountingAllUsers {

        @BeforeEach
        void setUp() {

            userService.createUser("John Doe", "john.doe@example.com");

            userService.createUser("Jane Smith", "jane.smith@example.com");

            userService.createUser("Alice Johnson", "alice.johnson@example.com");

        }

        @DisplayName("should count users except given")
        @Test
        public void allUsersCounted() {
            long count1 = userService.countAllUsersExceptMe("john.doe@example.com");
            long count2 = userService.countAllUsersExceptMe("test@com");

            assertEquals(2, count1);
            assertEquals(3, count2);

        }
    }
}
