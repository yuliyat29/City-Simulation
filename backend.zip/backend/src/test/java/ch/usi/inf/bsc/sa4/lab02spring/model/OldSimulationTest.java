package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;


class OldSimulationTest {

    @Mock
    private ObjectId mockObjectId;

    @Test
    void getParentId() {
        // Initialize Mockito annotations
        MockitoAnnotations.openMocks(this);

        // Mock data
        ObjectId parentId = new ObjectId();
        double wage = 1000.0;
        double transportationCost = 200.0;
        double constructionCostLimit = 50000.0;
        double rentLimit = 10000.0;
        String simulationName = "Test Simulation";
        String authorEmail = "test@example.com";
        boolean isPublic = true;
        String simulationPicture = "https://example.com/picture.jpg";
        Date lastUpdateDate = new Date();

        // Create an instance of OldSimulation
        OldSimulation oldSimulation = new OldSimulation(
                mockObjectId, parentId, wage, transportationCost, constructionCostLimit, rentLimit,
                simulationName, authorEmail, isPublic, simulationPicture, lastUpdateDate
        );

        // Test the getParentId method
        assertEquals(parentId, oldSimulation.getParentId());
    }
}
