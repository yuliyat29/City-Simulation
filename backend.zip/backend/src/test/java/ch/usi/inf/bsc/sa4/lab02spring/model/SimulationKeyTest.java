package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SimulationKeyTest {

    @Test
    public void testConstructorAndGettersForX() {
        SimulationKey key = new SimulationKey(3, 4);
        assertEquals(3, key.getX(), "Constructor or getX method failed");
    }

    @Test
    public void testConstructorAndGettersForY() {
        SimulationKey key = new SimulationKey(3, 4);
        assertEquals(4, key.getY(), "Constructor or getY method failed");
    }

    @Test
    public void testSetX() {
        SimulationKey key = new SimulationKey(3, 4);
        key.setX(7);
        assertEquals(7, key.getX(), "setX method failed");
    }

    @Test
    public void testSetY() {
        SimulationKey key = new SimulationKey(3, 4);
        key.setY(8);
        assertEquals(8, key.getY(), "setY method failed");
    }

    @Test
    public void testEqualsSameObject() {
        SimulationKey key1 = new SimulationKey(3, 4);
        assertEquals(key1, key1, "equals method failed for same object");
    }

    @Test
    public void testEqualsDifferentObjectSameValues() {
        SimulationKey key1 = new SimulationKey(3, 4);
        SimulationKey key2 = new SimulationKey(3, 4);
        assertEquals(key1, key2, "equals method failed for different objects with same values");
    }

    @Test
    public void testEqualsDifferentObjectDifferentValues() {
        SimulationKey key1 = new SimulationKey(3, 4);
        SimulationKey key2 = new SimulationKey(4, 5);
        assertFalse(key1.equals(key2), "equals method failed for different objects with different values");
    }

    @Test
    public void testEqualsNull() {
        SimulationKey key = new SimulationKey(3, 4);
        assertFalse(key.equals(null), "equals method failed for null comparison");
    }

    @Test
    public void testEqualsDifferentClass() {
        SimulationKey key = new SimulationKey(3, 4);
        assertFalse(key.equals(new Object()), "equals method failed for different class comparison");
    }

    @Test
    public void testHashCodeConsistency() {
        SimulationKey key = new SimulationKey(3, 4);
        int initialHashCode = key.hashCode();
        assertEquals(initialHashCode, key.hashCode(), "hashCode method is not consistent");
    }

    @Test
    public void testHashCodeEqualObjects() {
        SimulationKey key1 = new SimulationKey(3, 4);
        SimulationKey key2 = new SimulationKey(3, 4);
        assertEquals(key1.hashCode(), key2.hashCode(), "hashCode method failed for equal objects");
    }

    @Test
    public void testHashCodeUnequalObjects() {
        SimulationKey key1 = new SimulationKey(3, 4);
        SimulationKey key2 = new SimulationKey(4, 5);
        assertNotEquals(key1.hashCode(), key2.hashCode(), "hashCode method failed for unequal objects");
    }

    @Test
    public void testCompareToEqualObjects() {
        SimulationKey key1 = new SimulationKey(3, 4);
        SimulationKey key2 = new SimulationKey(3, 4);
        assertEquals(0, key1.compareTo(key2), "compareTo method failed for equal objects");
    }

    @Test
    public void testCompareToDifferentObjects() {
        SimulationKey key1 = new SimulationKey(3, 4);
        SimulationKey key2 = new SimulationKey(4, 5);
        assertNotEquals(0, key1.compareTo(key2), "compareTo method failed for different objects");
    }

    @Test
    public void testCompareToOrdering() {
        SimulationKey key1 = new SimulationKey(3, 4);
        SimulationKey key2 = new SimulationKey(4, 5);
        assertNotSame(key1, key2, "compareTo method does not provide consistent ordering");
    }
}

