package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;


@DisplayName("Simulation Tests")
class SimulationTest {

    @ParameterizedTest
    @DisplayName("Test Simulation constructor with valid parameters")
    @CsvSource({
            // Valid parameters
            "12000, 5000, 'Valid Simulation', 'author@example.com', true, 'picture.png'",
            "14000, 2000, 'Another valid Simulation', 'author2@example.com', false, 'picture.raw'",
            // Corner cases
            // Lower bound
            "1, 1, 'abc', 'a@example.com', true, 'a.png'",
            // Higher bound
            "100000, 100000, 'qwertzuiorsdfghjklyxcvbnmqaywsxedcrfvtgbzhnujmikol', 'Valid@example.com', false, 'picture.png'",
    })
    void testSimulationConstructor_ValidParameters(int wage, int transportationCost,
                                                   String simulationName, String authorEmail, boolean isPublic,
                                                   String simulationPicture) {
        // Act and assert
        Simulation validSimulation = new Simulation(
                wage,
                transportationCost,
                10000,
                5000,
                simulationName,
                authorEmail,
                isPublic,
                simulationPicture,
                null,
                null
        );
        assertNotNull(validSimulation, "Expected a valid Simulation object, but it was null");
        assertEquals(transportationCost, validSimulation.getCity().getTransportationCost(),
                "Expected transportation cost: " + transportationCost + ", but got: " + validSimulation.getCity().getTransportationCost());
        assertEquals(wage, validSimulation.getCity().getWage(),
                "Expected wage: " + wage + ", but got: " + validSimulation.getCity().getWage());
        assertEquals(simulationName, validSimulation.getSimulationName(),
                "Expected simulation name: " + simulationName + ", but got: " + validSimulation.getSimulationName());
        assertEquals(authorEmail, validSimulation.getAuthorEmail(),
                "Expected author email: " + authorEmail + ", but got: " + validSimulation.getAuthorEmail());
        assertEquals(isPublic, validSimulation.isPublic(),
                "Expected is public: " + isPublic + ", but got: " + validSimulation.isPublic());
        assertEquals(simulationPicture, validSimulation.getSimulationPicture(),
                "Expected simulation picture: " + simulationPicture + ", but got: " + validSimulation.getSimulationPicture());
    }

    @ParameterizedTest
    @DisplayName("Test Simulation constructor with invalid parameters")
    @CsvSource({
            // Invalid parameters
            "-1000, -50000, '', '', true, ''",
            "-20000000, 20000000, 'ConsoleLogLasagnaIfYouKnowThisMEMEYouKnowWHoIAmINeedALongEnoughString', '', false, ''",
            // null case
            "0, 0, null, null, false, null",
            // negative case
            "-1, -1, null, null, false, null",
            // Corner cases
            // Lower bound
            "0, 0, 'Invalid Simulation', '', true, '.png'",
            "0, 0, 'Invalid Simulation', null, true, '.png'",
            // Higher bound
            "100001, 100001, 'AllWorkAndNoPlayMakesJackADullBoyHiWritingTestIsFun', 'author@example.com', true, 'picture.png'",
    })
    void testSimulationConstructor_InvalidParameters(int wage, int transportationCost,
                                                     String simulationName, String authorEmail, boolean isPublic,
                                                     String simulationPicture) {
        // Assert
        assertThrows(IllegalArgumentException.class, () ->
                        new Simulation(
                                wage,
                                transportationCost,
                                10000,
                                5000,
                                simulationName,
                                authorEmail,
                                isPublic,
                                simulationPicture,
                                null,
                                null
                        ),
                "Expected IllegalArgumentException for invalid parameters");
    }


    /**
     * Verifies that calling the makePublic() method does not change the value of isPublic if it is already true,
     * and calling makePrivate() does not change the value if it is already false.
     * Also, verifies that calling makePublic() changes the value to true if it is false,
     * and calling makePrivate() changes the value to false if it is true.
     *
     * @param isPublicValue  Initial value of isPublic.
     */
    @ParameterizedTest
    @CsvSource({
            "true",
            "false"
    })
    void shareBehaviorTest(boolean isPublicValue) {
        // Define test data
        int wage = 1200;
        int transportationCost = 2000;
        String simulationName = "Simulation";
        String authorEmail = "author@example.com";
        String simulationPicture = "picture.jpg";
        Date createDate = new Date();
        Date updateDate = new Date();

        Simulation generation = new Simulation(
                wage,
                transportationCost,
                10000,
                5000,
                simulationName,
                authorEmail,
                isPublicValue,
                simulationPicture,
                null,
                null
        );

        // isPublic is true
        if (isPublicValue) {
            // makePublic() from true to true
            generation.makePublic();
            assertTrue(generation.isPublic(), "Expected isPublic to remain true after calling makePublic()");

            // makePrivate() from true to false
            generation.makePrivate();
            assertFalse(generation.isPublic(), "Expected isPublic to be false after calling makePrivate()");

        } else { // isPublic is false
            //makePrivate() from false to false
            generation.makePrivate();
            assertFalse(generation.isPublic(), "Expected isPublic to remain false after calling makePrivate()");

            // makePublic() from false to true
            generation.makePublic();
            assertTrue(generation.isPublic(), "Expected isPublic to be true after calling makePublic()");
        }
    }
}


