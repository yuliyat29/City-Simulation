package ch.usi.inf.bsc.sa4.lab02spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab02SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
