package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import ch.usi.inf.bsc.sa4.lab02spring.model.User;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;

class GetUserDTOTests {


    @Test
    void testConstructor2() {
        User user = new User("Name", "jane.doe@example.org", "alice.liddell@example.org");
        user.setId(ObjectId.get());
        GetUserDTO actualGetUserDTO = new GetUserDTO(user);
        assertEquals("Name", actualGetUserDTO.name());
        assertEquals("alice.liddell@example.org", actualGetUserDTO.profilePhoto());
        assertEquals("jane.doe@example.org", actualGetUserDTO.email());
    }
}
