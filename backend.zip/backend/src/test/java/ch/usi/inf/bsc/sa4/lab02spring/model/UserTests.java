package ch.usi.inf.bsc.sa4.lab02spring.model;


import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("The user")
public class UserTests {

    private User user;

    @BeforeEach
    void setup() {
        // this test preparation method is invoked right before each test invocation.
        this.user = new User("Albert Carlson", "carlson@usi.ch", "");
    }

    @DisplayName("after creation")
    @Nested
    class AfterCreationTests {

        @DisplayName("has the same name provided in the constructor")
        @Test
        void testGetName() {
            var actualName = user.getName();
            var expectedName = "Albert Carlson";
            assertEquals(expectedName, actualName, "name is not the one provided in the constructor");
        }

        @DisplayName("has the same name provided in the constructor")
        @Test
        void testGetEmail() {
            var actualEmail = user.getEmail();
            var expectedEmail = "carlson@usi.ch";
            assertEquals(expectedEmail, actualEmail, "email is not the one provided in the constructor");
        }

        @DisplayName("has the same name provided in the constructor")
        @Test
        void testGetProfilePhoto() {
            var actualProfilePhoto = user.getProfilePhoto();
            var expectedProfilePhoto = "";
            assertEquals(expectedProfilePhoto, actualProfilePhoto, "profile photo is not empty string in the constructor");
        }

        @DisplayName("can change their profile photo")
        @Test
        void testProfilePhotoChange() {
            var newProfilePhoto = "images/cloud/id/38391";
            user.setProfilePhoto(newProfilePhoto);
        }

    }


    @Nested
    @DisplayName("User Object ID Tests")
    class UserIdTests {

        private ObjectId userId;

        @BeforeEach
        void setUpObjectId() {
            userId = new ObjectId("60f9d2c9b8ea23779a7f3f13"); // MOCKING ID
        }


        @DisplayName("Setting and getting user ID")
        @Test
        void testSetAndGetId() {

            user.setId(userId);

            assertEquals(userId, user.getId(), "user ID should be set correctly");
        }

        @DisplayName("User ID is null when not provided")
        @Test
        void testNullUserId() {

            assertNull(user.getId(), "user ID should be null when not provided");
        }

        @DisplayName("User ID Persists Across Updates")
        @Test
        void testUserIdPersistence() {
            user.setId(userId);
            user.setName("John Doe");
            assertEquals(userId, user.getId(), "User ID should remain unchanged after updating other properties");
        }

        @DisplayName("Attempting to Reset User ID")
        @Test
        void testResetUserId() {
            ObjectId originalUserId = user.getId();
            user.setId(null);
            assertEquals(originalUserId, user.getId(), "User ID should remain unchanged after attempting to reset it");
        }

        @DisplayName("Object ID Format not null")
        @Test
        void testObjectIdFormatNotNull() {
            assertNotNull(userId, "User ID should not be null");
        }

        @DisplayName("Object ID Format")
        @Test
        void testObjectIdFormat() {
            String objectIdHex = userId.toHexString();
            String objectIdRegex = "^[0-9a-fA-F]{24}$";
            assertTrue(objectIdHex.matches(objectIdRegex), "User ID should match the expected format");
        }
    }

    @DisplayName("after a successful profile photo change")
    @Nested
    class AfterProfilePhotoChangeTests {


        private String newProfilePhoto;

        private String newProfilePhoto2;

        @BeforeEach
        void setup() {
            this.newProfilePhoto = "images/cloud/id/38391";
            user.setProfilePhoto(newProfilePhoto);
        }

        @DisplayName("profile photo really changed")
        @Test
        void testProfilePhotoReallyChanged(){
            assertEquals(newProfilePhoto, user.getProfilePhoto(), "profile photo is not changed");
        }

        @DisplayName("profile photo really changed")
        @Test
        void testProfilePhotoReallyChanged2(){
            this.newProfilePhoto2 = "images/cloud/id/721";
            user.setProfilePhoto(newProfilePhoto2);

            assertEquals(newProfilePhoto2, user.getProfilePhoto(), "profile photo didn't change");
        }

    }

    @DisplayName("equals method")
    @Nested
    class EqualsMethodTests {

        @Test
        @DisplayName("returns true when comparing the same object")
        void testEqualsSameObject() {
            assertEquals(user, user, "equals should return true when comparing the same object");
        }

        @Test
        @DisplayName("returns false when comparing with null")
        void testEqualsNull() {
            assertFalse(user.equals(null), "equals should return false when comparing with null");
        }

        @Test
        @DisplayName("returns false when comparing with an object of a different class")
        void testEqualsDifferentClass() {
            assertFalse(user.equals("some string"), "equals should return false when comparing with an object of a different class");
        }

        @Test
        @DisplayName("returns true when comparing with another user with the same email")
        void testEqualsSameEmail() {
            User anotherUser = new User("John Doe", "carlson@usi.ch", "photoPath");
            assertEquals(user, anotherUser, "equals should return true when comparing with another user with the same email");
        }

        @Test
        @DisplayName("returns false when comparing with another user with a different email")
        void testEqualsDifferentEmail() {
            User anotherUser = new User("John Doe", "john.doe@usi.ch", "photoPath");
            assertFalse(user.equals(anotherUser), "equals should return false when comparing with another user with a different email");
        }
    }
}
