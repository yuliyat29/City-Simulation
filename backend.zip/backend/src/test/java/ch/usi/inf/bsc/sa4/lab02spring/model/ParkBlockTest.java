package ch.usi.inf.bsc.sa4.lab02spring.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ParkBlockTest {

    @Test
    void testConstructorForX() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.RESIDENTIALBLOCK);

        assertEquals(2, actualParkBlock.getX());
    }
    @Test
    void testConstructorForY() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.RESIDENTIALBLOCK);

        assertEquals(3, actualParkBlock.getY());
    }
    @Test
    void testConstructorForDistance() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.RESIDENTIALBLOCK);

        assertEquals(5, actualParkBlock.getDistanceFromCenter());
    }
    @Test
    void testConstructorForType() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.RESIDENTIALBLOCK);

        assertEquals(BTypes.RESIDENTIALBLOCK, actualParkBlock.getType());
    }

    @Test
    void testConstructorForGetX() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.WATERBLOCK);

        assertEquals(2, actualParkBlock.getX());
    }

    @Test
    void testConstructorForGetY() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.PARKBLOCK);

        assertEquals(3, actualParkBlock.getY());
    }

    @Test
    void testConstructorForGetDistance() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.PARKBLOCK);

        assertEquals(5, actualParkBlock.getDistanceFromCenter());

    }

    @Test
    void testConstructorForGetType() {
        ParkBlock actualParkBlock = new ParkBlock(2, 3, BTypes.PARKBLOCK);

        assertEquals(BTypes.PARKBLOCK, actualParkBlock.getType());
    }

}
