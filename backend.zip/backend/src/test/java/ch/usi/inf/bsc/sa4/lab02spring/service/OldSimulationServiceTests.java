package ch.usi.inf.bsc.sa4.lab02spring.service;

import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.*;
import ch.usi.inf.bsc.sa4.lab02spring.model.City;
import ch.usi.inf.bsc.sa4.lab02spring.model.OldSimulation;
import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;
import ch.usi.inf.bsc.sa4.lab02spring.model.Block;
import com.nimbusds.common.contenttype.ContentType;
import org.junit.jupiter.api.*;
import org.mockito.internal.matchers.Find;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.springframework.data.domain.Sort;
import ch.usi.inf.bsc.sa4.lab02spring.repository.SimulationRepository;
import org.bson.types.ObjectId;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.OptionalLong;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest
@DisplayName("The Old Simulation Service")

public class OldSimulationServiceTests {
    @Autowired
    OldSimulationService oldSimulationService;

    @DisplayName("after storing old simulation")
    @Nested
    class WhenStoringOldSimulation {
        OldSimulation oldSimulationToStore;
        ObjectId oldSimulationId = new ObjectId();

        @BeforeEach
        void setUp() {
            oldSimulationToStore = new OldSimulation(
                    oldSimulationId,
                    new ObjectId(),
                    "alant@usi.ch",
                    false,
                    new City(10000,2000,500,1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()
            );
            oldSimulationService.storeSimulation(oldSimulationToStore);
        }
        @DisplayName("old simulation should be stored in database")
        @Test
        public void oldSimulationShouldBeStoredInDatabase() {
            OldSimulation oldSimulationFromDB = oldSimulationService.getSimulationById(oldSimulationId.toString());
            assertNotNull(oldSimulationFromDB);
        }
    }
    @DisplayName("after delete old simulation")
    @Nested
    class WhenDeletingOldSimulation {
        OldSimulation oldSimulationToDelete;
        ObjectId oldSimulationId = new ObjectId();

        @BeforeEach
        void setUp() {
            oldSimulationToDelete = new OldSimulation(
                    oldSimulationId,
                    new ObjectId(),
                    "alant@usi.ch",
                    false,
                    new City(10000,2000,500,1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()
            );
            oldSimulationService.storeSimulation(oldSimulationToDelete);
            oldSimulationService.deleteSimulation(oldSimulationToDelete);
        }

        @DisplayName("old simulation should be deleted in database")
        @Test
        public void oldSimulationShouldBeDeletedFromDatabase() {
           assertThrows(Exception.class , () -> oldSimulationService.getSimulationById(oldSimulationId.toString())
                   ,"Old simulation should not be deleted from database");
        }

    }
    @DisplayName("after delete old simulation by parent id ")
    @Nested
    class WhenDeletingOldSimulationByParentId {
        OldSimulation oldSimulationToDelete;
        ObjectId oldSimulationParentId = new ObjectId();

        @BeforeEach
        void setUp() {
            oldSimulationToDelete = new OldSimulation(
                    new ObjectId(),
                    oldSimulationParentId,
                    "alant@usi.ch",
                    false,
                    new City(10000,2000,500,1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()
            );
            oldSimulationService.storeSimulation(oldSimulationToDelete);
            oldSimulationService.deleteSimulationsByParentId(oldSimulationParentId.toString());
        }

        @DisplayName("after delete old simulation by parent id should be deleted in database")
        @Test
        public void oldSimulationShouldBeDeletedFromDatabase() {
            assertThrows(Exception.class , () -> oldSimulationService.getSimulationById(oldSimulationParentId.toString())
                    ,"Old simulation should not be deleted from database");
        }

    }

    @DisplayName("after storing simulation as old")
    @Nested
    class WhenStoringOld {
        Simulation simulationToStore;
        ObjectId oldSimulationId = new ObjectId();

        @BeforeEach
        void setUp() {
            simulationToStore = new Simulation(
                    oldSimulationId,
                    "alant@usi.ch",
                    false,
                    new City(10000,2000,500,1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()

            );
            oldSimulationService.storeSimulationAsOld(simulationToStore);
        }
        @DisplayName("simulation should be stored in database")
        @Test
        public void simulationStoreAsOld(){
            List<OldSimulation> oldSimulationFromDB = oldSimulationService.getUserOldSimulations(oldSimulationId.toString());
            assertNotNull(oldSimulationFromDB.get(0));
        }
    }

    @DisplayName("after getting user old simulations")
    @Nested
    class WhenGettingUsersOldSimulations{

        ObjectId oldSimulationParentID = new ObjectId();
        int numberOfOldSim = 3;

        @BeforeEach
        void setup(){
            for(int i = 0 ; i < numberOfOldSim ; i++){
                Simulation simulation = new Simulation(
                        oldSimulationParentID,
                        "alant@usi.ch",
                        false,
                        new City(10000,2000,500+i,1000),
                        "Simulation1",
                        "Description",
                        new Date(),
                        new Date()
                );
                oldSimulationService.storeSimulationAsOld(simulation);
            }
        }

        @DisplayName("the result is not null")
        @Test
        public void resultIsNotNull(){
            List<OldSimulation> oldSimulations = oldSimulationService.getUserOldSimulations(oldSimulationParentID.toString());
            assertNotNull(oldSimulations,
                    "List shouldnt be null");
        }

        @DisplayName("the size should be as expected")
        @Test
        public void resultExpected(){
            List<OldSimulation> oldSimulations = oldSimulationService.getUserOldSimulations(oldSimulationParentID.toString());
            assertEquals(numberOfOldSim , oldSimulations.size());
        }
    }

    @DisplayName("after getting simulation by id")
    @Nested
    class WhenGettingSimulationByID {
        OldSimulation oldSimulationToStore;
        ObjectId oldSimulationId = new ObjectId();

        @BeforeEach
        void setUp() {
            oldSimulationToStore = new OldSimulation(
                    oldSimulationId,
                    new ObjectId(),
                    "alant@usi.ch",
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()
            );
            oldSimulationService.storeSimulation(oldSimulationToStore);
        }

        @DisplayName("after getting simulation shouldnt be null")
        @Test
        public void resultIsNotNull(){
            OldSimulation oldSimulationFromDB = oldSimulationService.getSimulationById(oldSimulationId.toString());
            assertNotNull(oldSimulationFromDB, "simulation shouldnt be null");
        }

        @DisplayName("after getting simulation id should be same in database")
        @Test
        public void resultAsExpected(){
            OldSimulation oldSimulationFromDB = oldSimulationService.getSimulationById(oldSimulationId.toString());
            assertEquals(oldSimulationId.toString() , oldSimulationFromDB.get_id().toString());
        }
    }

    @DisplayName("after deleting oldest simulation")
    @Nested
    class WhenDeletingOldestSimulation{
        List <OldSimulation> oldSimulations = new ArrayList<>();
        OldSimulation oldSimulation;
        OldSimulation oldestSimulation;
        ObjectId oldSimulationID = new ObjectId();
        ObjectId oldestSimulationID = new ObjectId();
        ObjectId oldSimulationParentID = new ObjectId();
        @BeforeEach
        void setup(){
            oldSimulation =  new OldSimulation(
                    oldSimulationID,
                    oldSimulationParentID,
                    "alant@usi.ch",
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()
            );

            oldestSimulation = new OldSimulation(
                    oldestSimulationID,
                    oldSimulationParentID,
                    "alant@usi.ch",
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()
            );
            oldSimulations.add(oldSimulation);
            oldSimulations.add(oldestSimulation);
            oldSimulationService.storeSimulation(oldSimulation);
            oldSimulationService.storeSimulation(oldestSimulation);
            oldSimulationService.deleteOldestOne(oldSimulations);
        }

        @DisplayName("after deleting should delete correct one")
        @Test
        public void deletingOldestOne(){
            List<OldSimulation> oldSimulations = oldSimulationService.getUserOldSimulations(oldSimulationParentID.toString());
            assertEquals(1, oldSimulations.size());
            assertEquals(oldestSimulationID.toString(), oldSimulations.get(0).get_id().toString());
        }
    }


    @DisplayName("getting old block from simulation")
    @Nested
    class WhenGettingOldBlock{
        FindBlockDTO findBlockDTO;
        OldSimulation oldSimulation;
        ObjectId oldSimulationID = new ObjectId();

        @BeforeEach
        void setup(){
            findBlockDTO = new FindBlockDTO(0,0,oldSimulationID.toString());
            oldSimulation = new OldSimulation(
                    oldSimulationID,
                    new ObjectId(),
                    "alant@usi.ch",
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "Description",
                    new Date(),
                    new Date()
            );
            oldSimulationService.storeSimulation(oldSimulation);
        }

        @DisplayName("after storing database shouldnt be null")
        @Test
        public void resultIsNull(){
            OldSimulation oldSimulationFromDB = oldSimulationService.getSimulationById(oldSimulationID.toString());
            assertNotNull(oldSimulationFromDB, "simulation shouldnt be null");
        }

        @DisplayName("should get correct old block")
        @Test
        public void getCorrectOldBlock(){
            Block block = oldSimulationService.oldBlockGetterFromSimulation(findBlockDTO);
            assertEquals(findBlockDTO.x(), block.getX());
            assertEquals(findBlockDTO.y(), block.getY());
        }
    }
}
