package ch.usi.inf.bsc.sa4.lab02spring.service;

import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.*;
import ch.usi.inf.bsc.sa4.lab02spring.model.City;
import ch.usi.inf.bsc.sa4.lab02spring.model.ResidentialBlock;
import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;
import ch.usi.inf.bsc.sa4.lab02spring.model.Block;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.springframework.data.domain.Sort;
import ch.usi.inf.bsc.sa4.lab02spring.repository.SimulationRepository;
import org.bson.types.ObjectId;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest
@DisplayName("The Simulation Service")
public class SimulationServiceTests {

    @Autowired
    SimulationService simulationService;

    @DisplayName(" after storing simulation")
    @Nested
    class WhenStoringSimulation {

        Simulation simulationToStore;
        Simulation storedSimulation;

        @BeforeEach
        void setup() {
            simulationToStore = new Simulation(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Simulation1",
                    "alant@usi.ch",
                    false,
                    "",
                    new Date(),
                    null
            );
            storedSimulation = simulationService.storeSimulation(simulationToStore);
        }

        @DisplayName(" the result should be non null")
        @Test
        void testNotNull() {
            assertNotNull(storedSimulation);
        }

        @DisplayName(" simulation should be stored in the database")
        @Test
        void testStoredSimulation() {
            Simulation simulationFromDB = simulationService.getSimulationById(storedSimulation.get_id().toString());
            assertNotNull(simulationFromDB);
        }

        @DisplayName(" should update simulation if simulation with the same id is already in the database")
        @Test
        void testUpdateSimulation() {
            storedSimulation.setSimulationName("NewName");
            simulationService.storeSimulation(storedSimulation);
            Simulation simulationFromDB = simulationService.getSimulationById(storedSimulation.get_id().toString());
            assertEquals("NewName", simulationFromDB.getSimulationName());
        }

    }

    @DisplayName(" after creating a new simulation ")
    @Nested
    class WhenCreatingANewSimulation {

        CreateSimulationDTO newSimulationDTO;
        SimulationDTO newSimulation;
        String email = "alant@usi.ch";

        @BeforeEach
        void setup() {
            newSimulationDTO = new CreateSimulationDTO(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Simulation1"
            );
            this.newSimulation = simulationService.createSimulation(newSimulationDTO, email);
        }

        @DisplayName(" the new simulation should be non null")
        @Test
        public void testNotNull() {
            assertNotNull(this.newSimulation);
        }

        @DisplayName(" the new simulation should have the specified parameters")
        @Test
        public void testCreateSimulation() {
            assertEquals(newSimulationDTO.transportationCost(), newSimulation.transportationCost());
            assertEquals(newSimulationDTO.wage(), newSimulation.wage());
            assertEquals(newSimulationDTO.simulationName(), newSimulation.simulationName());
            assertEquals(email, newSimulation.authorEmail());
            assertFalse(newSimulation.isPublic());
            assertEquals("", newSimulation.simulationPicture());
        }

        @DisplayName(" the new simulation should be stored in the database")
        @Test
        public void testSimulationContained() {
            Simulation simulationFromDB = simulationService.getSimulationById(newSimulation._id());
            assertNotNull(simulationFromDB);
            assertEquals(newSimulationDTO.transportationCost(), simulationFromDB.getCity().getTransportationCost());
            assertEquals(newSimulationDTO.wage(), simulationFromDB.getCity().getWage());
            assertEquals(newSimulationDTO.simulationName(), simulationFromDB.getSimulationName());
            assertEquals(email, simulationFromDB.getAuthorEmail());
            assertFalse(simulationFromDB.isPublic());
            assertEquals("", simulationFromDB.getSimulationPicture());
        }

    }

    @DisplayName(" after getting block from simulation")
    @Nested
    class WhenGettingBlockFromSimulation {

        CreateSimulationDTO newSimulationDTO;
        SimulationDTO newSimulation;
        String email = "alant@usi.ch";
        FindBlockDTO findBlock1DTO;
        FindBlockDTO findBlock2DTO;
        Block block1;
        Block block2;

        @BeforeEach
        void setup() {
            newSimulationDTO = new CreateSimulationDTO(
                    12000,
                    200,
                    10000,
                    5000,
                    "Simulation1"
            );
            this.newSimulation = simulationService.createSimulation(newSimulationDTO, email);
            findBlock1DTO = new FindBlockDTO(-1, 0, newSimulation._id());
            findBlock2DTO = new FindBlockDTO(1, -1, "someSimulation");
            this.block1 = simulationService.blockGetterFromSimulation(findBlock1DTO);
            this.block2 = simulationService.blockGetterFromSimulation(findBlock2DTO);
        }

        @DisplayName(" the result should be null if the simulations does not exist")
        @Test
        public void testNull() {
            assertNull(block2);
        }

        @DisplayName(" the result should non null if the simulations exists")
        @Test
        public void testNotNull() {
            assertNotNull(block1);
        }

        @DisplayName(" the block coordinates should be the same")
        @Test
        public void testCoordinatesEqual() {
            assertEquals(findBlock1DTO.x(), block1.getX());
            assertEquals(findBlock1DTO.y(), block1.getY());
        }

    }

    @DisplayName(" after making simulation public")
    @Nested
    class WhenMakingSimulationPublic {

        CreateSimulationDTO newSimulationDTO;
        SimulationDTO newSimulation;
        String email = "alant@usi.ch";
        SimulationLinkDTO simulationLinkDTO;

        @BeforeEach
        void setup() {
            newSimulationDTO = new CreateSimulationDTO(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Simulation1"
            );
            this.newSimulation = simulationService.createSimulation(newSimulationDTO, email);
            this.simulationLinkDTO = simulationService.makePublic(newSimulation._id());
        }

        @DisplayName(" the link should be non null")
        @Test
        public void testNotNull() {
            assertNotNull(simulationLinkDTO);
        }

        @DisplayName(" the link should contain the right url")
        @Test
        public void testURL() {
            assertEquals(
                    ("http://localhost:3000/simulations/shared/" + newSimulation._id()),
                    simulationLinkDTO.link()
            );
        }

        @DisplayName(" the simulation should be updated in the database")
        @Test
        public void testUpdate() {
            Simulation updatedSimulation = simulationService.getSimulationById(newSimulation._id());
            assertTrue(updatedSimulation.isPublic());
        }

    }

    @DisplayName(" after making simulation private")
    @Nested
    class WhenMakingSimulationPrivate {

        CreateSimulationDTO newSimulationDTO;
        SimulationDTO newSimulation;
        String email = "alant@usi.ch";
        SimulationLinkDTO simulationLinkDTO;

        @BeforeEach
        void setup() {
            newSimulationDTO = new CreateSimulationDTO(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Simulation1"
            );
            this.newSimulation = simulationService.createSimulation(newSimulationDTO, email);
            simulationService.makePublic(newSimulation._id());
            this.simulationLinkDTO = simulationService.makePrivate(newSimulation._id());
        }

        @DisplayName(" the link should be non null")
        @Test
        public void testNotNull() {
            assertNotNull(simulationLinkDTO);
        }

        @DisplayName(" the link should contain the right url")
        @Test
        public void testURL() {
            assertEquals(
                    ("http://localhost:3000/simulations/shared/" + newSimulation._id()),
                    simulationLinkDTO.link()
            );
        }

        @DisplayName(" the simulation should be updated in the database")
        @Test
        public void testUpdate() {
            Simulation updatedSimulation = simulationService.getSimulationById(newSimulation._id());
            assertFalse(updatedSimulation.isPublic());
        }

    }

    @DisplayName(" after getting user's simulations")
    @Nested
    class WhenGettingUsersSimulations {

        String email1 = "alant@usi.ch";
        String email2 = "graceh@usi.ch";
        String email3 = "charlesb@usi.ch";
        int sizeForUser1 = 5;
        int sizeForUser2 = 2;
        int sizeForUser3 = 0;
        List<SimulationDTO> simulationsOfUser1;
        List<SimulationDTO> simulationsOfUser2;
        List<SimulationDTO> simulationsOfUser3;

        @BeforeEach
        void setup() {
            for (int i = 0; i < sizeForUser1; i++) {
                CreateSimulationDTO newSimulationDTO = new CreateSimulationDTO(
                        12000 + i,
                        2000 + i,
                        10000 + i,
                        5000,
                        "Simulation" + i
                );
                simulationService.createSimulation(newSimulationDTO, email1);
            }
            for (int i = 0; i < sizeForUser2; i++) {
                CreateSimulationDTO newSimulationDTO = new CreateSimulationDTO(
                        12000 + i,
                        2000 + i,
                        10000 + i,
                        5000,
                        "Simulation" + i
                );
                simulationService.createSimulation(newSimulationDTO, email2);
            }
            this.simulationsOfUser1 = simulationService.getUsersSimulations(
                    email1,
                    Sort.by(Sort.Direction.ASC, "populationSize"),
                    sizeForUser1,
                    0
            );
            this.simulationsOfUser2 = simulationService.getUsersSimulations(
                    email2,
                    Sort.by(Sort.Direction.ASC, "populationSize"),
                    sizeForUser2,
                    0
            );
            this.simulationsOfUser3 = simulationService.getUsersSimulations(
                    email3,
                    Sort.by(Sort.Direction.ASC, "populationSize"),
                    sizeForUser3 + 1,
                    0
            );
        }

        @AfterEach
        void tearDown() {
            simulationService.cleanAllSimulations();
        }

        @DisplayName(" the list of simulations should be non null")
        @Test
        public void testNotNull() {
            assertNotNull(simulationsOfUser1);
            assertNotNull(simulationsOfUser2);
            assertNotNull(simulationsOfUser3);
        }

        @DisplayName(" the list should be empty if user has no simulations")
        @Test
        public void testNoSimulations() {
            assertTrue(simulationsOfUser3.isEmpty());
        }

        @DisplayName(" the number of simulations should be correct")
        @Test
        public void testNumberOfSimulations() {
            assertEquals(sizeForUser1, simulationsOfUser1.size());
            assertEquals(sizeForUser2, simulationsOfUser2.size());
            assertEquals(sizeForUser3, simulationsOfUser3.size());
        }

        @DisplayName(" users should get only their own simulations")
        @Test
        public void testOwnerOfSimulations() {
            boolean correctOwner1 = simulationsOfUser1.stream().allMatch(simulationDTO ->
                    email1.equals(simulationDTO.authorEmail())
            );
            boolean correctOwner2 = simulationsOfUser2.stream().allMatch(simulationDTO ->
                    email2.equals(simulationDTO.authorEmail())
            );
            assertTrue(correctOwner1, "user got simulations that do not belong to them");
            assertTrue(correctOwner2, "user got simulations that do not belong to them");
        }

    }

    @DisplayName(" after getting simulation by id")
    @Nested
    class WhenGettingSimulationById {

        CreateSimulationDTO newSimulationDTO;
        SimulationDTO storedSimulation;
        String email1 = "alant@usi.ch";

        @BeforeEach
        void setup() {
            newSimulationDTO = new CreateSimulationDTO(
                    72,
                    23,
                    10000,
                    5000,
                    "Simulation1"
            );
            this.storedSimulation = simulationService.createSimulation(newSimulationDTO, email1);
        }

        @DisplayName(" should throw when getting simulation by invalid id")
        @Test
        public void testThrowWithInvalidId() {
            Executable getByIdCall = () -> simulationService.getSimulationById("invalidId");
            assertThrows(Exception.class, getByIdCall);
        }

        @DisplayName(" the result should be non null when getting simulation by correct id")
        @Test
        public void testNotNull() {
            assertNotNull(simulationService.getSimulationById(storedSimulation._id()));
        }

        @DisplayName(" should return the correct simulation")
        @Test
        public void testGotCorrectSimulation() {
            Simulation result = simulationService.getSimulationById(storedSimulation._id());
            assertEquals(storedSimulation._id(), result.get_id().toString());
            assertEquals(storedSimulation.authorEmail(), result.getAuthorEmail());
        }

    }

    @DisplayName(" after getting all simulations")
    @Nested
    class WhenGettingAllSimulations {

        int numberOfSimulations = 7;

        @BeforeEach
        void setup() {
            for (int i = 0; i < numberOfSimulations; i++) {
                CreateSimulationDTO newSimulationDTO = new CreateSimulationDTO(
                        12000 + i,
                        2000 + i,
                        10000 + i,
                        5000,
                        "Simulation" + i
                );
                simulationService.createSimulation(newSimulationDTO, "email" + i);
            }
        }

        @AfterEach
        void tearDown() {
            simulationService.cleanAllSimulations();
        }

        @DisplayName(" the result should be non null")
        @Test
        public void testNotNull() {
            assertNotNull(simulationService.getAll());
        }

        @DisplayName(" the number of simulations should be correct")
        @Test
        public void testCorrectNumber() {
            assertEquals(numberOfSimulations, simulationService.getAll().size());
        }

        @DisplayName(" should return empty list when there are no simulations")
        @Test
        public void testEmptyList() {
            simulationService.cleanAllSimulations();
            assertTrue(simulationService.getAll().isEmpty());
        }

        @DisplayName(" the simulations should be correct")
        @Test
        public void testCorrectSimulations() {
            List<Simulation> allSimulations = simulationService.getAll();
            for (int i = 0; i < numberOfSimulations; i++) {
                Simulation simulation = allSimulations.get(i);
                assertEquals(
                        "email" + i,
                        simulation.getAuthorEmail()
                );
                assertEquals(
                        "Simulation" + i,
                        simulation.getSimulationName()
                );
            }
        }

    }

    @DisplayName(" after counting simulations by email")
    @Nested
    class WhenCountingSimulationsByEmail {

        String email1 = "alant@usi.ch";
        String email2 = "graceh@usi.ch";
        String email3 = "charlesb@usi.ch";
        int numberOfSimulationsForEmail1 = 5;
        int numberOfSimulationsForEmail2 = 2;
        int numberOfSimulationsForEmail3 = 0;

        @BeforeEach
        @DisplayName(" creates simulations for each email we have except Email3")
        void setup() {
            for (int i = 0; i < numberOfSimulationsForEmail1; i++) {
                CreateSimulationDTO newSimulationDTO = new CreateSimulationDTO(
                        12000 + i,
                        2000 + i,
                        10000 + i,
                        5000,
                        "Simulation" + i
                );
                simulationService.createSimulation(newSimulationDTO, email1);
            }
            for (int i = 0; i < numberOfSimulationsForEmail2; i++) {
                CreateSimulationDTO newSimulationDTO = new CreateSimulationDTO(
                        12000 + i,
                        2000 + i,
                        10000 + i,
                        5000,
                        "Simulation" + i
                );
                simulationService.createSimulation(newSimulationDTO, email2);
            }
        }

        @AfterEach
        void tearDown() {
            simulationService.cleanAllSimulations();
        }

        @DisplayName(" should return correct count for an email with simulations")
        @Test
        public void testCountForEmailWithSimulations() {
            long countForEmail1 = simulationService.countSimulationByEmail(email1);
            long countForEmail2 = simulationService.countSimulationByEmail(email2);

            assertEquals(numberOfSimulationsForEmail1, countForEmail1);
            assertEquals(numberOfSimulationsForEmail2, countForEmail2);
        }

        @DisplayName(" should return 0 for an email without simulations")
        @Test
        public void testCountForEmailWithoutSimulations() {
            long countForEmail3 = simulationService.countSimulationByEmail(email3);

            assertEquals(numberOfSimulationsForEmail3, countForEmail3);
        }
    }

    @DisplayName(" after updating a simulation")
    @Nested
    class WhenUpdatingASimulation {

        CreateSimulationDTO createSimulationDTO;
        UpdateSimulationDTO updateSimulationDTO;
        SimulationDTO originalSimulation;
        Simulation updatedSimulation;
        String email = "alant@usi.ch";

        @BeforeEach
        void setup() {
            createSimulationDTO = new CreateSimulationDTO(
                    12000,
                    2000,
                    10000,
                    5000,
                    "OriginalSimulation"
            );
            originalSimulation = simulationService.createSimulation(createSimulationDTO, email);

            updateSimulationDTO = new UpdateSimulationDTO(
                    originalSimulation._id(),
                    12500,
                    2500,
                    10000,
                    5000,
                    "UpdatedSimulation"
            );

            simulationService.updateSimulation(updateSimulationDTO);
            updatedSimulation = simulationService.getSimulationById(originalSimulation._id());
        }

        @DisplayName(" the updated simulation should not be null")
        @Test
        public void testNotNull() {
            assertNotNull(updatedSimulation);
        }

        @DisplayName(" the attributes should be updated correctly")
        @Test
        public void testAttributesUpdated() {
            assertEquals(updateSimulationDTO.wage(), updatedSimulation.getCity().getWage());
            assertEquals(updateSimulationDTO.transportationCost(), updatedSimulation.getCity().getTransportationCost());
            assertEquals(updateSimulationDTO.simulationName(), updatedSimulation.getSimulationName());
            assertEquals(email, updatedSimulation.getAuthorEmail());
            assertFalse(updatedSimulation.isPublic());
            assertEquals(originalSimulation.simulationPicture(), updatedSimulation.getSimulationPicture());
        }
    }

    @DisplayName(" after getting author email")
    @Nested
    class WhenGettingAuthorEmail {

        CreateSimulationDTO createSimulationDTO;
        SimulationDTO newSimulation;
        String email = "alant@usi.ch";
        String getAuthorEmailResult;

        @BeforeEach
        void setup() {
            createSimulationDTO = new CreateSimulationDTO(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Simulation1"
            );
            this.newSimulation = simulationService.createSimulation(createSimulationDTO, email);
            getAuthorEmailResult = simulationService.getAuthorEmail(newSimulation._id());
        }

        @DisplayName(" the result should be non null if specifying simulation with right id")
        @Test
        public void testNotNull() {
            assertNotNull(getAuthorEmailResult);
        }

        @DisplayName(" the result should be null if specifying simulation with wrong id")
        @Test
        public void testNull() {
            assertNull(simulationService.getAuthorEmail("123"));
        }

        @DisplayName(" the email should be correct")
        @Test
        public void testCorrectEmail() {
            assertEquals(email, getAuthorEmailResult);
        }

    }

    @DisplayName(" after cleaning all simulations")
    @Nested
    class WhenCleaningAllSimulations {

        int numberOfSimulations = 7;

        @BeforeEach
        void setup() {
            for (int i = 0; i < numberOfSimulations; i++) {
                CreateSimulationDTO newSimulationDTO = new CreateSimulationDTO(
                        12000 + i,
                        2000 + i,
                        10000,
                        5000,
                        "Simulation" + i
                );
                simulationService.createSimulation(newSimulationDTO, "email" + i);
            }
            simulationService.cleanAllSimulations();
        }

        @DisplayName(" the number of simulation should be 0")
        @Test
        void testCleanAllSimulations() {
            assertEquals(0, simulationService.getAll().size());
        }

    }

    @DisplayName(" after deleting simulation")
    @Nested
    class WhenDeletingSimulation {
        @Test
        @DisplayName(" getting the simulation by id should throw an exception")
        void testDeleteSimulation() {
            // Create a simulation
            CreateSimulationDTO simulationDTO = new CreateSimulationDTO(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Simulation1"
            );
            SimulationDTO createdSimulation = simulationService.createSimulation(simulationDTO, "alant@usi.ch");

            // Get the ID of the created simulation
            String simulationId = createdSimulation._id();

            // Delete the simulation
            simulationService.deleteSimulation(simulationId);

            // Attempt to retrieve the deleted simulation
            assertThrows(Exception.class, () -> simulationService.getSimulationById(simulationId),
                    "Simulation should not exist after deletion");
        }
    }

    @DisplayName(" after updating transportation costs")
    @Nested
    class WhenUpdatingTransportationCosts {

        List<Integer> xCoordinates = List.of(0);
        List<Integer> yCoordinates = List.of(0);
        double newTransportationCost = 1500;
        Simulation simulation;
        Simulation storedSimulation;
        SimulationDTO simulationDTO;

        @BeforeEach
        void setup() {
            simulation = new Simulation(
                    10000,
                    2000,
                    500,
                    1000,
                    "Simulation1",
                    "alant@usi.ch",
                    false,
                    "",
                    new Date(),
                    new Date()
            );
            storedSimulation = simulationService.storeSimulation(simulation);
            simulationDTO = simulationService.updateTransportationCost(
                    storedSimulation.get_id().toString(),
                    xCoordinates,
                    yCoordinates,
                    newTransportationCost
            );
        }

        @DisplayName(" the result should be not null")
        @Test
        public void testNotNull() {
            assertNotNull(simulationDTO);
        }

        @DisplayName(" the blocks should be updated")
        @Test
        public void testBlockUpdate() {
            Simulation updatedSimulation = simulationService.getSimulationById(storedSimulation.get_id().toString());
            ResidentialBlock block = (ResidentialBlock) City.findBlockByCoordinate(
                    updatedSimulation.getCity(),
                    0,
                    0
            );
            assertEquals(newTransportationCost, block.getTransportationCost());
        }

    }

    @DisplayName(" after updating construction costs limit")
    @Nested
    class WhenUpdatingConstructionCostsLimit {

        List<Integer> xCoordinates = List.of(0);
        List<Integer> yCoordinates = List.of(0);
        double newConstructionCostsLimit = 1000;
        Simulation simulation;
        Simulation storedSimulation;
        SimulationDTO simulationDTO;

        @BeforeEach
        void setup() {
            simulation = new Simulation(
                    10000,
                    2000,
                    500,
                    1000,
                    "Simulation1",
                    "alant@usi.ch",
                    false,
                    "",
                    new Date(),
                    new Date()
            );
            storedSimulation = simulationService.storeSimulation(simulation);
            simulationDTO = simulationService.updateLocalConstructionCostLimit(
                    storedSimulation.get_id().toString(),
                    xCoordinates,
                    yCoordinates,
                    newConstructionCostsLimit
            );
        }

        @DisplayName(" the result should be not null")
        @Test
        public void testNotNull() {
            assertNotNull(simulationDTO);
        }

        @DisplayName(" the blocks should be updated")
        @Test
        public void testBlockUpdate() {
            Simulation updatedSimulation = simulationService.getSimulationById(storedSimulation.get_id().toString());
            ResidentialBlock block = (ResidentialBlock) City.findBlockByCoordinate(
                    updatedSimulation.getCity(),
                    0,
                    0
            );
            assertEquals(newConstructionCostsLimit, block.getConstructionCostLimit());
        }

    }

    @DisplayName(" after updating rent limit")
    @Nested
    class WhenUpdatingRentLimit {

        List<Integer> xCoordinates = List.of(0);
        List<Integer> yCoordinates = List.of(0);
        double newRentLimit = 200;
        Simulation simulation;
        Simulation storedSimulation;
        SimulationDTO simulationDTO;

        @BeforeEach
        void setup() {
            simulation = new Simulation(
                    10000,
                    2000,
                    500,
                    1000,
                    "Simulation1",
                    "alant@usi.ch",
                    false,
                    "",
                    new Date(),
                    new Date()
            );
            storedSimulation = simulationService.storeSimulation(simulation);
            simulationDTO = simulationService.updateLocalRentLimit(
                    storedSimulation.get_id().toString(),
                    xCoordinates,
                    yCoordinates,
                    newRentLimit
            );
        }

        @DisplayName(" the result should be not null")
        @Test
        public void testNotNull() {
            assertNotNull(simulationDTO);
        }

        @DisplayName(" the blocks should be updated")
        @Test
        public void testBlockUpdate() {
            Simulation updatedSimulation = simulationService.getSimulationById(storedSimulation.get_id().toString());
            ResidentialBlock block = (ResidentialBlock) City.findBlockByCoordinate(
                    updatedSimulation.getCity(),
                    0,
                    0
            );
            assertEquals(newRentLimit, block.getRentLimit());
        }

    }

}
