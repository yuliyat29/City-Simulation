package ch.usi.inf.bsc.sa4.lab02spring.model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class ResidentialBlockTest {

    private ResidentialBlock residentialBlock;

    @BeforeEach
    public void setUp() {
        residentialBlock = new ResidentialBlock(
                1, 2, 10, BTypes.RESIDENTIALBLOCK, 200.0, 100, 1500.0, 1000.0, 2000.0, 100000.0, 50000.0
        );
    }
    @Test
    public void testConstructorHeight() {
        assertEquals(10, residentialBlock.getHeight());
    }

    @Test
    public void testConstructorTransportationCost() {
        assertEquals(200.0, residentialBlock.getTransportationCost());
    }

    @Test
    public void testConstructorPopulation() {
        assertEquals(100, residentialBlock.getNumberOfPeople());
    }

    @Test
    public void testConstructorRent() {
        assertEquals(1500.0, residentialBlock.getCostOfRent());
    }

    @Test
    public void testConstructorConstructionCostLimit() {
        assertEquals(100000.0, residentialBlock.getConstructionCostLimit());
    }

    @Test
    public void testConstructorConstructionCost() {
        assertEquals(50000.0, residentialBlock.getConstructionCost());
    }

    @Test
    public void testConstructor() {
        assertEquals(10, residentialBlock.getHeight());
        assertEquals(200.0, residentialBlock.getTransportationCost());
        assertEquals(100, residentialBlock.getNumberOfPeople());
        assertEquals(1500.0, residentialBlock.getCostOfRent());
        assertEquals(2000.0, residentialBlock.getRentLimit());
        assertEquals(100000.0, residentialBlock.getConstructionCostLimit());
        assertEquals(50000.0, residentialBlock.getConstructionCost());
    }

    @Test
    public void testSetHeight() {
        residentialBlock.setHeight(15);
        assertEquals(15, residentialBlock.getHeight());
    }

    @Test
    public void testSetNumberOfPeople() {
        residentialBlock.setNumberOfPeople(120);
        assertEquals(120, residentialBlock.getNumberOfPeople());
    }

    @Test
    public void testSetCostOfRent() {
        residentialBlock.setCostOfRent(1600.0);
        assertEquals(1600.0, residentialBlock.getCostOfRent());
    }

    @Test
    public void testSetConstructionCost() {
        residentialBlock.setConstructionCost(55000.0);
        assertEquals(55000.0, residentialBlock.getConstructionCost());
    }

    @Test
    public void testSetTransportationCost() {
        residentialBlock.setTransportationCost(220.0);
        assertEquals(220.0, residentialBlock.getTransportationCost());
    }

    @Test
    public void testSetRentLimit() {
        residentialBlock.setRentLimit(2100.0);
        assertEquals(2100.0, residentialBlock.getRentLimit());
    }

    @Test
    public void testSetConstructionCostLimit() {
        residentialBlock.setConstructionCostLimit(110000.0);
        assertEquals(110000.0, residentialBlock.getConstructionCostLimit());
    }
}


