package ch.usi.inf.bsc.sa4.lab02spring.model;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.params.provider.Arguments.arguments;

import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@DisplayName("Toolbelt class")
public class ToolbeltTests {

  //ask: the class should be private?
//  @Test
//  @DisplayName("Private Constructor should Throws IllegalStateException if accessed directly")
//  void testPrivateConstructor() {
//      assertThrows(IllegalStateException.class, () -> {
//        Constructor<Toolbelt> constructor = Toolbelt.class.getDeclaredConstructor();
//        constructor.setAccessible(true);
//        constructor.newInstance();
//      }, "Private constructor should throw IllegalStateException when invoked");
//  }

  public static Stream<Arguments> taxicabDistanceTestsArgumentProvider() {
        return Stream.of(
                arguments(0, 0, 0, 0, 0),
                arguments(1, 2, 3, 4, 4),
                arguments(-1, -2, -3, -4, 4),
                arguments(-2, 2, 10, 1, 13),
                arguments(7, -2, 1, 1, 9),
                arguments(1, 0, -3, 35, 39),
                arguments(0, 2, 0, -3, 5),
                arguments(20, 15, -30, 0, 65)
        );
    }
  @ParameterizedTest(name = "with coordinates {0}, {1}, {2}, {3}")
  @DisplayName("The taxicab distance should be calculated correctly")
  @MethodSource("taxicabDistanceTestsArgumentProvider")
  void testTaxicabDistance(int x1, int y1, int x2, int y2, int expectedResult) {
        var actualResult = Toolbelt.taxicabDistance(x1, y1, x2, y2);
        assertEquals(expectedResult, actualResult, "Incorrect calculation of the taxicab distance");
    }

  @DisplayName("The open city model")
  @Nested
  class OpenCityModel {

    // Inner class to hold base parameters
    private static class Parameters {
      double wage;
      int distanceFromCBD;
      double transportationCost;
      double costOfHousing;


      Parameters(double wage, int distanceFromCBD, double transportationCost, double costOfAHouse) {
        this.wage = wage;
        this.distanceFromCBD = distanceFromCBD;
        this.transportationCost = transportationCost;
        this.costOfHousing = costOfAHouse;
      }
    }

    private Parameters baseParams;
    private Parameters deltaParams;

    @BeforeEach
    // initialize base parameters (given by the documentation)
    void initializeParameters() {
      this.baseParams = new Parameters(6000.0, 3, 200.0, 20.0);
      this.deltaParams = new Parameters(3000.0, 2, 150.0, 20.0);
    }

    @Nested
    @DisplayName("should have a method to calculate the cost of housing")
    class costOfHousing {

      @Test
      @DisplayName("that return the expected value for a given set of valid values")
      void testCostOfHousing() {
        double actualCostOfHouse = Toolbelt.costOfHousing(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        assertEquals(21.13440876770531, actualCostOfHouse, 0.001,
                "Incorrect calculation of the cost of house");
      }

      @Test
      @DisplayName("that behaves correctly depending on various values given")
      void testCostOfHousingBehavior() {
        // base case
        double baseCase = Toolbelt.costOfHousing(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);

        // cost of house with different wage
        double highWageCase = Toolbelt.costOfHousing(baseParams.wage + deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        double lowWageCase = Toolbelt.costOfHousing(baseParams.wage - deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        // cost of house with different distance from CBD
        double highDistanceFromCBDCase = Toolbelt.costOfHousing(baseParams.wage, baseParams.distanceFromCBD + deltaParams.distanceFromCBD, baseParams.transportationCost);
        double lowDistanceFromCBDCase = Toolbelt.costOfHousing(baseParams.wage, baseParams.distanceFromCBD - deltaParams.distanceFromCBD, baseParams.transportationCost);
        //cost of house with different transportation cost
        double highTransportationCostCase = Toolbelt.costOfHousing(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost + deltaParams.transportationCost);
        double lowTransportationCostCase = Toolbelt.costOfHousing(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost - deltaParams.transportationCost);

        // more wage then more cost of house
        assertTrue(lowWageCase < baseCase, "The cost of house should increase with more wage \n less wage case: " + lowWageCase + " < more wage case: " + baseCase);
        assertTrue(baseCase < highWageCase, "The cost of house should increase with more wage \n less wage case: " + baseCase + " < more wage case: " + highWageCase);

        // more distance from CBD then less cost of house
        assertTrue(baseCase < lowDistanceFromCBDCase, "The cost of house should decrease with the distance from the CBD \n more distance case: " + baseCase + " < less distance case: " + lowDistanceFromCBDCase);
        assertTrue(highDistanceFromCBDCase < baseCase, "The cost of house should decrease with the distance from the CBD\n more distance case: " + highDistanceFromCBDCase + " < less distance case: " + baseCase);

        // higher transportation cost then less cost of house
        assertTrue(baseCase < lowTransportationCostCase, "The cost of house should decrease with higher transportation cost\n higher transportation cost case: " + baseCase + " < less transportation cost: " + lowTransportationCostCase);
        assertTrue(highTransportationCostCase < baseCase, "The cost of house should decrease with higher transportation cost\n higher transportation cost: " + highTransportationCostCase + " < less transportation cost: " + baseCase);
      }

      public static Stream< Arguments > invalidCostOfHouseTestsProvider() {
        return Stream.of(
                arguments(6000.0, -500, 0.2), // Negative distanceFromCBD
                arguments(6000.0, 500, -0.2),  // Negative transportationCost
                arguments(-6000.0, 500, 0.2)  // Negative wage
        );
      }
      @DisplayName("that throws in case of invalid inputs")
      @ParameterizedTest(name = "inputs: {0}, {1}, {2}")
      @MethodSource("invalidCostOfHouseTestsProvider")
      void testInvalidCostOfHouse(double wage, int distanceFromCBD, double transportationCost) {
        assertThrows(IllegalArgumentException.class, () -> Toolbelt.costOfHousing(wage, distanceFromCBD, transportationCost),
                "costOfHousing should throw IllegalArgumentException for negative value");
      }
    }

    @Nested
    @DisplayName("should have a method to calculate the cost of land")
    class costOfLandPerBlock {

      @Test
      @DisplayName("that return the expected value for a given set of valid values")
      void testCostOfLand() {
        double actualCostOfLand = Toolbelt.costOfLand(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        assertEquals(3.4962827288983434, actualCostOfLand, 0.001,
                "Incorrect calculation of the cost of land");
      }

      @Test
      @DisplayName("that behaves correctly depending on various values given")
      void testCostOfLandBehavior() {
        // base case
        double baseCase = Toolbelt.costOfLand(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);

        // cost of land with different wage
        double highWageCase = Toolbelt.costOfLand(baseParams.wage + deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        double lowWageCase = Toolbelt.costOfLand(baseParams.wage - deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        // cost of land with different distance from CBD
        double highDistanceFromCBDCase = Toolbelt.costOfLand(baseParams.wage, baseParams.distanceFromCBD + deltaParams.distanceFromCBD, baseParams.transportationCost);
        double lowDistanceFromCBDCase = Toolbelt.costOfLand(baseParams.wage, baseParams.distanceFromCBD - deltaParams.distanceFromCBD, baseParams.transportationCost);
        //cost of land with different transportation cost
        double highTransportationCostCase = Toolbelt.costOfLand(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost + deltaParams.transportationCost);
        double lowTransportationCostCase = Toolbelt.costOfLand(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost - deltaParams.transportationCost);

        // more wage -> more cost of land
        assertTrue(lowWageCase < baseCase, "The cost of land should increase with more wage \n less wage case: " + lowWageCase + " < more wage case: " + baseCase);
        assertTrue(baseCase < highWageCase, "The cost of land should increase with more wage \n less wage case: " + baseCase + " < more wage case: " + highWageCase);

        // more distance from CBD -> less cost of land
        assertTrue(baseCase < lowDistanceFromCBDCase, "The cost of land should decrease with the distance from the CBD \n more distance case: " + baseCase + " < less distance case: " + lowDistanceFromCBDCase);
        assertTrue(highDistanceFromCBDCase < baseCase, "The cost of land should decrease with the distance from the CBD\n more distance case: " + highDistanceFromCBDCase + " < less distance case: " + baseCase);

        // higher transportation cost -> less cost of land
        assertTrue(baseCase < lowTransportationCostCase, "The cost of land should decrease with higher transportation cost\n higher transportation cost case: " + baseCase + " < less transportation cost case: " + lowTransportationCostCase);
        assertTrue(highTransportationCostCase < baseCase, "The cost of land should decrease with higher transportation cost\n mroe transportation cost case: " + highTransportationCostCase + " < less transportation cost case: " + baseCase);
      }

      public static Stream< Arguments > invalidCostOfLandTestsProvider() {
        return Stream.of(
                arguments(6000.0, -500, 0.2), // Negative distanceFromCBD
                arguments(6000.0, 500, -0.2),  // Negative transportationCost
                arguments(-6000.0, 500, 0.2)  // Negative wage
        );
      }

      @DisplayName("that throws in case of invalid inputs")
      @ParameterizedTest(name = "inputs: {0}, {1}, {2}")
      @MethodSource("invalidCostOfLandTestsProvider")
      void testInvalidCostOfLand(double wage, int distanceFromCBD, double transportationCost) {
        assertThrows(IllegalArgumentException.class, () -> Toolbelt.costOfLand(wage, distanceFromCBD, transportationCost),
                "costOfLand should throw IllegalArgumentException for negative value");
      }
    }

    @Nested
    @DisplayName("should have a method to calculate the height of a building in a block")
    class heightPerBlock {

      public static Stream< Arguments > heightBlockTestsProvider() {
        return Stream.of(
                //wage, distanceFromCBD, transportationCost, expectedHeight
                arguments(100, 100, 11.1),
                arguments(9999999, 500, 100.0), //maximum value bound
                arguments(0, 1, 3.0) //minimum value bound
        );
      }

      @DisplayName("that return the expected value for a given set of valid values")
      @ParameterizedTest(name = "distance from CBD {0}, transport cost {1}")
      @MethodSource("heightBlockTestsProvider")
      void testHeightBlock(int distanceFromCBD, double transportationCost, double expectedHeight) {
        double actualHeight = Toolbelt.heightBlock( distanceFromCBD, transportationCost);
        assertEquals(expectedHeight, actualHeight, 0.1,
                "Incorrect calculation of height of a block" + actualHeight);
      }

      @Test
      @DisplayName("that behaves correctly depending on various values given")
      void testHeightBlockBehavior() {
        // base case
        double baseCase = Toolbelt.heightBlock(baseParams.distanceFromCBD, baseParams.costOfHousing);

        // height of a block with different distance from CBD
        double highDistanceFromCBDCase = Toolbelt.heightBlock( baseParams.distanceFromCBD + deltaParams.distanceFromCBD, baseParams.costOfHousing);
        double lowDistanceFromCBDCase = Toolbelt.heightBlock( baseParams.distanceFromCBD - deltaParams.distanceFromCBD, baseParams.costOfHousing);
        // height of a block with different cost of housing
        double highTransportationCostCase = Toolbelt.heightBlock(baseParams.distanceFromCBD, baseParams.costOfHousing + deltaParams.costOfHousing);
        double lowTransportationCostCase = Toolbelt.heightBlock(baseParams.distanceFromCBD, baseParams.costOfHousing - deltaParams.costOfHousing);

        // more distance from CBD -> building are smaller
        assertTrue(baseCase <= lowDistanceFromCBDCase, "The height of the building should decrease with the distance from the CBD \n less distance case: " + baseCase + " < high distance case: " + lowDistanceFromCBDCase);
        assertTrue(highDistanceFromCBDCase <= baseCase, "The height of the building should decrease with the distance from the CBD\n more distance case: " + highDistanceFromCBDCase + " < less distance case: " + baseCase);

        // higher cost of hosue -> smaller building
        assertTrue(baseCase <= lowTransportationCostCase, "The height of the building should decrease with higher cost of House\n higher  cost of House case: " + baseCase + " < less  cost of House case: " + lowTransportationCostCase);
        assertTrue(highTransportationCostCase <= baseCase, "The height of the building should decrease with higher cost of House\n higher  cost of House case: " + highTransportationCostCase + " < less  cost of House case: " + baseCase);

      }

      public static Stream< Arguments > invalidHeightBlockTestsProvider() {
        return Stream.of(
                arguments(-5, 200), // Negative distanceFromCBD
                arguments(5, -200)  // Negative transportationCost
        );
      }
      @DisplayName("that throws in case of invalid inputs")
      @ParameterizedTest(name = "inputs: {0}, {1}")
      @MethodSource("invalidHeightBlockTestsProvider")
      void testInvalidHeightBlock(int distanceFromCBD, double costOfHousing) {
        assertThrows(IllegalArgumentException.class, () -> Toolbelt.heightBlock(distanceFromCBD, costOfHousing),
                "heightBlock should throw IllegalArgumentException for negative value");
      }
    }

    @Nested
    @DisplayName("should have a method to calculate the density gradient")
    class densityGradient {

      @Test
      @DisplayName("and that return the expected value for a given set of valid values")
      void testDensityGradient() {
        double actualGradient = Toolbelt.densityGradient(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        assertEquals(52.44424093347515, actualGradient, 0.001,
                "Incorrect calculation of the density gradient.");
      }

      @Test
      @DisplayName("that behaves correctly depending on various values given")
      void testDensityGradientBehavior() {
        // base case
        double baseCase = Toolbelt.densityGradient(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);

        // Gradient with different wage
        double highWageCase = Toolbelt.densityGradient(baseParams.wage + deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        double lowWageCase = Toolbelt.densityGradient(baseParams.wage - deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        // Gradient with different distance from CBD
        double highDistanceFromCBDCase = Toolbelt.densityGradient(baseParams.wage, baseParams.distanceFromCBD + deltaParams.distanceFromCBD, baseParams.transportationCost);
        double lowDistanceFromCBDCase = Toolbelt.densityGradient(baseParams.wage, baseParams.distanceFromCBD - deltaParams.distanceFromCBD, baseParams.transportationCost);
        // Gradient with different transportation cost
        double highTransportationCostCase = Toolbelt.densityGradient(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost + deltaParams.transportationCost);
        double lowTransportationCostCase = Toolbelt.densityGradient(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost - deltaParams.transportationCost);

        // more wage -> more gradient
        assertTrue(lowWageCase < baseCase, "The gradient should be higher with more wage \n low wage case: " + lowWageCase + " < high wage case: " + baseCase);
        assertTrue(baseCase < highWageCase, "The gradient should be higher with more wage \n low wage case: " + baseCase + " < high wage case: " + highWageCase);

        // more distance from CBD -> less gradient
        assertTrue(highDistanceFromCBDCase < baseCase, "The gradient should decrease with the distance from the CBD\n low distance case: " + highDistanceFromCBDCase + " < high distance case: " + baseCase);
        assertTrue(baseCase < lowDistanceFromCBDCase, "The gradient should decrease with the distance from the CBD \n low distance case: " + baseCase + " < high distance case: " + lowDistanceFromCBDCase);

        // higher transportation cost -> less gradient relative to the center
        assertTrue(baseCase < lowTransportationCostCase, "The gradient should decrease with lower transportation cost\n higher transportation cost case: " + baseCase + " < lower transportation cost case: " + lowTransportationCostCase);
        assertTrue(highTransportationCostCase < baseCase, "The gradient should decrease with lower transportation cost\n higher transportation cost case: " + highTransportationCostCase + " < lower transportation cost case: " + baseCase);
      }

      public static Stream< Arguments > invalidDensityGradientTestsProvider() {
        return Stream.of(
                arguments(6000.0, -500, 0.2), // Negative distanceFromCBD
                arguments(6000.0, 500, -0.2),  // Negative transportationCost
                arguments(-6000.0, 500, 0.2)  // Negative wage
        );
      }

      @DisplayName("and that throws in case of invalid inputs")
      @ParameterizedTest(name = "inputs: {0}, {1}, {2}")
      @MethodSource("invalidDensityGradientTestsProvider")
      void testInvalidDensityGradient(double wage, int distanceFromCBD, double transportationCost) {
        assertThrows(IllegalArgumentException.class, () -> Toolbelt.densityGradient(wage, distanceFromCBD, transportationCost),
                "densityGradient should throw IllegalArgumentException for negative value");
      }
    }

    @Nested
    @DisplayName("should have a method to calculate where the city edge is")
    class cityEdge {
      @Test
      @DisplayName("that return the expected value for a given set of valid values")
      void testCityEdge() {
        int actualCityEdge = Toolbelt.cityEdge(baseParams.wage, baseParams.transportationCost);
        assertEquals(0, actualCityEdge,
                "Incorrect calculation of the city edge");
      }

      @Test
      @DisplayName("that behaves correctly depending on various values given")
      void testCityEdgeBehavior() {
        // base case
        int baseCase = Toolbelt.cityEdge(baseParams.wage, baseParams.transportationCost);

        // City edge with different wage
        int highWageCase = Toolbelt.cityEdge(baseParams.wage + deltaParams.wage, baseParams.transportationCost);
        int lowWageCase = Toolbelt.cityEdge(baseParams.wage - deltaParams.wage, baseParams.transportationCost);
        // City edge with different transportation cost
        int highTransportationCostCase = Toolbelt.cityEdge(baseParams.wage, baseParams.transportationCost + 50000 + 500*deltaParams.transportationCost);
        int lowTransportationCostCase = Toolbelt.cityEdge(baseParams.wage, baseParams.transportationCost - deltaParams.transportationCost);

        // more wage -> more city edge
        assertTrue(lowWageCase <= baseCase, "The city edge should be higher with more wage \n low wage case: " + lowWageCase + " < high wage case: " + baseCase);
        assertTrue(baseCase < highWageCase, "The city edge should be higher with more wage \n low wage case: " + baseCase + " < high wage case: " + highWageCase);
        assertTrue(lowWageCase < highWageCase, "The city edge should be higher with more wage \n low wage case: " + lowWageCase + " < high wage case: " + highWageCase);

        //note:difference very low with the imposed parameters
        assertTrue(baseCase <= lowTransportationCostCase, "The city edge should increase with lower transportation cost\n higher transportation cost case: " + baseCase + " < lower transportation cost case: " + lowTransportationCostCase);
        assertTrue(highTransportationCostCase <= baseCase, "The city edge should increase with lower transportation cost\n higher transportation cost case: " + highTransportationCostCase + " < lower transportation cost case: " + baseCase);
        assertTrue(highTransportationCostCase <= lowTransportationCostCase, "The city edge should increase with lower transportation cost\n higher transportation cost case: " + highTransportationCostCase + " < lower transportation cost case: " + lowTransportationCostCase);
      }
    }

    @Nested
    @DisplayName("should have a method to calculate the number of blocks")
    class numberOfBlock {
      public static Stream< Arguments > distanceValuesProvider() {
        return Stream.of(
                //distance from CBD
                arguments(10, 40),
                arguments(15, 60),
                arguments(0, 1) //exceptional case
        );
      }

      @DisplayName("at a given distance")
      @ParameterizedTest(name = "inputs: {0}")
      @MethodSource("distanceValuesProvider")
      void testNumberOfBlocksPerDistance(int distanceFromCBD, int expectedBlocksCount) {
        int actualBlocksCount = Toolbelt.numberOfBlocksPerDistance(distanceFromCBD);
        assertEquals(expectedBlocksCount, actualBlocksCount,
                "Incorrect result of number of blocks");
      }
      public static Stream< Integer > negativeDistanceProvider() {
        return Stream.of(-1, -5, -10);
      }

      @DisplayName("or throw if the given distance is negative")
      @ParameterizedTest(name = "inputs: {0}")
      @MethodSource("negativeDistanceProvider")
      void testNumberOfBlocksPerDistanceNegative(int distanceFromCBD) {
        assertThrows(IllegalArgumentException.class,
                () -> Toolbelt.numberOfBlocksPerDistance(distanceFromCBD),
                "Negative distance from CBD should throw");
      }
    }
    @Nested
    @DisplayName("should have a method to calculate the total population")
    class totalPopulation {

      @Test
      @DisplayName("that return the expected value for a given set of valid values")
      void testTotalPopulation() {

        int actualTotalPopulation = Toolbelt.totalPopulation(baseParams.wage, baseParams.transportationCost);
        assertEquals(128, actualTotalPopulation,
                "Incorrect calculation of total population");
      }

      @Test
      @DisplayName("that behaves correctly depending on various values given")
      void testTotalPopulationBehavior() {
        // base case
        int baseCase = Toolbelt.totalPopulation(baseParams.wage, baseParams.transportationCost);

        // total population with different wage
        int highWageCase = Toolbelt.totalPopulation(baseParams.wage + deltaParams.wage, baseParams.transportationCost);
        int lowWageCase = Toolbelt.totalPopulation(baseParams.wage - deltaParams.wage, baseParams.transportationCost);
        // total population with different transportation cost
        int highTransportationCostCase = Toolbelt.totalPopulation(baseParams.wage, baseParams.transportationCost + deltaParams.transportationCost);
        int lowTransportationCostCase = Toolbelt.totalPopulation(baseParams.wage, baseParams.transportationCost - deltaParams.transportationCost);

        // more wage -> more population
        assertTrue(lowWageCase < baseCase, "The total population should increase with more wage \n low wage case: " + lowWageCase + " < high wage case: " + baseCase);
        assertTrue(baseCase < highWageCase, "The total population should increase with more wage \n low wage case: " + baseCase + " < high wage case: " + highWageCase);

        //difference too small
        // higher transportation cost -> less population
        assertTrue(baseCase <= lowTransportationCostCase, "The total population should decrease with higher transportation cost \n low wage case: " + lowTransportationCostCase + " < high wage case: " + baseCase);
        assertTrue(highTransportationCostCase <= baseCase, "The total population should decrease with higher transportation cost \n low wage case: " + baseCase + " < high wage case: " + highTransportationCostCase);
        assertTrue(highTransportationCostCase <= lowTransportationCostCase, "The total population should decrease with higher transportation cost \n low wage case: " + lowTransportationCostCase + " < high wage case: " + highTransportationCostCase);
      }
    }

    @Nested
    @DisplayName("should have a method to calculate the population for each block")
    class populationPerBlock {

      @Test
      @DisplayName("that return the expected value for a given set of valid values")
      void testPopulationPerBlock() {
        int actualPopulation = Toolbelt.populationPerBlock(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        assertEquals(52, actualPopulation, 0.001,
                "Incorrect calculation of total population");
      }

      @Test
      @DisplayName("that behaves correctly depending on various values given")
      void testPopulationPerBlockBehavior() {
        // base case
        int baseCase = Toolbelt.populationPerBlock(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);

        // population per block with different wage
        double highWageCase = Toolbelt.populationPerBlock(baseParams.wage + deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        double lowWageCase = Toolbelt.populationPerBlock(baseParams.wage - deltaParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost);
        //  population per block different distance from CBD
        double highDistanceFromCBDCase = Toolbelt.populationPerBlock(baseParams.wage, baseParams.distanceFromCBD + deltaParams.distanceFromCBD, baseParams.transportationCost);
        double lowDistanceFromCBDCase = Toolbelt.populationPerBlock(baseParams.wage, baseParams.distanceFromCBD - deltaParams.distanceFromCBD, baseParams.transportationCost);
        //  population per block with different transportation cost
        double highTransportationCostCase = Toolbelt.populationPerBlock(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost + deltaParams.transportationCost);
        double lowTransportationCostCase = Toolbelt.populationPerBlock(baseParams.wage, baseParams.distanceFromCBD, baseParams.transportationCost - deltaParams.transportationCost);

        // more wage -> more population per block
        assertTrue(lowWageCase < baseCase, "The population per block should increase with more wage \n less wage case: " + lowWageCase + " < more wage case: " + baseCase);
        assertTrue(baseCase < highWageCase, "The population per block increase with more wage \n less wage case: " + baseCase + " < more wage case: " + highWageCase);

        // more distance from CBD -> less population per block
        assertTrue(baseCase < lowDistanceFromCBDCase, "The population per block should decrease with the distance from the CBD \n more distance case: " + baseCase + " < less distance case: " + lowDistanceFromCBDCase);
        assertTrue(highDistanceFromCBDCase < baseCase, "The population per block should decrease with the distance from the CBD\n more distance case: " + highDistanceFromCBDCase + " < less distance case: " + baseCase);

        // higher transportation cost -> less population per block
        assertTrue(baseCase < lowTransportationCostCase, "The population per block should decrease with higher transportation cost\n higher transportation cost case: " + baseCase + " < less transportation cost case: " + lowTransportationCostCase);
        assertTrue(highTransportationCostCase < baseCase, "The population per block should decrease with higher transportation cost\n higher transportation cost case: " + highTransportationCostCase + " < less transportation cost case: " + baseCase);
      }
    }
  }

  public static Stream<Arguments> constructionCostLimitPerBlockProvider() {
    return Stream.of(
            arguments(3, 103.9), //min
            arguments(50, 7071.1), //normal
            arguments(99, 19700.7) //max
    );
  }
  @ParameterizedTest(name = "with coordinates {0}")
  @DisplayName("The limit for the construction cost should be calculated correctly")
  @MethodSource("constructionCostLimitPerBlockProvider")
  void testConstructionCostLimitPerBlock(int height, double expectedCostLimit) {

    double actualCostLimit = Toolbelt.constructionCostLimitPerBlock(height);

    assertEquals(expectedCostLimit, actualCostLimit, 0.1,
            "Incorrect calculation of construction cost limit for height: " + height);
  }
  public static Stream< Arguments > invalidconstructionCostLimitPerBlockProvider() {
    return Stream.of(
            arguments(new int[]{-5, -6, -2}), //negative value
            arguments(new int[]{0, 1, 2}), //too low non negative
            arguments(new int[]{101, 241, 32423}) //too hight
    );
  }

  @DisplayName("The limit for the construction cost should throws in case of out-of-bound values")
  @ParameterizedTest(name = "inputs: {0}")
  @MethodSource("invalidconstructionCostLimitPerBlockProvider")
  void testInvalid(int[] heights) {
    for (int height : heights) {
      assertThrows(IllegalArgumentException.class, () -> Toolbelt.constructionCostLimitPerBlock(height),
              "constructionCostLimitPerBlock should throw IllegalArgumentException for negative value");
      }
    }

    @DisplayName("Should throw an exception when trying to instantiate Toolbelt class")
    @Test
    void testThrows() {
      assertThrows(Exception.class, () -> new Toolbelt());
    }
}