package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SortedMap;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@DisplayName("City Tests")
class CityTests {

    private City city;
    private BTypes newBlockType;

    // This method will set up the mock city and a new block type before each test
    void setUp() {
        city = mock(City.class);
        newBlockType = BTypes.RESIDENTIALBLOCK; // Replace SOME_TYPE with an actual value from BTypes enum
        doCallRealMethod().when(city).changeBlockTypes(anyList(), anyList(), any(BTypes.class));
    }

    @ParameterizedTest
    @DisplayName("Test changeBlockTypes with valid parameters")
    @CsvSource({
            "1,2,3, 4,5,6",  // Valid parameters
            "0,0,1, 0,0,1",  // Includes (0,0) which should be ignored
    })
    void testChangeBlockTypes_ValidParameters(String xCoords, String yCoords) {
        setUp();

        List<Integer> xCoordinates = Arrays.stream(xCoords.split(",")).map(Integer::parseInt).toList();
        List<Integer> yCoordinates = Arrays.stream(yCoords.split(",")).map(Integer::parseInt).toList();

        // Call the method
        city.changeBlockTypes(xCoordinates, yCoordinates, newBlockType);

        // Verify that changeBlockType was called correctly for valid coordinates
        for (int i = 0; i < xCoordinates.size(); i++) {
            int x = xCoordinates.get(i);
            int y = yCoordinates.get(i);
            if (x != 0 || y != 0) {
                verify(city).changeBlockType(x, y, newBlockType);
            } else {
                verify(city, never()).changeBlockType(x, y, newBlockType);
            }
        }
    }

    @Test
    @DisplayName("Test changeBlockTypes with mismatched list sizes")
    void testChangeBlockTypes_DifferentSizes() {
        setUp();

        List<Integer> xCoordinates = Arrays.asList(1, 2, 3);
        List<Integer> yCoordinates = Arrays.asList(4, 5);

        // Expect IllegalArgumentException when xCoordinates and yCoordinates have different sizes
        assertThrows(IllegalArgumentException.class, () -> {
            city.changeBlockTypes(xCoordinates, yCoordinates, newBlockType);
        });
    }

    @Test
    void testUpdateBlocks() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();
        city.updateBlocks(xCoordinates, new ArrayList<>(), 10.0d);
        assertEquals(0, city.getPopulationSize());
    }


    @Test
    void testUpdateBlocks2() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);

        ArrayList<Integer> xCoordinates = new ArrayList<>();
        xCoordinates.add(2);
        assertThrows(IllegalArgumentException.class, () -> city.updateBlocks(xCoordinates, new ArrayList<>(), 10.0d));
    }


    @Test
    void testUpdateBlocks3() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);

        ArrayList<Integer> xCoordinates = new ArrayList<>();
        xCoordinates.add(1);
        xCoordinates.add(2);
        assertThrows(IllegalArgumentException.class, () -> city.updateBlocks(xCoordinates, new ArrayList<>(), 10.0d));
    }


    @Test
    void testUpdateBlocks4() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();

        ArrayList<Integer> yCoordinates = new ArrayList<>();
        yCoordinates.add(2);
        assertThrows(IllegalArgumentException.class, () -> city.updateBlocks(xCoordinates, yCoordinates, 10.0d));
    }


    @Test
    void testUpdateBlocks5() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();

        ArrayList<Integer> yCoordinates = new ArrayList<>();
        yCoordinates.add(1);
        yCoordinates.add(2);
        assertThrows(IllegalArgumentException.class, () -> city.updateBlocks(xCoordinates, yCoordinates, 10.0d));
    }


    @Test
    void testUpdateLocalConstructionLimit() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();
        city.updateLocalConstructionLimit(xCoordinates, new ArrayList<>(), 10.0d);
        assertEquals(0, city.getPopulationSize());
        assertEquals(1, city.getBlocks().size());
        assertEquals(10.0d, city.getRentLimit());
        assertEquals(10.0d, city.getTransportationCost());
        assertEquals(10.0d, city.getWage());
        assertEquals(Double.NaN, city.getConstructionCostLimit());
    }


    @Test
    void testUpdateLocalConstructionLimit2() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();

        ArrayList<Integer> yCoordinates = new ArrayList<>();
        yCoordinates.add(2);
        city.updateLocalConstructionLimit(xCoordinates, yCoordinates, 10.0d);
        assertEquals(0, city.getPopulationSize());
        assertEquals(1, city.getBlocks().size());
        assertEquals(10.0d, city.getRentLimit());
        assertEquals(10.0d, city.getTransportationCost());
        assertEquals(10.0d, city.getWage());
        assertEquals(Double.NaN, city.getConstructionCostLimit());
    }


    @Test
    void testUpdateLocalConstructionLimit3() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();

        ArrayList<Integer> yCoordinates = new ArrayList<>();
        yCoordinates.add(1);
        yCoordinates.add(2);
        city.updateLocalConstructionLimit(xCoordinates, yCoordinates, 10.0d);
        assertEquals(0, city.getPopulationSize());
        assertEquals(1, city.getBlocks().size());
        assertEquals(10.0d, city.getRentLimit());
        assertEquals(10.0d, city.getTransportationCost());
        assertEquals(10.0d, city.getWage());
        assertEquals(Double.NaN, city.getConstructionCostLimit());
    }


    @Test
    void testUpdateLocalRentLimits() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();
        city.updateLocalRentLimits(xCoordinates, new ArrayList<>(), 10.0d);
        assertEquals(0, city.getPopulationSize());
        assertEquals(1, city.getBlocks().size());
        assertEquals(10.0d, city.getRentLimit());
        assertEquals(10.0d, city.getTransportationCost());
        assertEquals(10.0d, city.getWage());
        assertEquals(Double.NaN, city.getConstructionCostLimit());
    }


    @Test
    void testUpdateLocalRentLimits2() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);

        ArrayList<Integer> xCoordinates = new ArrayList<>();
        xCoordinates.add(2);
        assertThrows(IllegalArgumentException.class,
                () -> city.updateLocalRentLimits(xCoordinates, new ArrayList<>(), 10.0d));
    }


    @Test
    void testUpdateLocalRentLimits3() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);

        ArrayList<Integer> xCoordinates = new ArrayList<>();
        xCoordinates.add(1);
        xCoordinates.add(2);
        assertThrows(IllegalArgumentException.class,
                () -> city.updateLocalRentLimits(xCoordinates, new ArrayList<>(), 10.0d));
    }


    @Test
    void testUpdateLocalRentLimits4() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();

        ArrayList<Integer> yCoordinates = new ArrayList<>();
        yCoordinates.add(2);
        assertThrows(IllegalArgumentException.class, () -> city.updateLocalRentLimits(xCoordinates, yCoordinates, 10.0d));
    }


    @Test
    void testUpdateLocalRentLimits5() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        ArrayList<Integer> xCoordinates = new ArrayList<>();

        ArrayList<Integer> yCoordinates = new ArrayList<>();
        yCoordinates.add(1);
        yCoordinates.add(2);
        assertThrows(IllegalArgumentException.class, () -> city.updateLocalRentLimits(xCoordinates, yCoordinates, 10.0d));
    }


    @Test
    void testChangeBlockType1() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        city.changeBlockType(Integer.MIN_VALUE, Integer.MIN_VALUE, BTypes.RESIDENTIALBLOCK);
        SortedMap<Integer, Block> blocks = city.getBlocks();
        assertEquals(1, blocks.size());
        Block getResult = blocks.get(961);
        assertEquals(0, getResult.getDistanceFromCenter());
        assertEquals(0, city.getPopulationSize());
        assertEquals(0, ((ResidentialBlock) getResult).getNumberOfPeople());
        assertEquals((int) (1.4274683055608695d * 100), (int) (((ResidentialBlock) getResult).getCostOfRent() * 100));
        assertEquals(10.0d, ((ResidentialBlock) getResult).getRentLimit());
        assertEquals(10.0d, ((ResidentialBlock) getResult).getTransportationCost());
        assertEquals(103.92304845413264d, ((ResidentialBlock) getResult).getConstructionCost());
        assertEquals(3, ((ResidentialBlock) getResult).getHeight());
        assertEquals(BTypes.RESIDENTIALBLOCK, getResult.getType());
        assertEquals(Double.NaN, ((ResidentialBlock) getResult).getConstructionCostLimit());
        assertEquals(Integer.MIN_VALUE, getResult.getX());
        assertEquals(Integer.MIN_VALUE, getResult.getY());
    }


    @Test
    void testChangeBlockType2() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        city.changeBlockType(Integer.MIN_VALUE, 3, BTypes.WATERBLOCK);
        SortedMap<Integer, Block> blocks = city.getBlocks();
        assertEquals(2, blocks.size());
        Block getResult = blocks.get(-2147482684);
        assertEquals(-2147483645, getResult.getDistanceFromCenter());
        assertEquals(3, getResult.getY());
        assertEquals(BTypes.WATERBLOCK, getResult.getType());
        assertEquals(Integer.MIN_VALUE, getResult.getX());
    }


    @Test
    void testChangeBlockType3() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        city.changeBlockType(Integer.MIN_VALUE, 3, BTypes.PARKBLOCK);
        SortedMap<Integer, Block> blocks = city.getBlocks();
        assertEquals(2, blocks.size());
        Block getResult = blocks.get(-2147482684);
        assertEquals(-2147483645, getResult.getDistanceFromCenter());
        assertEquals(3, getResult.getY());
        assertEquals(BTypes.PARKBLOCK, getResult.getType());
        assertEquals(Integer.MIN_VALUE, getResult.getX());
    }


    @Test
    void testChangeBlockType4() {
        City city = new City(10.0d, 10.0d, Double.NaN, 0.5d);
        city.changeBlockType(Integer.MIN_VALUE, Integer.MIN_VALUE, BTypes.RESIDENTIALBLOCK);
        SortedMap<Integer, Block> blocks = city.getBlocks();
        assertEquals(1, blocks.size());
        Block getResult = blocks.get(961);
        assertEquals(0, getResult.getDistanceFromCenter());
        assertEquals(0, city.getPopulationSize());
        assertEquals(0, ((ResidentialBlock) getResult).getNumberOfPeople());
        assertEquals(0.5d, ((ResidentialBlock) getResult).getCostOfRent());
        assertEquals(0.5d, ((ResidentialBlock) getResult).getRentLimit());
        assertEquals(10.0d, ((ResidentialBlock) getResult).getTransportationCost());
        assertEquals(103.92304845413264d, ((ResidentialBlock) getResult).getConstructionCost());
        assertEquals(3, ((ResidentialBlock) getResult).getHeight());
        assertEquals(BTypes.RESIDENTIALBLOCK, getResult.getType());
        assertEquals(Double.NaN, ((ResidentialBlock) getResult).getConstructionCostLimit());
        assertEquals(Integer.MIN_VALUE, getResult.getX());
        assertEquals(Integer.MIN_VALUE, getResult.getY());
    }

    @Test
    void testChangeBlockType5() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        city.changeBlockType(Integer.MIN_VALUE, Integer.MIN_VALUE, BTypes.WATERBLOCK);
        SortedMap<Integer, Block> blocks = city.getBlocks();
        assertEquals(1, blocks.size());
        Block getResult = blocks.get(961);
        assertEquals(0, getResult.getDistanceFromCenter());
        assertEquals(0, city.getPopulationSize());
        assertEquals(BTypes.WATERBLOCK, getResult.getType());
        assertEquals(Integer.MIN_VALUE, getResult.getX());
        assertEquals(Integer.MIN_VALUE, getResult.getY());
    }


    @Test
    void testChangeBlockType6() {
        City city = new City(10.0d, 10.0d, Double.NaN, 10.0d);
        city.changeBlockType(Integer.MIN_VALUE, Integer.MIN_VALUE, BTypes.PARKBLOCK);
        SortedMap<Integer, Block> blocks = city.getBlocks();
        assertEquals(1, blocks.size());
        Block getResult = blocks.get(961);
        assertEquals(0, getResult.getDistanceFromCenter());
        assertEquals(0, city.getPopulationSize());
        assertEquals(BTypes.PARKBLOCK, getResult.getType());
        assertEquals(Integer.MIN_VALUE, getResult.getX());
        assertEquals(Integer.MIN_VALUE, getResult.getY());
    }

    @Test
    void testUpdateBlock() {
        City city = new City(10000, 2000, 500, 1000);
        ResidentialBlock oldBlock = (ResidentialBlock) City.findBlockByCoordinate(city, 0, 0);
        double newTransportationCost = 1500;
        int numberOfPeopleInBlock = Toolbelt.populationPerBlock(10000, 0, newTransportationCost);
        int expectedResult = numberOfPeopleInBlock - oldBlock.getNumberOfPeople();
        int result = city.updateBlock(0, 0, newTransportationCost);
        assertEquals(expectedResult, result);
    }


}
