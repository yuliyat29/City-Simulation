package ch.usi.inf.bsc.sa4.lab02spring.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class BlockTests {
    private Block block;
    private static final BTypes TEST_TYPE = BTypes.RESIDENTIALBLOCK;

    @BeforeEach
    public void setUp() {
        block = new Block(5, 7, TEST_TYPE);
    }

    @Test
    public void testConstructor() {
        assertEquals(5, block.getX());
        assertEquals(7, block.getY());
        assertEquals(TEST_TYPE, block.getType());
        assertEquals(12, block.getDistanceFromCenter()); // Assuming (0,0) is the center and using taxicab distance
    }

    @Test
    public void testSetX() {
        block.setX(10);
        assertEquals(10, block.getX());
    }

    @Test
    public void testSetY() {
        block.setY(15);
        assertEquals(15, block.getY());
    }

    @Test
    public void testSetType() {
        block.setType(BTypes.WATERBLOCK);
        assertEquals(BTypes.WATERBLOCK, block.getType());
    }
}
