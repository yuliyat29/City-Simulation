package ch.usi.inf.bsc.sa4.lab02spring.controller;

import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.*;
import ch.usi.inf.bsc.sa4.lab02spring.model.*;
import ch.usi.inf.bsc.sa4.lab02spring.service.OldSimulationService;
import ch.usi.inf.bsc.sa4.lab02spring.service.SimulationService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;

import java.util.*;


import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.mockito.BDDMockito.given;

@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("The simulation controller")
public class SimulationControllerTests {

    // Mock the depending services
    @MockBean
    private SimulationService simulationService;

    @MockBean
    private OldSimulationService oldSimulationService;

    // fluent API to perform REST calls
    // in the context of testing.
    @Autowired
    private MockMvc mockMvc;

    // This is from Jackson, a JSON serialization API.
    @Autowired
    private ObjectMapper objectMapper;

    @DisplayName(" after getting user's simulations")
    @Nested
    class WhenGettingUsersSimulations {

        List<SimulationDTO> simulationsOfUser1 = new ArrayList<>();
        String email1 = "alant@usi.ch";
        int listSize = 3;
        FakeUser fakeUser;
        ResultActions postResult;
        GetMySimulationsDTO getMySimulationsDTO;
        GetMySimulationsDTO getMySimulationsDTOWithNull;

        @BeforeEach
        void setup() throws Exception {
            fakeUser = new FakeUser(email1, "User1");
            getMySimulationsDTO = new GetMySimulationsDTO("populationSize", true, 0, listSize);
            getMySimulationsDTOWithNull = new GetMySimulationsDTO("populationSize", null, 0, listSize);
            given(simulationService.getUsersSimulations(
                    email1,
                    Sort.by(Sort.Direction.ASC, getMySimulationsDTO.param()),
                    getMySimulationsDTO.limit(),
                    getMySimulationsDTO.offset()
            )).willReturn(simulationsOfUser1);

            for (int i = 0; i < listSize; i++) {
                SimulationDTO simulationDTO = new SimulationDTO(
                        "simulation" + i,
                        1000 + i,
                        12000 + i,
                        2000 + i,
                        10000 + i,
                        5000,
                        "Simulation" + i,
                        email1,
                        false,
                        "",
                        new City(12000 + i, 2000 + i, 10000 + i, 4000)
                );

                simulationsOfUser1.add(simulationDTO);
            }

            postResult = mockMvc.perform(post("/simulations/my")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(getMySimulationsDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser.getToken()))
            );

        }

        @DisplayName(" should return 200 OK when getting user's simulations")
        @Test
        public void testGetUserSimulationStatus() throws Exception {
            postResult.andExpect(status().isOk());
        }

        @DisplayName(" should return simulations belonging to the user")
        @Test
        public void testCorrectOwner() throws Exception {
            List<SimulationDTO> responseList = objectMapper.readValue(
                    postResult.andReturn().getResponse().getContentAsString(),
                    new TypeReference<List<SimulationDTO>>() {
                    }
            );
            boolean isCorrectOwner = responseList.stream().allMatch(simulationDTO ->
                    email1.equals(simulationDTO.authorEmail())
            );
            assertTrue(isCorrectOwner);
        }

    }

    @DisplayName(" after getting all simulations")
    @Nested
    class WhenGettingAllSimulations {

        List<Simulation> allSimulations = new ArrayList<>();
        String email = "alant@usi.ch";
        int listSize = 7;
        FakeUser fakeUser;
        ResultActions getResult;

        @BeforeEach
        void setup() throws Exception {
            fakeUser = new FakeUser(email, "User");
            given(simulationService.getAll()).willReturn(allSimulations);

            for (int i = 0; i < listSize; i++) {
                Simulation simulation = new Simulation(
                        12000 + i,
                        2000 + i,
                        10000 + i,
                        5000,
                        "Simulation" + i,
                        "email" + i,
                        false,
                        "",
                        new Date(),
                        null
                );
                simulation.set_id(new ObjectId());

                allSimulations.add(simulation);
            }

            getResult = mockMvc.perform(get("/simulations")
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser.getToken()))
            );

        }

        @DisplayName(" should return 200 OK when getting all simulations")
        @Test
        void testGetAllStatus() throws Exception {
            getResult.andExpect(status().isOk());
        }

        @DisplayName(" should return the correct number of simulations ")
        @Test
        public void testCorrectNumberOfSimulations() throws Exception {
            List<SimulationDTO> responseList = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    List.class
            );
            assertEquals(listSize, responseList.size());
        }

        @DisplayName(" should return correct simulations")
        @Test
        public void testCorrectSimulations() throws Exception {
            List<SimulationDTO> responseList = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    new TypeReference<List<SimulationDTO>>() {
                    }
            );
            for (int i = 0; i < listSize; i++) {
                assertEquals("Simulation" + i, responseList.get(i).simulationName());
                assertEquals("email" + i, responseList.get(i).authorEmail());
            }
        }

    }

    @DisplayName(" after counting simulations for current user")
    @Nested
    class WhenCountingSimulationsForCurrentUser {

        String email1 = "alant@usi.ch";
        FakeUser fakeUser1;
        long numberOfSimulations1 = 8;
        ResultActions getResult;

        @BeforeEach
        void setup() throws Exception {
            fakeUser1 = new FakeUser(email1, "User1");
            given(simulationService.countSimulationByEmail(email1)).willReturn(numberOfSimulations1);
            getResult = mockMvc.perform(get("/simulations/countSimulations")
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            );
        }

        @DisplayName(" should return 200 OK for a current user")
        @Test
        public void testStatus() throws Exception {
            getResult.andExpect(status().isOk());
        }

        @DisplayName(" should return the correct number")
        @Test
        public void testCorrectNumber() throws Exception {
            assertEquals(numberOfSimulations1 + "", getResult.andReturn().getResponse().getContentAsString());
        }

    }

    @DisplayName(" after getting simulation")
    @Nested
    class WhenGettingSimulation {

        String email1 = "alant@usi.ch";
        Simulation testSimulation;
        FakeUser fakeUser1;
        FakeUser fakeUser2;

        @BeforeEach
        void setup() {
            fakeUser1 = new FakeUser(email1, "User1");
            fakeUser2 = new FakeUser("otherEmail", "User2");
            testSimulation = new Simulation(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Test Simulation",
                    email1,
                    true,
                    "test_picture",
                    new Date(),
                    null
            );
            testSimulation.set_id(new ObjectId());
            given(simulationService.getSimulationById(testSimulation.get_id().toString())).willReturn(testSimulation);
        }

        @DisplayName(" should return 200 OK if the simulation is accessed by its owner")
        @Test
        public void testGetSimulationByOwner() throws Exception {
            mockMvc.perform(
                    get("/simulations/{simulationId}", testSimulation.get_id().toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return 401 Unauthorized if the simulation is not accessed by its owner")
        @Test
        public void testGetSimulationByNotOwner() throws Exception {
            mockMvc.perform(
                    get("/simulations/{simulationId}", testSimulation.get_id().toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser2.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return the correct result")
        @Test
        public void testCorrectResult() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    get("/simulations/{simulationId}", testSimulation.get_id().toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            ).andExpect(status().isOk());
            SimulationDTO simulationResultDTO = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    SimulationDTO.class
            );
            assertEquals(testSimulation.getCity().getPopulationSize(), simulationResultDTO.populationSize());
            assertEquals(testSimulation.getCity().getWage(), simulationResultDTO.wage());
            assertEquals(testSimulation.getCity().getTransportationCost(), simulationResultDTO.transportationCost());
            assertEquals(testSimulation.getSimulationName(), simulationResultDTO.simulationName());
            assertEquals(testSimulation.getAuthorEmail(), simulationResultDTO.authorEmail());
            assertEquals(testSimulation.getSimulationPicture(), simulationResultDTO.simulationPicture());
            assertEquals(testSimulation.isPublic(), simulationResultDTO.isPublic());
        }

    }

    @DisplayName(" after adding simulation")
    @Nested
    class WhenAddingSimulation {

        String userEmail;
        FakeUser fakeUser;
        FakeUser fakeInvalidUser;
        ResultActions postResult;
        CreateSimulationDTO createSimulationDTO;
        Simulation simulation;
        SimulationDTO response;

        @BeforeEach
        void setup() throws Exception {
            userEmail = "test@example.com";
            fakeUser = new FakeUser(userEmail, "User");
            fakeInvalidUser = new FakeUser(null, "InvalidUser");
            simulation = new Simulation(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Test Simulation",
                    userEmail,
                    false,
                    "",
                    new Date(),
                    null
            );
            simulation.set_id(new ObjectId());
            createSimulationDTO = new CreateSimulationDTO(
                    12000,
                    2000,
                    10000,
                    5000,
                    "Test Simulation"
            );
            response = new SimulationDTO(simulation);
            given(simulationService.createSimulation(createSimulationDTO, userEmail)).willReturn(response);
            postResult = mockMvc.perform(post("/simulations/addSimulation")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(createSimulationDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser.getToken()))
            );
        }

        @DisplayName(" should return 201 Created response if the simulation is successfully added")
        @Test
        public void testCreatedResponse() throws Exception {
            postResult.andExpect(status().isCreated());
        }

        @DisplayName(" should return 401 Unauthorized when an invalid user tries to add a simulation")
        @Test
        public void testUnauthorizedResponse() throws Exception {
            mockMvc.perform(post("/simulations/addSimulation")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(createSimulationDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeInvalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return the correct simulation")
        @Test
        public void testCorrectSimulation() {
            assertEquals(createSimulationDTO.transportationCost(), response.transportationCost());
            assertEquals(createSimulationDTO.wage(), response.wage());
            assertEquals(createSimulationDTO.simulationName(), response.simulationName());
        }

    }

    @DisplayName(" after making simulation public")
    @Nested
    class WhenMakingSimulationPublic {

        String email = "alant@usi.ch";
        String otherEmail = "graceh@usi.ch";
        FakeUser fakeUser1;
        FakeUser fakeUser2;
        String simulationId = "123";
        SimulationLinkDTO expectedResponse = new SimulationLinkDTO("http://localhost:3000/simulations/shared/123");
        SimulationIdDTO simulationIdDTO = new SimulationIdDTO(simulationId);

        @BeforeEach
        void setup() {
            fakeUser1 = new FakeUser(email, "User1");
            fakeUser2 = new FakeUser(otherEmail, "User2");
            given(simulationService.getAuthorEmail(simulationId)).willReturn(email);
            given(simulationService.makePublic(simulationId)).willReturn(expectedResponse);
        }

        @Test
        @DisplayName(" should return 202 ACCEPTED if the simulation is made public by the owner")
        public void testMakePublicByOwner() throws Exception {
            mockMvc.perform(post("/simulations/makePublic")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(simulationIdDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            ).andExpect(status().isAccepted());
        }

        @Test
        @DisplayName(" should return 401 UNAUTHORIZED if the simulation is not made public by the owner")
        public void testMakePublicByNonOwner() throws Exception {
            mockMvc.perform(post("/simulations/makePublic")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(simulationIdDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser2.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return the correct link")
        @Test
        public void testCorrectLink() throws Exception {
            ResultActions postResult = mockMvc.perform(post("/simulations/makePublic")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(simulationIdDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            );
            SimulationLinkDTO responseLinkDTO = objectMapper.readValue(
                    postResult.andReturn().getResponse().getContentAsString(),
                    SimulationLinkDTO.class
            );
            assertEquals(expectedResponse.link(), responseLinkDTO.link());
        }
    }

    @DisplayName(" after updating simulation")
    @Nested
    class WhenUpdatingSimulation {

        String email = "alant@usi.ch";
        String otherEmail = "graceh@usi.ch";
        FakeUser fakeUser1;
        FakeUser fakeUser2;
        String simulationId = "123";
        UpdateSimulationDTO updateDTO = new UpdateSimulationDTO(
                simulationId,
                12000,
                2000,
                10000,
                5000,
                "Updated Simulation"
        );
        SimulationDTO expectedResponse = new SimulationDTO(
                simulationId,
                1500,
                12000,
                2000,
                10000,
                5000,
                "Updated Simulation",
                email,
                false,
                "",
                new City(12000, 2000, 10000, 5000)
        );

        @BeforeEach
        void setup() {
            fakeUser1 = new FakeUser(email, "User1");
            fakeUser2 = new FakeUser(otherEmail, "User2");
            given(simulationService.getAuthorEmail(simulationId)).willReturn(email);
            given(simulationService.updateSimulation(updateDTO)).willReturn(expectedResponse);
        }

        @Test
        @DisplayName(" should return 201 CREATED if the simulation is updated by the owner")
        public void testUpdateSimulationByOwner() throws Exception {
            mockMvc.perform(post("/simulations/updateSimulation")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            ).andExpect(status().isCreated());
        }

        @Test
        @DisplayName(" should return 401 UNAUTHORIZED if the simulation is not updated by the owner")
        public void testUpdateSimulationByNonOwner() throws Exception {
            mockMvc.perform(post("/simulations/updateSimulation")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser2.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return the correct result")
        @Test
        public void testCorrectResult() throws Exception {
            ResultActions postResult = mockMvc.perform(post("/simulations/updateSimulation")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            );
            SimulationDTO responseSimulationDTO = objectMapper.readValue(
                    postResult.andReturn().getResponse().getContentAsString(),
                    SimulationDTO.class
            );
            assertEquals(expectedResponse._id(), responseSimulationDTO._id());
            assertEquals(expectedResponse.populationSize(), responseSimulationDTO.populationSize());
            assertEquals(expectedResponse.transportationCost(), responseSimulationDTO.transportationCost());
            assertEquals(expectedResponse.wage(), responseSimulationDTO.wage());
            assertEquals(expectedResponse.simulationName(), responseSimulationDTO.simulationName());
            assertEquals(expectedResponse.authorEmail(), responseSimulationDTO.authorEmail());
            assertEquals(expectedResponse.isPublic(), responseSimulationDTO.isPublic());
            assertEquals(expectedResponse.simulationPicture(), responseSimulationDTO.simulationPicture());
        }

    }

    @DisplayName(" after making simulation private")
    @Nested
    class WhenMakingSimulationPrivate {

        SimulationIdDTO simulationIdDTO;
        SimulationLinkDTO simulationLinkDTO;
        String email = "alant@usi.ch";
        String otherEmail = "graceh@usi.ch";
        FakeUser fakeUser1;
        FakeUser fakeUser2;

        @BeforeEach
        void setup() {
            fakeUser1 = new FakeUser(email, "User1");
            fakeUser2 = new FakeUser(otherEmail, "User2");
            simulationIdDTO = new SimulationIdDTO("validId");
            simulationLinkDTO = new SimulationLinkDTO("http://localhost:3000/simulations/shared/" + simulationIdDTO.id());
            given(simulationService.getAuthorEmail(simulationIdDTO.id())).willReturn(email);
            given(simulationService.makePrivate(simulationIdDTO.id())).willReturn(simulationLinkDTO);
        }

        @DisplayName(" should return response status 401 Unauthorized when trying to modify another user's simulation")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/makePrivate")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(simulationIdDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser2.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 202 Accepted when user modifies their own simulation")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/makePrivate")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(simulationIdDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            ).andExpect(status().isAccepted());
        }

        @DisplayName(" should return the correct link")
        @Test
        public void testCorrectLink() throws Exception {
            ResultActions postResult = mockMvc.perform(post("/simulations/makePrivate")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(simulationIdDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser1.getToken()))
            );
            SimulationLinkDTO responseLinkDTO = objectMapper.readValue(
                    postResult.andReturn().getResponse().getContentAsString(),
                    SimulationLinkDTO.class
            );
            assertEquals(simulationLinkDTO.link(), responseLinkDTO.link());
        }

    }

    @DisplayName(" after getting shared simulation")
    @Nested
    class WhenGettingSharedSimulation {

        String publicId = "publicId";
        String privateId = "privateId";
        Simulation publicSimulation;
        Simulation privateSimulation;
        FakeUser fakeUser;

        @BeforeEach
        void setup() {
            fakeUser = new FakeUser("alant@usi.ch", "User1");
            publicSimulation = new Simulation(
                    12000,
                    2000,
                    10000,
                    5000,
                    "PublicSimulation",
                    "alant@usi.ch",
                    true,
                    "",
                    new Date(),
                    null
            );
            publicSimulation.set_id(new ObjectId());
            privateSimulation = new Simulation(
                    12000,
                    2000,
                    10000,
                    5000,
                    "PrivateSimulation",
                    "gareceh@usi.ch",
                    false,
                    "",
                    new Date(),
                    null
            );
            privateSimulation.set_id(new ObjectId());
            given(simulationService.getSimulationById(publicId)).willReturn(publicSimulation);
            given(simulationService.getSimulationById(privateId)).willReturn(privateSimulation);
        }

        @DisplayName(" should return 200 OK when getting public simulation")
        @Test
        public void testOkStatus() throws Exception {
            mockMvc.perform(get("/simulations/shared/" + publicId)
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return 401 Unauthorized when getting private simulation")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(get("/simulations/shared/" + privateId)
                    .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

    }

    @DisplayName(" after counting user simulations")
    @Nested
    class WhenCountingUserSimulations {

        @DisplayName(" should return 200, after counted user simulations")
        @Nested
        class CountUserSimulations {
            String userEmail = "test@example.com";
            long expectedSimulationCount = 10;
            FakeUser fakeUser;

            @Test
            @DisplayName("should return 200 OK")
            void testResponseStatusOK() throws Exception {
                fakeUser = new FakeUser(userEmail, "User");
                given(simulationService.countSimulationByEmail(userEmail)).willReturn(expectedSimulationCount);

                mockMvc.perform(post("/simulations/countUserSimulations")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(objectMapper.writeValueAsString(userEmail))
                        .with(SecurityMockMvcRequestPostProcessors.authentication(fakeUser.getToken()))).andExpect(status().isOk());

            }
        }

    }

    @DisplayName(" after getting old simulation")
    @Nested
    class WhenGettingOldSimulation {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        ObjectId id = new ObjectId();
        ObjectId parentId = new ObjectId();
        OldSimulation oldSimulation;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            oldSimulation = new OldSimulation(
                    id,
                    parentId,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            given(oldSimulationService.getSimulationById(id.toString())).willReturn(oldSimulation);
        }

        @DisplayName(" should return response status 401 Unauthorized when a simulation is not accessed by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(
                    get("/simulations/getOldSimulation/{simulationId}", id.toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 200 OK when a simulation is accessed by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(
                    get("/simulations/getOldSimulation/{simulationId}", id.toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return the correct DTO")
        @Test
        public void testCorrectDTO() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    get("/simulations/getOldSimulation/{simulationId}", id.toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isOk());
            OldSimulationDTO oldSimulationDTO  = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    OldSimulationDTO.class
            );
            assertEquals(id.toString(), oldSimulationDTO._id());
            assertEquals(parentId.toString(), oldSimulationDTO.parentId());
            assertEquals("Simulation1", oldSimulationDTO.simulationName());
            assertEquals(validEmail, oldSimulationDTO.authorEmail());
            assertFalse(oldSimulationDTO.isPublic());
            assertEquals("", oldSimulationDTO.simulationPicture());
            assertEquals(10000, oldSimulationDTO.wage());
            assertEquals(2000, oldSimulationDTO.transportationCost());
            assertEquals(500, oldSimulationDTO.constructionCostLimit());
            assertEquals(1000, oldSimulationDTO.rentLimit());
        }

    }

    @DisplayName(" after updating transportation costs")
    @Nested
    class WhenUpdatingTransportationCosts {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        UpdateTransportationCostDTO updateTransportationCostDTO;
        ObjectId id = new ObjectId();
        SimulationDTO simulationDTO;
        Simulation simulation;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            updateTransportationCostDTO = new UpdateTransportationCostDTO(
                    id.toString(),
                    List.of(0, 1),
                    List.of(0, 1),
                    1000
            );
            simulation = new Simulation(
                    id,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            simulationDTO =  new SimulationDTO(simulation);

            given(simulationService.getAuthorEmail(id.toString())).willReturn(validEmail);
            given(simulationService.updateTransportationCost(
                    updateTransportationCostDTO.simulationId(),
                    updateTransportationCostDTO.xCoordinates(),
                    updateTransportationCostDTO.yCoordinates(),
                    updateTransportationCostDTO.newTransportationCost()
            )).willReturn(simulationDTO);
        }

        @DisplayName(" should return response status 401 Unauthorized when a simulation is not modified by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateTransportationCost")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateTransportationCostDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 201 Created when a simulation is modified by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateTransportationCost")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateTransportationCostDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isCreated());
        }

        @DisplayName(" should return the correct DTO")
        @Test
        public void testCorrectDTO() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    post("/simulations/updateTransportationCost")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(updateTransportationCostDTO))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            SimulationDTO responseSimulationDTO = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    SimulationDTO.class
            );
            assertEquals(id.toString(), responseSimulationDTO._id());
            assertEquals("Simulation1", responseSimulationDTO.simulationName());
            assertEquals(validEmail, responseSimulationDTO.authorEmail());
            assertFalse(responseSimulationDTO.isPublic());
            assertEquals("", responseSimulationDTO.simulationPicture());
            assertEquals(10000, responseSimulationDTO.wage());
            assertEquals(2000, responseSimulationDTO.transportationCost());
            assertEquals(500, responseSimulationDTO.constructionCostLimit());
            assertEquals(1000, responseSimulationDTO.rentLimit());
        }

    }

    @DisplayName(" after updating construction costs")
    @Nested
    class WhenUpdatingConstructionCosts {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        UpdateConstructionCostDTO updateConstructionCostDTO;
        ObjectId id = new ObjectId();
        SimulationDTO simulationDTO;
        Simulation simulation;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            updateConstructionCostDTO = new UpdateConstructionCostDTO(
                    id.toString(),
                    List.of(0, 1),
                    List.of(0, 1),
                    200
            );
            simulation = new Simulation(
                    id,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            simulationDTO = new SimulationDTO(simulation);

            given(simulationService.getAuthorEmail(id.toString())).willReturn(validEmail);
            given(simulationService.updateLocalConstructionCostLimit(
                    updateConstructionCostDTO.simulationId(),
                    updateConstructionCostDTO.xCoordinates(),
                    updateConstructionCostDTO.yCoordinates(),
                    updateConstructionCostDTO.newConstructionCostLimit()
            )).willReturn(simulationDTO);
        }

        @DisplayName(" should return response status 401 Unauthorized when a simulation is not modified by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateConstructionCost")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateConstructionCostDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 201 Created when a simulation is modified by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateConstructionCost")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateConstructionCostDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isCreated());
        }

        @DisplayName(" should return the correct DTO")
        @Test
        public void testCorrectDTO() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    post("/simulations/updateConstructionCost")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(updateConstructionCostDTO))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            SimulationDTO responseSimulationDTO = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    SimulationDTO.class
            );
            assertEquals(id.toString(), responseSimulationDTO._id());
            assertEquals("Simulation1", responseSimulationDTO.simulationName());
            assertEquals(validEmail, responseSimulationDTO.authorEmail());
            assertFalse(responseSimulationDTO.isPublic());
            assertEquals("", responseSimulationDTO.simulationPicture());
            assertEquals(10000, responseSimulationDTO.wage());
            assertEquals(2000, responseSimulationDTO.transportationCost());
            assertEquals(500, responseSimulationDTO.constructionCostLimit());
            assertEquals(1000, responseSimulationDTO.rentLimit());
        }

    }

    @DisplayName(" after updating local rent limit")
    @Nested
    class WhenUpdatingLocalRentLimit {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        UpdateRentLimitDTO updateRentLimitDTO;
        ObjectId id = new ObjectId();
        SimulationDTO simulationDTO;
        Simulation simulation;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            updateRentLimitDTO = new UpdateRentLimitDTO(
                    id.toString(),
                    List.of(0, 1),
                    List.of(0, 1),
                    500
            );
            simulation = new Simulation(
                    id,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            simulationDTO = new SimulationDTO(simulation);

            given(simulationService.getAuthorEmail(id.toString())).willReturn(validEmail);
            given(simulationService.updateLocalRentLimit(
                    updateRentLimitDTO.simulationId(),
                    updateRentLimitDTO.xCoordinates(),
                    updateRentLimitDTO.yCoordinates(),
                    updateRentLimitDTO.newRentLimit()
            )).willReturn(simulationDTO);
        }

        @DisplayName(" should return response status 401 Unauthorized when a simulation is not modified by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateRentLimit")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateRentLimitDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 201 Created when a simulation is modified by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateRentLimit")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateRentLimitDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isCreated());
        }

        @DisplayName(" should return the correct DTO")
        @Test
        public void testCorrectDTO() throws Exception {
            ResultActions postResult = mockMvc.perform(
                    post("/simulations/updateRentLimit")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(updateRentLimitDTO))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            SimulationDTO responseSimulationDTO = objectMapper.readValue(
                    postResult.andReturn().getResponse().getContentAsString(),
                    SimulationDTO.class
            );
            assertEquals(id.toString(), responseSimulationDTO._id());
            assertEquals("Simulation1", responseSimulationDTO.simulationName());
            assertEquals(validEmail, responseSimulationDTO.authorEmail());
            assertFalse(responseSimulationDTO.isPublic());
            assertEquals("", responseSimulationDTO.simulationPicture());
            assertEquals(10000, responseSimulationDTO.wage());
            assertEquals(2000, responseSimulationDTO.transportationCost());
            assertEquals(500, responseSimulationDTO.constructionCostLimit());
            assertEquals(1000, responseSimulationDTO.rentLimit());
        }

    }

    @DisplayName(" after updating block types")
    @Nested
    class WhenUpdatingBlockTypes {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        UpdateBlockTypeDTO updateBlockTypeDTO;
        ObjectId id = new ObjectId();
        SimulationDTO simulationDTO;
        Simulation simulation;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            updateBlockTypeDTO = new UpdateBlockTypeDTO(
                    id.toString(),
                    List.of(0, 1),
                    List.of(0, 1),
                    BTypes.PARKBLOCK
            );
            simulation = new Simulation(
                    id,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            simulationDTO = new SimulationDTO(simulation);

            given(simulationService.getAuthorEmail(id.toString())).willReturn(validEmail);
            given(simulationService.updateBlockTypes(
                    updateBlockTypeDTO.simulationId(),
                    updateBlockTypeDTO.xCoordinates(),
                    updateBlockTypeDTO.yCoordinates(),
                    updateBlockTypeDTO.newBlockType()
            )).willReturn(simulationDTO);
        }

        @DisplayName(" should return response status 401 Unauthorized when a simulation is not modified by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateBlockTypes")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateBlockTypeDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 201 Created when a simulation is modified by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/updateBlockTypes")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(updateBlockTypeDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isCreated());
        }

        @DisplayName(" should return the correct DTO")
        @Test
        public void testCorrectDTO() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    post("/simulations/updateBlockTypes")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(updateBlockTypeDTO))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            SimulationDTO responseSimulationDTO = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    SimulationDTO.class
            );
            assertEquals(id.toString(), responseSimulationDTO._id());
            assertEquals("Simulation1", responseSimulationDTO.simulationName());
            assertEquals(validEmail, responseSimulationDTO.authorEmail());
            assertFalse(responseSimulationDTO.isPublic());
            assertEquals("", responseSimulationDTO.simulationPicture());
            assertEquals(10000, responseSimulationDTO.wage());
            assertEquals(2000, responseSimulationDTO.transportationCost());
            assertEquals(500, responseSimulationDTO.constructionCostLimit());
            assertEquals(1000, responseSimulationDTO.rentLimit());
        }

    }

    @DisplayName(" after getting block by coordinate")
    @Nested
    class WhenGettingBlockByCoordinate {

        FindBlockDTO findBlockDTO;
        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        ObjectId id = new ObjectId();
        Simulation simulation;
        Block block;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            findBlockDTO = new FindBlockDTO(2, 2, id.toString());
            simulation = new Simulation(
                    id,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            block = new Block(0, 0, BTypes.WATERBLOCK);

            given(simulationService.getSimulationById(id.toString())).willReturn(simulation);
            given(simulationService.blockGetterFromSimulation(findBlockDTO)).willReturn(block);
        }

        @DisplayName(" should return response status 401 Unauthorized when a simulation is not accessed by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/getBlockByCoordinates")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(findBlockDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 200 OK when a simulation is not accessed by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/getBlockByCoordinates")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(findBlockDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return response status 200 OK when accessing public simulation")
        @Test
        public void testPublicAccess() throws Exception {
            simulation.makePublic();
            mockMvc.perform(post("/simulations/getBlockByCoordinates")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(findBlockDTO))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return the correct block")
        @Test
        public void testCorrectBlock() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    post("/simulations/getBlockByCoordinates")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(findBlockDTO))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            Block responseBlock = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    Block.class
            );
            assertEquals(block.getX(), responseBlock.getX());
            assertEquals(block.getY(), responseBlock.getY());
            assertEquals(block.getType(), responseBlock.getType());
        }

    }

    @DisplayName(" after getting old simulations")
    @Nested
    class WhenGettingOldSimulations {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        ObjectId parentId = new ObjectId();
        Simulation simulation;
        int numberOfOldSimulations = 3;
        List<OldSimulation> oldSimulationList = new ArrayList<>();

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            simulation = new Simulation(
                    parentId,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );

            for (int i = 0; i < numberOfOldSimulations; i++) {
                oldSimulationList.add(
                        new OldSimulation(
                                new ObjectId(),
                                parentId,
                                validEmail,
                                false,
                                new City(10000, 2000, 500, 1000),
                                "Simulation1",
                                "",
                                new Date(),
                                new Date()
                        )
                );
            }

            given(simulationService.getSimulationById(parentId.toString())).willReturn(simulation);
            given(oldSimulationService.getUserOldSimulations(parentId.toString())).willReturn(oldSimulationList);

        }

        @DisplayName(" should return response status 401 Unauthorized when simulations are not accessed by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(
                    get("/simulations/getUserOldSimulations/{parentSimulationId}", parentId.toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 200 OK when simulations are accessed by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(
                    get("/simulations/getUserOldSimulations/{parentSimulationId}", parentId.toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return the correct number of simulations")
        @Test
        public void testCorrectNumberOfSimulations() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    get("/simulations/getUserOldSimulations/{parentSimulationId}", parentId.toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            List<OldSimulationDTO> responseList = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    List.class
            );
            assertEquals(numberOfOldSimulations, responseList.size());
        }

        @DisplayName(" should return the simulations belonging to the owner")
        @Test
        public void testCorrectOwner() throws Exception {
            ResultActions getResult = mockMvc.perform(
                    get("/simulations/getUserOldSimulations/{parentSimulationId}", parentId.toString())
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            List<OldSimulationDTO> responseList = objectMapper.readValue(
                    getResult.andReturn().getResponse().getContentAsString(),
                    new TypeReference<List<OldSimulationDTO>>() {
                    }
            );
            for (int i = 0; i < numberOfOldSimulations; i++) {
                assertEquals(validEmail, responseList.get(i).authorEmail());
            }
        }

    }

    @DisplayName(" after getting old block by coordinate")
    @Nested
    class WhenGettingOldBlockByCoordinate {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        ObjectId publicId = new ObjectId();
        ObjectId privateId = new ObjectId();
        OldSimulation privateSimulation;
        OldSimulation publicSimulation;
        FindBlockDTO findBlockDTOPrivate;
        FindBlockDTO findBlockDTOPublic;
        Block block;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            privateSimulation = new OldSimulation(
                    privateId,
                    new ObjectId(),
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            publicSimulation = new OldSimulation(
                    publicId,
                    new ObjectId(),
                    validEmail,
                    true,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );
            findBlockDTOPrivate = new FindBlockDTO(0, 0, privateId.toString());
            findBlockDTOPublic = new FindBlockDTO(0, 0, publicId.toString());
            block = new Block(0, 0, BTypes.RESIDENTIALBLOCK);

            given(oldSimulationService.getSimulationById(findBlockDTOPrivate.simulationId())).
                    willReturn(privateSimulation);
            given(oldSimulationService.getSimulationById(findBlockDTOPublic.simulationId())).
                    willReturn(publicSimulation);
            given(oldSimulationService.oldBlockGetterFromSimulation(findBlockDTOPrivate)).willReturn(block);
            given(oldSimulationService.oldBlockGetterFromSimulation(findBlockDTOPublic)).willReturn(block);
        }

        @DisplayName(" should return response status 401 Unauthorized when a simulation is not accessed by the owner")
        @Test
        public void testUnauthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/getOldBlockByCoordinates")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(findBlockDTOPrivate))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isUnauthorized());
        }

        @DisplayName(" should return response status 200 OK when a simulation is accessed by the owner")
        @Test
        public void testAuthorizedAccess() throws Exception {
            mockMvc.perform(post("/simulations/getOldBlockByCoordinates")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(findBlockDTOPrivate))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return response status 200 OK when accessing public simulation")
        @Test
        public void testPublicAccess() throws Exception {
            mockMvc.perform(post("/simulations/getOldBlockByCoordinates")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(objectMapper.writeValueAsString(findBlockDTOPublic))
                    .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            ).andExpect(status().isOk());
        }

        @DisplayName(" should return the correct block")
        @Test
        public void testCorrectBlock() throws Exception {
            ResultActions postResult = mockMvc.perform(
                    post("/simulations/getOldBlockByCoordinates")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(findBlockDTOPrivate))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
            Block responseBlock = objectMapper.readValue(
                    postResult.andReturn().getResponse().getContentAsString(),
                    Block.class
            );
            assertEquals(0, responseBlock.getX());
            assertEquals(0, responseBlock.getY());
            assertEquals(BTypes.RESIDENTIALBLOCK, responseBlock.getType());
        }

    }

    @DisplayName(" after deleting simulations")
    @Nested
    class WhenDeletingSimulation {

        FakeUser validUser;
        FakeUser invalidUser;
        String validEmail = "alant@usi.ch";
        String invalidEmail = "graceh@usi.ch";
        ObjectId id = new ObjectId();
        SimulationIdDTO simulationIdDTO;
        Simulation simulation;

        @BeforeEach
        void setup() {
            validUser = new FakeUser(validEmail, "ValidUser");
            invalidUser = new FakeUser(invalidEmail, "InvalidUser");
            simulationIdDTO = new SimulationIdDTO(id.toString());
            simulation = new Simulation(
                    id,
                    validEmail,
                    false,
                    new City(10000, 2000, 500, 1000),
                    "Simulation1",
                    "",
                    new Date(),
                    new Date()
            );

            given(simulationService.getSimulationById(simulationIdDTO.id())).willReturn(simulation);
        }

        @DisplayName(" the method should run without exceptions when author tries to delete a simulation")
        @Test
        public void testCorrectRunAuthor() throws Exception {
            mockMvc.perform(
                    post("/simulations/deleteSimulation")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(simulationIdDTO))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(validUser.getToken()))
            );
        }

        @DisplayName(" the method should run without exceptions when non author tries to delete a simulation")
        @Test
        public void testCorrectRunNonAuthor() throws Exception {
            mockMvc.perform(
                    post("/simulations/deleteSimulation")
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectMapper.writeValueAsString(simulationIdDTO))
                            .with(SecurityMockMvcRequestPostProcessors.authentication(invalidUser.getToken()))
            );
        }

    }

}
