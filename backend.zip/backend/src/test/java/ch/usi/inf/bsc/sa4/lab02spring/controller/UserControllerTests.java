package ch.usi.inf.bsc.sa4.lab02spring.controller;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.GetMyUserListDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.SimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UserDTO;
import ch.usi.inf.bsc.sa4.lab02spring.model.FakeUser;
import ch.usi.inf.bsc.sa4.lab02spring.model.User;
import ch.usi.inf.bsc.sa4.lab02spring.service.UserService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("UserController Tests")
class UserControllerTests {

    @MockBean
    private UserService userService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private FakeUser fakeUser;

    private OAuth2AuthenticationToken authenticationToken;

    @BeforeEach
    void setup() {
        fakeUser = new FakeUser("test@example.com", "Test");
        authenticationToken = fakeUser.getToken();
    }

    @DisplayName("after checking authentication status")
    @Nested
    class WhenCheckingAuthenticationStatus {

        @Test
        @DisplayName("should return true when authenticated")
        void testIsAuthenticatedAuthenticated() throws Exception {
            mockMvc.perform(get("/users/isAuthenticated")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk());
        }

        @Test
        @DisplayName("should return false when authentication token is invalid or expired")
        void testIsAuthenticatedInvalidOrExpiredToken() throws Exception {
            mockMvc.perform(get("/users/isAuthenticated")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(null)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$").value(false));
        }

    }


    @Nested
    @DisplayName("When creating a new user")
    class WhenCreatingANewUser {



        @Test
        @DisplayName("should return 200 OK when creating a new user")
        void testCreateUserStatus() throws Exception {
            String fullName = "Test";
            String email = "test@example.com";

            when(userService.getByEmail(email)).thenReturn(Optional.empty());

            when(userService.createUser(fullName, email)).thenReturn(new User(fullName, email, ""));

            mockMvc.perform(get("/users/createUser")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken))
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk());

            verify(userService, times(1)).createUser(fullName, email);
        }

        @Test
        @DisplayName("should not create a new user if already exists")
        void testCreateUserDuplicate() throws Exception {
            String fullName = "Test User";
            String email = "test@example.com";

            when(userService.getByEmail(email)).thenReturn(Optional.of(new User(fullName, email, "")));

            mockMvc.perform(get("/users/createUser")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk());

            verify(userService, times(0)).createUser(any(), any());
        }
    }

    @DisplayName("after getting me")
    @Nested
    class WhenGettingMe {

        @DisplayName("GET /users/getMe - User Found by Email")
        @Test
        void testGetMe_UserFoundByEmail() throws Exception {
            User user = new User("Test User", "test@example.com", "profilePhoto");
            when(userService.getByEmail("test@example.com")).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/getMe")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.name").value(user.getName()))
                    .andExpect(jsonPath("$.email").value(user.getEmail()))
                    .andExpect(jsonPath("$.profilePhoto").value(user.getProfilePhoto()));
        }

        @DisplayName("GET /users/getMe - User Found by Email with Empty Name")
        @Test
        void testGetMe_UserFoundByEmailWithEmptyName() throws Exception {
            User user = new User("", "test@example.com", "profilePhoto");
            when(userService.getByEmail("test@example.com")).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/getMe")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.name").value(""))
                    .andExpect(jsonPath("$.email").value(user.getEmail()));
        }

        @DisplayName("GET /users/getMe - User Found with Profile Photo URL")
        @Test
        void testGetMe_UserFoundWithProfilePhotoURL() throws Exception {
            User user = new User("Test User", "test@example.com", "https://example.com/profile.jpg");
            when(userService.getByEmail("test@example.com")).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/getMe")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.profilePhoto").value(user.getProfilePhoto()));
        }


        @DisplayName("GET /users/getMe - User Not Found by Email")
        @Test
        void testGetMe_UserNotFoundByEmail() throws Exception {
            when(userService.getByEmail("nonexistent@example.com")).thenReturn(Optional.empty());

            mockMvc.perform(get("/users/getMe")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$").doesNotExist());
        }



        @DisplayName("GET /users/getMe - User with Multiple Email Addresses")
        @Test
        void testGetMe_UserWithMultipleEmails() throws Exception {
            String longEmail = "test.testovich@usi.ch";
            String shortEmail = "test@usi.ch";

            FakeUser fakeUser = new FakeUser(longEmail, "");
            OAuth2AuthenticationToken authenticationToken = fakeUser.getToken();

            User user = new User("Test User", longEmail, "profilePhoto");
            when(userService.getByEmail(longEmail)).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/getMe")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.email").value(user.getEmail()));

            verify(userService, never()).getByEmail(shortEmail);
        }

        @DisplayName("GET /users/getMe - Valid OAuth2 Authentication Token")
        @Test
        void testGetMe_ValidOAuth2AuthenticationToken() throws Exception {
            String email = "test@example.com";
            User user = new User("Test User", email, "profilePhoto");
            when(userService.getByEmail(email)).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/getMe")
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.name").value(user.getName()))
                    .andExpect(jsonPath("$.email").value(user.getEmail()));
        }


        @DisplayName("GET /users/getMe - Authentication Token is Null")
        @Test
        void testGetMe_AuthenticationTokenIsNull() throws Exception {
            mockMvc.perform(get("/users/getMe"))
                    .andExpect(status().isFound());
        }

    }


    @DisplayName("after getting user by ID")
    @Nested
    class WhenGettingUserById {


        @DisplayName("GET /users/{userId} - User Found by ID")
        @Test
        void testGetById_UserFoundById() throws Exception {
            String userId = "12345";

            User user = new User("Test User", "test@example.com", "profilePhoto");
            when(userService.getById(userId)).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.name").value(user.getName()))
                    .andExpect(jsonPath("$.email").value(user.getEmail()));
        }


        @DisplayName("GET /users/{userId} - User Not Found by ID")
        @Test
        void testGetById_UserNotFoundById() throws Exception {
            String userId = "nonexistentId";

            when(userService.getById(userId)).thenReturn(Optional.empty());

            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isNotFound());
        }


        @DisplayName("GET /users/{userId} - User ID Invalid Format")
        @Test
        void testGetById_UserIdInvalidFormat() throws Exception {
            String invalidUserId = "invalidUserIdFormat$123";

            mockMvc.perform(get("/users/{userId}", invalidUserId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isNotFound());
        }


        @DisplayName("GET /users/{userId} - User ID Too Long")
        @Test
        void testGetById_UserIdTooLong() throws Exception {
            String userId = "a".repeat(257);
            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isNotFound());
        }


        @DisplayName("GET /users/{userId} - User ID Too Short")
        @Test
        void testGetById_UserIdTooShort() throws Exception {
            String userId = "b";

            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isNotFound());
        }


        @DisplayName("GET /users/{userId} - User Found with Profile Photo")
        @Test
        void testGetById_UserFoundWithProfilePhoto() throws Exception {
            String userId = "12345";
            User user = new User("Test User", "test@example.com", "profilePhoto");
            when(userService.getById(userId)).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.profilePhoto").exists());
        }


        @DisplayName("GET /users/{userId} - User Found with Empty Profile Photo")
        @Test
        void testGetById_UserFoundWithEmptyProfilePhoto() throws Exception {
            String userId = "12345";
            User user = new User("Test User", "test@example.com", "");
            when(userService.getById(userId)).thenReturn(Optional.of(user));

            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.profilePhoto").value(""));
        }


        @DisplayName("GET /users/{userId} - User ID with SQL Injection Attempt")
        @Test
        void testGetById_UserIdWithSqlInjectionAttempt() throws Exception {
            String userId = "12345'; DROP TABLE users; --";

            when(userService.getById(userId)).thenReturn(Optional.empty());

            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isBadRequest());
        }


        @DisplayName("GET /users/{userId} - User ID with URL Encoded Characters")
        @Test
        void testGetById_UserIdWithUrlEncodedCharacters() throws Exception {
            String encodedUserId = "user%20id%23456";

            // Decode the encoded user ID
            String userId = URLDecoder.decode(encodedUserId, StandardCharsets.UTF_8);

            mockMvc.perform(get("/users/{userId}", userId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isNotFound());
        }


        @DisplayName("GET /users/{userId} - User ID with Malformed Data")
        @Test
        void testGetById_UserIdWithMalformedData() throws Exception {
            String malformedUserId = "\u0000\u0001\u0002";

            mockMvc.perform(get("/users/{userId}", malformedUserId)
                            .with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isBadRequest());
        }

    }

    @DisplayName("After getting all users")
    @Nested
    class GetAllUsers {

        @BeforeEach
        void setUp() {

            userService.createUser("John Doe", "john.doe@example.com");

            userService.createUser("Jane Smith", "jane.smith@example.com");

            userService.createUser("Alice Johnson", "alice.johnson@example.com");

        }

        @DisplayName("should return 200 OK when getting all users")
        @Test
        void testGetAllStatus() throws Exception {
            List<User> allUsers = userService.getAll();
            given(userService.getAll()).willReturn(allUsers);
            mockMvc.perform(get("/users"))
                    .andExpect(status().isOk());
        }

        @DisplayName("should return 200 OK when there are no users")
        @Test
        void testGetAllStatusEmptyList() throws Exception {
            given(userService.getAll()).willReturn(Collections.emptyList());
            mockMvc.perform(get("/users"))
                    .andExpect(status().isOk());
        }
    }

    @DisplayName("GET /users/countUsers - Count of users except the authenticated user")
    @Nested
    class UserCountExceptMe {

        @BeforeEach
        void setUp() {

            userService.createUser("John Doe", "john.doe@example.com");

            userService.createUser("Jane Smith", "jane.smith@example.com");

            userService.createUser("Alice Johnson", "alice.johnson@example.com");

        }

        @DisplayName("200 if response is OK")
        @Test
        public void testResponseOK() throws Exception {
            given(userService.countAllUsersExceptMe("john.doe@example.com")).willReturn(2L);
            mockMvc.perform(get("/users/countUsers").
                            with(SecurityMockMvcRequestPostProcessors.authentication(authenticationToken)))
                    .andExpect(status().isOk());
        }
    }

}
