package ch.usi.inf.bsc.sa4.lab02spring.model;

/**
 * Utility class containing methods used for simulation generation
 */
public final class Toolbelt {

    // OPEN CITY MODEL

    /**
     * Constants used in formulas
     */
    private static final double ALPHA = 2000;

    /**
     * Utility, set from the developer and not visible to the user
     */
    private static final double U = 12500;

    /**
     * Constant strictly bigger than 1
     */
    private static final double DELTA = 1.5;

    /**
     * Constant strictly bigger than 0
     */
    private static final int C0 = 20;

    /**
     * Constant strictly bigger than 0
     */
    private static final double R_CAP = 20;

    /**
     * Constant for scaling the density gradient
     */
    private static final int POPULATION_SCALING_FACTOR = 10000;

    /**
     * Constant denoting the number of blocks per unit distance
     */
    private static final int NUMBER_OF_BLOCKS_PER_UNIT_DISTANCE = 4;

    /**
     * Constant denoting the maximum floor number
     */
    public static final int MAX_FLOOR_NUMBER = 100;

    /**
     * Constant denoting the minimum floor number
     */
    public static final int MIN_FLOOR_NUMBER = 3;


    /**
     * Constructor used to block instantiation of the utility class
     */
    public Toolbelt() {
        throw new IllegalStateException("Utility class");
    }



    /**
     * taxicabDistance calculates the Manhattan distance between two points.
     * The taxicab distance is the sum of the absolute differences of the coordinates.
     * @param x1 x-coordinate of the firs point
     * @param y1 y-coordinate of the first point
     * @param x2 x-coordinate of the second point
     * @param y2 y-coordinate of the second point
     * @return the taxicab distance between two points
     * */
    public static int taxicabDistance(int x1, int y1, int x2, int y2) {
        final int dx = Math.abs(x2 - x1);
        final int dy = Math.abs(y2 - y1);
        return dx + dy;
    }

    /**
     * Computes the cost of housing at a given distance distanceFromCBD
     *
     * @param wage the wage earned by each person
     * @param distanceFromCBD distance from the CBD
     * @param transportationCost travel cost per unit of distance
     *
     * @throws IllegalArgumentException if distance is negative
     *
     * @return cost of housing
     */
    public static double costOfHousing(double wage, int distanceFromCBD, double transportationCost) {
        if (wage < 0 || distanceFromCBD < 0 || transportationCost < 0) {
            throw new IllegalArgumentException();
        }

        final double exponent = (wage - U - ALPHA - transportationCost * distanceFromCBD) / ALPHA;
        return ALPHA * Math.exp(exponent);
    }

    /**
     * Computes the cost of land at a given distance distanceFromCBD
     *
     * @param wage the wage earned by each person
     * @param distanceFromCBD distance from the CBD
     * @param transportationCost travel cost per unit of distance
     *
     * @throws IllegalArgumentException if distance is negative
     *
     * @return cost of land
     */
    public static double costOfLand(double wage, int distanceFromCBD, double transportationCost) {

        if (wage < 0 || distanceFromCBD < 0 || transportationCost < 0) {
            throw new IllegalArgumentException();
        }

        final double factor1 = DELTA - 1;
        final double factor2 = Math.pow(DELTA, DELTA / (-1 * factor1));
        final double factor3 = Math.pow(C0, 1 / (-1 * factor1));
        final double factor4 = Math.pow(ALPHA, DELTA / factor1);

        final double exponentNumerator = DELTA * (wage - U - ALPHA - transportationCost * distanceFromCBD);
        final double exponentDenominator = ALPHA * factor1;

        final double expression = Math.exp(exponentNumerator / exponentDenominator);
        return factor1 * factor2 * factor3 * factor4 * expression;
    }

    /**
     * Computes the efficient height of a Block at a given wage, distance distanceFromCBD and
     * cost of transport transportationCost
     *
     * @param distanceFromCBD distance from the CBD
     * @param costOfHousing cost of rent in this block
     *
     * @throws IllegalArgumentException if distance is negative
     *
     * @return cost of land
     */
    public static double heightBlock(
            int distanceFromCBD,
            double costOfHousing
    ) {
      if (costOfHousing < 0 || distanceFromCBD < 0) {
          throw new IllegalArgumentException();
        }

        final double factor1 = DELTA - 1;
        final double factor2 = Math.pow(DELTA, 1 / (-1 * factor1));
        final double factor3 = Math.pow(C0, 1 / (-1 * factor1));

        final double factor4 = Math.pow(costOfHousing, 1 / factor1);

        final double height = (factor2 * factor3 * factor4);

        if (height < MIN_FLOOR_NUMBER) {
            return MIN_FLOOR_NUMBER;
        } else if (height > MAX_FLOOR_NUMBER) {
            return MAX_FLOOR_NUMBER;
        } else {
            return height;
        }

    }

    /**
     * Computes the density gradient at a given distanceFromCBD
     *
     * @param wage the wage earned by each person
     * @param distanceFromCBD distance from the CBD
     * @param transportationCost travel cost per unit of distance
     *
     * @throws IllegalArgumentException if distance is negative
     *
     * @return density gradient
     */
    public static double densityGradient(double wage, int distanceFromCBD, double transportationCost) {

    if (distanceFromCBD < 0 || wage < 0 || transportationCost < 0) {
      throw new IllegalArgumentException();
        }

        final double factor1 = DELTA - 1;
        final double factor2 = Math.pow(DELTA, 1 / (-1 * factor1));
        final double factor3 = Math.pow(C0, 1 / (-1 * factor1));
        final double factor4 = Math.pow(ALPHA, 1 / factor1);

        final double exponentNumerator = DELTA * (wage - U - ALPHA - transportationCost * distanceFromCBD);
        final double exponentDenominator = ALPHA * factor1;

        final double expression = Math.exp(exponentNumerator / exponentDenominator);
        final double result = factor2 * factor3 * factor4 * expression;

        return result * POPULATION_SCALING_FACTOR;
    }

    /**
     * Computes the city edge of a simulation
     *
     * @param wage the wage earned by each person
     * @param transportationCost travel cost per unit of distance
     *
     * @return dCap the city edge
     */
    public static int cityEdge(double wage, double transportationCost) {

        int dCap = 0;
        double r = costOfLand(wage, dCap, transportationCost);
        while (r >= R_CAP) {
            dCap += 1;
            r = costOfLand(wage, dCap, transportationCost);

        }


        return dCap;
    }

    /**
     * Counts the total number of blocks which have exactly distance equal to distanceFromCBD
     *
     * @param distanceFromCBD distance from the CBD
     * @throws IllegalArgumentException if distance is negative
     * @return number of blocks
     */
    public static int numberOfBlocksPerDistance(int distanceFromCBD) {

        if (distanceFromCBD < 0) {
            throw new IllegalArgumentException();
        }

        if (distanceFromCBD == 0) {
            return 1;
        } else {
            return distanceFromCBD * NUMBER_OF_BLOCKS_PER_UNIT_DISTANCE;
        }

    }


    /**
     * Counts the total population in the city
     *
     * @param wage the wage earned by each person
     * @param transportationCost travel cost per unit of distance
     *
     * @return the total population in the city
     */
    public static int totalPopulation(double wage, double transportationCost) {

        final int cityEdge = cityEdge(wage, transportationCost);
        double totalPopulation = 0;

        for (int i = 0; i <= cityEdge; ++i) {
            totalPopulation +=
                    densityGradient(wage, i, transportationCost) *
                            numberOfBlocksPerDistance(i);
        }

        return (int)totalPopulation;

    }

    /**
     * Computes the population for a specific block
     *
     * @param wage the wage earned by each person
     * @param distanceFromCBD distance from the CBD
     * @param transportationCost travel cost per unit of distance
     *
     * @return population in the given block
     */
    public static int populationPerBlock(double wage, int distanceFromCBD, double transportationCost) {
        return (int) (densityGradient(wage, distanceFromCBD, transportationCost));
    }

    /**
     * Computes the construction cost limit for a specific block
     *
     * @param height the block height computed
     * @return construction cost limit in the given block
     */
    public static double constructionCostLimitPerBlock (int height) {

      if (height < MIN_FLOOR_NUMBER || height > MAX_FLOOR_NUMBER) {
          throw new IllegalArgumentException();
        }

        return C0 * Math.pow(height, DELTA);
    }

}
