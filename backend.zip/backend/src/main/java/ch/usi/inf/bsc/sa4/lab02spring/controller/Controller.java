package ch.usi.inf.bsc.sa4.lab02spring.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Controller for redirecting purposes
 */
@RestController
public class Controller {
    /**
     * Method for redirecting
     */
    @GetMapping("/")
    public RedirectView redirectToAnotherUrl() {
        return new RedirectView("http://localhost:3000");
    }
}
