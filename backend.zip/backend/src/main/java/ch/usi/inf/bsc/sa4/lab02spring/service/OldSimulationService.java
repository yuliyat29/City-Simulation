package ch.usi.inf.bsc.sa4.lab02spring.service;

import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.FindBlockDTO;
import ch.usi.inf.bsc.sa4.lab02spring.model.Block;
import ch.usi.inf.bsc.sa4.lab02spring.model.City;
import ch.usi.inf.bsc.sa4.lab02spring.model.OldSimulation;
import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;
import ch.usi.inf.bsc.sa4.lab02spring.repository.OldSimulationRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * A service class to support oldSimulation management.
 */
@Service
public class OldSimulationService {

  /**
   * Constant representing the maximum number of stored simulations
   */
  private static final int NUMBER_OF_MAX_STORED_SIMULATIONS = 6;

  /**
   * Repository interface for accessing and manipulating OldSimulation entities in the database.
   */
  private final OldSimulationRepository oldSimulationRepository;


  /**
   * Constructs an instance of OldSimulationService with the provided OldSimulationRepository dependency.
   *
   * @param oldSimulationRepository The repository used for interacting with OldSimulation entities.
   */
  @Autowired
  public OldSimulationService(OldSimulationRepository oldSimulationRepository) {
    this.oldSimulationRepository = oldSimulationRepository;
  }


  /**
   * Stores the given OldSimulation entity using the OldSimulationRepository.
   *
   * @param simulation The OldSimulation entity to be stored.
   */
  public void storeSimulation(OldSimulation simulation) {
    oldSimulationRepository.save(simulation);
  }


  /**
   * Deletes the given OldSimulation entity using its _id field as the identifier.
   *
   * @param simulation The OldSimulation entity to be deleted.
   */
  public void deleteSimulation(OldSimulation simulation) {
    oldSimulationRepository.deleteBy_id(simulation.get_id());
  }


  /**
   * Deletes the OldSimulations entities using parentId field as the identifier.
   *
   * @param parentId The id of main simulation.
   */
  public void deleteSimulationsByParentId(String parentId) {
    oldSimulationRepository.deleteByParentId(new ObjectId(parentId));
  }


  /**
   * Stores the given Simulation as an OldSimulation entity, creating a new OldSimulation instance
   * with the provided data. If the number of stored OldSimulations for the same parent simulation
   * exceeds the maximum allowed limit, the oldest one will be deleted.
   *
   * @param simulation The Simulation entity to be stored as an OldSimulation.
   */
  public void storeSimulationAsOld(Simulation simulation) {

    final OldSimulation oldSimulation = new OldSimulation(
            new ObjectId(),
            simulation.get_id(),
            simulation.getAuthorEmail(),
            simulation.isPublic(),
            simulation.getCity(),
            simulation.getSimulationName(),
            simulation.getSimulationPicture(),
            simulation.getCreationDate(),
            simulation.getUpdateDate()
    );

    storeSimulation(oldSimulation);

    if (getUserOldSimulations(simulation.get_id().toString()).size() == NUMBER_OF_MAX_STORED_SIMULATIONS){
      deleteOldestOne(getUserOldSimulations(simulation.get_id().toString()));
    }
  }


  /**
   * Retrieves a list of OldSimulations associated with the provided parent simulation ID.
   *
   * @param parentSimulationId The ID of the parent simulation as string.
   * @return A list of OldSimulation entities associated with the parent simulation ID.
   */
  public List<OldSimulation> getUserOldSimulations(String parentSimulationId) {
    return this.oldSimulationRepository.findUserOldSimulations(new ObjectId(parentSimulationId));
  }


  /**
   * Retrieves an OldSimulation associated with the provided simulation ID.
   *
   * @param simulationId The ID of the simulation as string.
   * @return An OldSimulation entity associated with the simulation ID.
   */
  public OldSimulation getSimulationById(String simulationId) {
      return oldSimulationRepository.findById(simulationId).orElseThrow(null);
  }


  /**
   * Deletes the oldest OldSimulation from the provided list of OldSimulations.
   *
   * @param oldSimulations The list of OldSimulations from which the oldest one will be deleted.
   */
  public void deleteOldestOne(List<OldSimulation> oldSimulations) {
    final int indexToDelete = getIndexOfOldestSimulation(oldSimulations);

    final OldSimulation oldSimulationToDelete = oldSimulations.get(indexToDelete);
    deleteSimulation(oldSimulationToDelete);
  }


  /**
   * Returns the index of the oldest OldSimulation in the provided list based on the update date.
   *
   * @param oldSimulations The list of OldSimulations.
   * @return The index of the oldest OldSimulation.
   */
  private static int getIndexOfOldestSimulation(List<OldSimulation> oldSimulations) {
    Date oldestUpdateDate = null;
    int indexOfOldestSimulation = 0;

    for (int i = 0; i < oldSimulations.size(); i++) {
      final OldSimulation oldSimulation = oldSimulations.get(i);
      final Date updateDate = oldSimulation.getUpdateDate();

      if (oldestUpdateDate == null || updateDate.before(oldestUpdateDate)) {
        oldestUpdateDate = updateDate;
        indexOfOldestSimulation = i;
      }
    }
    return indexOfOldestSimulation;
  }

  /**
   * Returns a block from the old simulation that matches FindBlockDTO
   *
   * @param dto An input DTO used to find a block
   * @return block from the old simulation that matches FindBlockDTO
   */
  public Block oldBlockGetterFromSimulation(FindBlockDTO dto){
    final Optional<OldSimulation> simulation = oldSimulationRepository.findById(dto.simulationId());
    if (simulation.isPresent()) {
      final City city = simulation.get().getCity();
      return City.findBlockByCoordinate(city, dto.x(), dto.y());
    }
    return null;
  }

}
