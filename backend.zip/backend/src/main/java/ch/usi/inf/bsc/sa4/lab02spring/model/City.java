package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.springframework.data.annotation.PersistenceCreator;

import java.util.List;
import java.util.SortedMap;
import java.util.Objects;
import java.util.TreeMap;

/**
 * Represents a city consisting. It is defined by the population wage, transportation costs,
 * construction costs limit, and certain constants not visible to the user.
 */
public class City {

  public static final int MAX_CITY_RADIUS = 30;

  /**
   * Total population size
   */
  private int populationSize;

  /**
   * The population wage
   */
  private double wage;

  /**
   * Global transportation costs
   */
  private double transportationCost;

  /**
   * Global construction costs limit
   */
  private double constructionCostLimit;

  /**
   * Global rent limit
   */
  private double rentLimit;

  /**
   * Blocks than constitute a city
   */
  private SortedMap<Integer, Block> blocks;

  /**
   * Persistence constructor used by MongoDB
   *
   * @param blocks the blocks of the city
   * @param populationSize the population size of the city
   * @param wage the population wage
   * @param transportationCost the transportation costs
   * @param constructionCostLimit the global limit for construction costs
   */
  @PersistenceCreator
  public City(SortedMap<Integer, Block> blocks,
              int populationSize,
              double wage,
              double transportationCost,
              double constructionCostLimit,
              double rentLimit
  ) {
    this.blocks = blocks;
    this.populationSize = populationSize;
    this.wage = wage;
    this.transportationCost = transportationCost;
    this.constructionCostLimit = constructionCostLimit;
    this.rentLimit = rentLimit;
    }

  /**
   *
   * Constructs a city with specified parameters
   *
   * @param wage the population wage
   * @param transportationCost the transportation costs
   * @param constructionCostLimit global limit for construction costs
   * @param rentLimit the limit for rent
   */
  public City(double wage, double transportationCost, double constructionCostLimit, double rentLimit) {
    this.wage = wage;
    this.transportationCost = transportationCost;
    this.constructionCostLimit = constructionCostLimit;
    this.rentLimit = rentLimit;
    this.populationSize = Toolbelt.totalPopulation(wage, transportationCost);
    this.blocks = generateCityBlocks(wage, transportationCost, constructionCostLimit, rentLimit);
  }

  /**
   * An empty constructor to fix 'Cannot deserialize from object value (no delegate- or property-based creator)'
   * error in SimulationControllerTests which occurs because Jackson Library doesn't know how to create a model which
   * doesn't have an empty constructor and the model contains a constructor with parameters that didn't annotate
   * its parameters with @JsonProperty("field_name").
   */
  public City() {}

  /**
   * Generates the city blocks based on the wages and costs of transportation
   * @param wage the population wage
   * @param transportationCost the transportation costs
   * @param constructionCostLimit global limit for construction costs
   * @return the city blocks
   */
  public final SortedMap<Integer, Block> generateCityBlocks(
          double wage,
          double transportationCost,
          double constructionCostLimit,
          double rentLimit
  ) {
    int cityRadius = Toolbelt.cityEdge(wage,transportationCost);
    SortedMap<Integer, Block> cityBlocks = new TreeMap<>();
    for (int i = -cityRadius; i <= cityRadius; i++) {
      for (int j = -cityRadius; j <= cityRadius; j++) {
        if (Toolbelt.taxicabDistance(i,j,0,0) > cityRadius) {
          Block block = new WaterBlock(i, j, BTypes.WATERBLOCK);
          cityBlocks.put(Objects.hash(i, j), block);
        } else {
          Block block = generateResidentialBlock(
            i,
            j,
            wage,
            transportationCost,
            constructionCostLimit,
            rentLimit
          );
          cityBlocks.put(Objects.hash(i, j), block);
        }
      }
    }
    return cityBlocks;
  }

  /**
   *
   * Generates a residential block
   *
   * @param x the x coordinate of the block
   * @param y the y coordinate of the block
   * @param wage the population wage
   * @param transportationCost the transportation costs
   * @param constructionCostLimit global limit for construction costs
   *
   * @return residential block
   */
  public ResidentialBlock generateResidentialBlock(
    int x,
    int y,
    double wage,
    double transportationCost,
    double constructionCostLimit,
    double rentLimit
  ) {
    int taxiCabForThisBlock = Toolbelt.taxicabDistance(x, y,0,0);
    double costOfHousing = Toolbelt.costOfHousing(wage, taxiCabForThisBlock, transportationCost);
    double costOfLand = Toolbelt.costOfLand(wage, taxiCabForThisBlock, transportationCost);
    int height = (int) Toolbelt.heightBlock(taxiCabForThisBlock, costOfHousing);
    int initialNumberOfPeopleInBlock;
    if (
            this.blocks == null ||
            findBlockByCoordinate(this, x, y).getType() == BTypes.WATERBLOCK ||
            findBlockByCoordinate(this, x, y).getType() == BTypes.PARKBLOCK
    ) {
      initialNumberOfPeopleInBlock = Toolbelt.populationPerBlock(
        wage,
        taxiCabForThisBlock,
        transportationCost
      );
    } else {
      initialNumberOfPeopleInBlock = ((ResidentialBlock) findBlockByCoordinate(this, x, y))
        .getNumberOfPeople();
    }
    int numberOfPeopleInBlock = Toolbelt.populationPerBlock(
                wage,
                taxiCabForThisBlock,
                transportationCost
    );

    if (Toolbelt.constructionCostLimitPerBlock(height) > constructionCostLimit) {
      int numberOfPeoplePerFloor = numberOfPeopleInBlock / height;
      for (int z = height; Toolbelt.constructionCostLimitPerBlock(z) > constructionCostLimit; z--) {
        height = z;
        numberOfPeopleInBlock -= numberOfPeoplePerFloor;
      }
    }

    if (height < Toolbelt.MIN_FLOOR_NUMBER) {
      height = Toolbelt.MIN_FLOOR_NUMBER;
    }
    this.populationSize += numberOfPeopleInBlock - initialNumberOfPeopleInBlock;

    if (costOfHousing > rentLimit) {
      int heightRentLimit = (int) Toolbelt.heightBlock(taxiCabForThisBlock, rentLimit);
      if (heightRentLimit < height) {
        int numberOfPeoplePerFloor = numberOfPeopleInBlock / height;
        int populationDifference = (heightRentLimit - height) * numberOfPeoplePerFloor;
        this.populationSize += populationDifference;
        numberOfPeopleInBlock += populationDifference;
        height = heightRentLimit;
      }
      costOfHousing = rentLimit;
    }

    return new ResidentialBlock(
                x,
                y,
                height,
                BTypes.RESIDENTIALBLOCK,
                transportationCost,
                numberOfPeopleInBlock,
                costOfHousing,
                costOfLand,
                rentLimit,
                constructionCostLimit,
                Toolbelt.constructionCostLimitPerBlock(height)
    );

  }

  /**
   * Returns the blocks of the city
   * @return the blocks
   */
  public SortedMap<Integer, Block> getBlocks() {
    return this.blocks;
  }

  /**
   * Finds a block based on the coordinates gives
   * @param city the city in which you want to find the blocks
   * @param cursorX the x coordinate
   * @param cursorY the y coordinate
   * @return the blocks
   */
  public static Block findBlockByCoordinate(City city, int cursorX, int cursorY) {
    Integer key = Objects.hash(cursorX, cursorY);
    SortedMap<Integer, Block> cityBlocks = city.getBlocks();
    return cityBlocks.get(key);
  }


  /**
   *  Updates a block and returns the updated population size
   * @param x the x coordinate
   * @param y the y coordinate
   * @param transportationCost the transportation cost of the block
   * @return the updated population size
   */
  public int updateBlock(int x, int y, double transportationCost) {
    ResidentialBlock block = (ResidentialBlock) findBlockByCoordinate(this, x, y);
    double costOfHousing = Toolbelt.costOfHousing(wage, block.distanceFromCenter, transportationCost);
    int height = (int) Toolbelt.heightBlock(block.distanceFromCenter, costOfHousing);
    int numberOfPeopleInBlock = Toolbelt.populationPerBlock(
            wage,
            block.distanceFromCenter,
            transportationCost
    );
    int newPopulation = numberOfPeopleInBlock - block.getNumberOfPeople();
    double costOfRentInBlock = Toolbelt.costOfHousing(wage, block.distanceFromCenter, transportationCost);
    block.setHeight(height);
    block.setTransportationCost(transportationCost);
    block.setNumberOfPeople(numberOfPeopleInBlock);
    block.setCostOfRent(costOfRentInBlock);
    return newPopulation;
  }

  /**
   * Updates a list of blocks  and updates the population size
   * @param xCoordinates the x coordinates of the blocks
   * @param yCoordinates the y coordinates of the blocks
   * @param transportationCost the costs of transportation of the blocks
   *
   * @throws IllegalArgumentException if the x and y coordinates do not have the same size
   *
   */
  public void updateBlocks(List<Integer> xCoordinates, List<Integer> yCoordinates, double transportationCost) {
    if (xCoordinates.size() != yCoordinates.size()) {
      throw new IllegalArgumentException("Lists of x and y should have the same size.");
    }

    int newPopulation = 0;

    for (int i = 0; i < xCoordinates.size(); i++) {
      int x = xCoordinates.get(i);
      int y = yCoordinates.get(i);
      newPopulation += updateBlock(x, y, transportationCost);
    }
    this.populationSize += newPopulation;
  }

  /**
   * Updates construction costs limit fot the given blocks
   *
   * @param xCoordinates a list containing x coordinates of blocks to be updated
   * @param yCoordinates a list containing y coordinates of blocks to be updated
   * @param constructionCostLimit a new construction costs limit for the given blocks
   */
  public void updateLocalConstructionLimit(
          List<Integer> xCoordinates,
          List<Integer> yCoordinates,
          double constructionCostLimit
  ) {
    for (int i = 0; i < xCoordinates.size(); i++) {
      ResidentialBlock block = (ResidentialBlock) findBlockByCoordinate(
              this,
              xCoordinates.get(i),
              yCoordinates.get(i)
      );
      int x = xCoordinates.get(i);
      int y = yCoordinates.get(i);
      this.blocks.put(Objects.hash(x, y), generateResidentialBlock(
              x,
              y,
              this.wage,
              block.getTransportationCost(),
              constructionCostLimit,
              block.getRentLimit()
      ));
    }
  }

  /**
   * Updates the blocks specified by the lists of x and y coordinates according to the new rent limit.
   * This may affect height and population for a specific block.
   *
   * @param xCoordinates the x coordinates of the blocks
   * @param yCoordinates the y coordinates of the blocks
   * @param rentLimit new rent limit
   *
   * @throws IllegalArgumentException if the lists of x and y coordinates have different sizes
   */
  public void updateLocalRentLimits(
          List<Integer> xCoordinates,
          List<Integer> yCoordinates,
          double rentLimit
  ) {
    if (xCoordinates.size() != yCoordinates.size()) {
      throw new IllegalArgumentException("Lists of x and y coordinates must have the same size.");
    }

    for (int i = 0; i < xCoordinates.size(); i++) {
      ResidentialBlock block = (ResidentialBlock) findBlockByCoordinate(
              this,
              xCoordinates.get(i),
              yCoordinates.get(i)
      );
      int x = xCoordinates.get(i);
      int y = yCoordinates.get(i);
      this.blocks.put(Objects.hash(x, y), generateResidentialBlock(
              x,
              y,
              this.wage,
              block.getTransportationCost(),
              block.getConstructionCostLimit(),
              rentLimit
      ));
    }
  }

  /**
   * Updates the type of block of a given block and the cost of rent for all possible adjacent residential blocks
   * @param x the x coordinate
   * @param y the y coordinate
   * @param newBlockType the new type of the block
   */
  public void changeBlockType(int x, int y, BTypes newBlockType) {

    Block currentBlock = findBlockByCoordinate(this, x, y);
    Block newBlock;
    switch (newBlockType) {

      case WATERBLOCK:
        if (currentBlock instanceof ResidentialBlock) {
          this.populationSize -= ((ResidentialBlock) currentBlock).getNumberOfPeople();
        }
        newBlock = new WaterBlock(x, y, BTypes.WATERBLOCK);
        break;

      case PARKBLOCK:
        if (currentBlock instanceof ResidentialBlock) {
          this.populationSize -= ((ResidentialBlock) currentBlock).getNumberOfPeople();
        }
        newBlock = new ParkBlock(x, y, BTypes.PARKBLOCK);
        break;

      case RESIDENTIALBLOCK:
        int distanceFromCenter = Toolbelt.taxicabDistance(x, y, 0, 0);
        int populationBlock = Toolbelt.populationPerBlock(wage, distanceFromCenter, transportationCost);
        this.populationSize += populationBlock;
        newBlock = generateResidentialBlock(
                x,
                y,
                wage,
                transportationCost,
                constructionCostLimit,
                rentLimit
        );
      break;
        default:
          throw new IllegalArgumentException("Invalid block type specified.");
    }

    blocks.put(Objects.hash(x, y), newBlock);
    }

    /**
     * Updates types of block for the given blocks
     * @param xCoordinates the x coordinates of the blocks
     * @param yCoordinates the y coordinates of the blocks
     * @param newBlockType the new type of the block
     */
    public void changeBlockTypes(List<Integer> xCoordinates, List<Integer> yCoordinates, BTypes newBlockType) {
        if (xCoordinates.size() != yCoordinates.size()) {
            throw new IllegalArgumentException("The number of x and y coordinates should be the same");
        }

        for (int i = 0; i < xCoordinates.size(); i++) {
            int x = xCoordinates.get(i);
            int y = yCoordinates.get(i);
            if(x != 0 || y != 0) {
                this.changeBlockType(x, y, newBlockType);
            }
        }
    }

    /**
     * Gets the population size
     * @return the population size
     */
    public int getPopulationSize(){
        return populationSize;
    }

  /**
   * gets the wage value
   * @return the wage
   */
  public double getWage(){
    return wage;
  }

  /**
   * Gets the transportation costs
   * @return the transportation cost
   */
  public double getTransportationCost(){
    return transportationCost;
  }

  /**
   * Gets the construction cost limit
   * @return the construction cost limit
   */
  public double getConstructionCostLimit() {
    return constructionCostLimit;
  }

  public double getRentLimit() { return rentLimit; }

  /**
   * Sets the wage
   * @param wage the wage that needs to be set
   */
  public void setWage(double wage) {
    this.wage = wage;
  }

  /**
   * Sets the construction cost limit
   * @param constructionCostLimit the construction cost limit that needs to be set
   */
  public void setConstructionCostLimit(double constructionCostLimit) {
    this.constructionCostLimit = constructionCostLimit;
  }

  /**
   * Sets the transportation costs
   * @param transportationCost the transportation costs to set
   */
  public void setTransportationCost(double transportationCost) {
    this.transportationCost = transportationCost;
  }
}
