package ch.usi.inf.bsc.sa4.lab02spring.model;

import java.util.Objects;

/**
 * Provides a simple model for a key used in simulations.
 */
public class SimulationKey implements Comparable<SimulationKey> {

  /**
   * Declares a protected integer variable to store the x-coordinate of the simulation key.
   */
  protected int x;

  /**
   * Declares a protected integer variable to store the y-coordinate of the simulation key.
   */
  protected int y;

  /**
   * The constructor initializes the instance variables x and y.
   *
   * @param x the x-coordinate of the simulation key.
   * @param y the y-coordinate of the simulation key.
   */
  public SimulationKey(int x, int y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Gets the x-coordinate of the simulation key.
   *
   * @return the x-coordinate.
   */
  public int getX() {
    return this.x;
  }

  /**
   * Gets the y-coordinate of the simulation key.
   *
   * @return the y-coordinate.
   */
  public int getY() {
    return this.y;
  }

  /**
   * Sets the x-coordinate of the simulation key.
   *
   * @param x the new x-coordinate.
   */
  public void setX(int x) {
    this.x = x;
  }

  /**
   * Sets the y-coordinate of the simulation key.
   *
   * @param y the new y-coordinate.
   */
  public void setY(int y) {
    this.y = y;
  }

  /**
   * Compares this SimulationKey to another SimulationKey based on their hash codes.
   *
   * @param other the other SimulationKey to be compared.
   * @return a negative integer, zero, or a positive integer as this object's hash code
   *         is less than, equal to, or greater than the specified object's hash code.
   */
  @Override
  public int compareTo(SimulationKey other) {
    return Integer.compare(other.hashCode(), this.hashCode());
  }

  /**
   * Indicates whether some other object is "equal to" this one.
   *
   * @param o the reference object with which to compare.
   * @return {@code true} if this object is the same as the obj argument; {@code false} otherwise.
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final SimulationKey that = (SimulationKey) o;
    return x == that.x && y == that.y;
  }

  /**
   * Returns a hash code value for the object.
   *
   * @return a hash code value for this object.
   */
  @Override
  public int hashCode() {
    return Objects.hash(x, y);
  }
}
