package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.PersistenceCreator;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;


/**
 * Represents an old simulation in the system, extending the base Simulation class.
 * This class is mapped to the "OldSimulations" collection in the MongoDB database.
 */
@Document(collection = "OldSimulations")
public class OldSimulation extends Simulation {

  /**
   * The ID of the parent simulation to which this old simulation belongs.
   */
  private final ObjectId parentId;


  /**
   * Persistence constructor used by MongoDB
   *
   * @param _id the id of the old simulation
   * @param parentId the id of the parent simulation
   * @param authorEmail the email of the author
   * @param isPublic boolean specifying if the simulation is public
   * @param city the city of the simulation
   * @param simulationPicture the URL to the simulation picture
   * @param creationDate date when the simulation was created
   * @param updateDate date when the simulation was last updated
   */
  @PersistenceCreator
  public OldSimulation(
          ObjectId _id,
          ObjectId parentId,
          String authorEmail,
          boolean isPublic,
          City city,
          String simulationName,
          String simulationPicture,
          Date creationDate,
          Date updateDate
  ) {
    super(_id, authorEmail, isPublic, city, simulationName, simulationPicture, creationDate, updateDate);
    this.parentId = parentId;
  }


  /**
   * Constructs a new OldSimulation object.
   *
   * @param _id                 The unique identifier of the old simulation.
   * @param parentId            The ID of the parent simulation to which this old simulation belongs.
   * @param wage                The wage associated with the old simulation.
   * @param transportationCost The transportation cost associated with the old simulation.
   * @param simulationName      The name of the old simulation.
   * @param authorEmail         The email of the author of the old simulation.
   * @param isPublic            A boolean indicating whether the old simulation is public.
   * @param simulationPicture   The picture associated with the old simulation.
   * @param lastUpdateDate      The date when this old simulation was last updated.
   */
  public OldSimulation(
    ObjectId _id,
    ObjectId parentId,
    double wage,
    double transportationCost,
    double constructionCostLimit,
    double rentLimit,
    String simulationName,
    String authorEmail,
    boolean isPublic,
    String simulationPicture,
    Date lastUpdateDate
  ) {
    super(
            wage,
            transportationCost,
            constructionCostLimit,
            rentLimit,
            simulationName,
            authorEmail,
            isPublic,
            simulationPicture,
            null,
            lastUpdateDate
    );
    this.parentId = parentId;
  }


  /**
   * Returns the parent id of old simulation
   *
   * @return parentId of old simulation
   */
  public ObjectId getParentId() {
      return parentId;
  }

}
