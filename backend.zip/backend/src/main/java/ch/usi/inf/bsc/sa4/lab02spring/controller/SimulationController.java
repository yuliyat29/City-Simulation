package ch.usi.inf.bsc.sa4.lab02spring.controller;

import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UpdateRentLimitDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.SimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.OldSimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UpdateSimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.CreateSimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UpdateTransportationCostDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.FindBlockDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.SimulationLinkDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.SimulationIdDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.GetMySimulationsDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UpdateConstructionCostDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UpdateBlockTypeDTO;

import ch.usi.inf.bsc.sa4.lab02spring.model.City;
import ch.usi.inf.bsc.sa4.lab02spring.model.Toolbelt;
import ch.usi.inf.bsc.sa4.lab02spring.model.User;
import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;
import ch.usi.inf.bsc.sa4.lab02spring.model.OldSimulation;
import ch.usi.inf.bsc.sa4.lab02spring.model.Block;
import ch.usi.inf.bsc.sa4.lab02spring.service.OldSimulationService;
import ch.usi.inf.bsc.sa4.lab02spring.service.SimulationService;

import ch.usi.inf.bsc.sa4.lab02spring.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/simulations")
public class SimulationController {
  private static final String EMAIL = "email";

  private final OldSimulationService oldSimulationService;
  private final SimulationService simulationService;
  private final UserService userService;



  @Autowired
  public SimulationController(
          SimulationService simulationService,
          OldSimulationService oldSimulationService,
          UserService userService) {
    this.simulationService = simulationService;
    this.oldSimulationService = oldSimulationService;
    this.userService = userService;
  }


  /**
   * Creates a new simulation and adds it to the database. Also, if the user entity is not created yet, creates an
   * user entity and adds it to database.
   * This endpoint allows users to create a new simulation by providing the user information and simulation name.
   *
   * @param dto The simulation dto with its fields.
   * @param token the OAuth2AuthenticationToken of a user
   * @return A ResponseEntity containing the HTTP status and the created simulation object in the body if successful.
   */
  @PostMapping(path = "/addSimulation")
  public ResponseEntity<SimulationDTO> addSimulation(
          @RequestBody CreateSimulationDTO dto,
          OAuth2AuthenticationToken token
  ) {
    String userEmail = token.getPrincipal().getAttribute(EMAIL);

    Optional<User> userExist = userService.getByEmail(userEmail);
    if (userExist.isEmpty()) {
      String fullName = token.getPrincipal().getAttribute("name");
      userService.createUser(fullName, userEmail);
    }

    if (userEmail != null) {
      if (Toolbelt.cityEdge(dto.wage(), dto.transportationCost()) > City.MAX_CITY_RADIUS) {
        throw new IllegalArgumentException("City edge exceeds the maximum size.");
      }
      SimulationDTO response = simulationService.createSimulation(dto, userEmail);
      return ResponseEntity.status(HttpStatus.CREATED).body(response);
    } else {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
    }
  }

  /**
   * Retrieves a simulation by its ID.
   * This endpoint allows users to retrieve a simulation by providing its unique identifier.
   *
   * @param simulationId The unique identifier of the simulation.
   * @return A {@code ResponseEntity} containing the simulation if found,
   * or a 404 Not Found status if the simulation does not exist.
   */
  @GetMapping(path = "/{simulationId}")
  public ResponseEntity<SimulationDTO> getSimulation(
          @PathVariable String simulationId,
          OAuth2AuthenticationToken token
  ) {
    String userEmail = token.getPrincipal().getAttribute(EMAIL);
    Simulation simulation = simulationService.getSimulationById(simulationId);
    if (!simulation.getAuthorEmail().equals(userEmail)) {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
    }
    return ResponseEntity.ok(new SimulationDTO(simulation));
  }


  /**
   * Retrieves an oldSimulation by its ID.
   * This endpoint allows users to retrieve an OldSimulation by providing its unique identifier.
   *
   * @param oldSimulationId The unique identifier of the oldSimulation.
   * @return A {@code ResponseEntity} containing the oldSimulation if found,
   * or a 404 Not Found status if the simulation does not exist.
   */
  @GetMapping (path = "getOldSimulation/{oldSimulationId}")
  public ResponseEntity<OldSimulationDTO> getOldSimulation(
          @PathVariable String oldSimulationId,
          OAuth2AuthenticationToken token
  ) {
    String userEmail = token.getPrincipal().getAttribute(EMAIL);
    OldSimulation oldsimulation = oldSimulationService.getSimulationById(oldSimulationId);
    if (!oldsimulation.getAuthorEmail().equals(userEmail)) {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
    }
    return ResponseEntity.ok(new OldSimulationDTO(oldsimulation));
  }



  /**
   * Returns the list of existing simulations.
   *
   * @return A ResponseEntity contains the HTTP status,the list with all simulations as DTOs in the body if successful.
   */
  @GetMapping
  public ResponseEntity<List<SimulationDTO>> getAll() {
    List<SimulationDTO> listSimulationsDTO = simulationService.getAll()
            .stream()
            .map(SimulationDTO::new)
            .toList();
    return ResponseEntity.ok(listSimulationsDTO);
  }


  @GetMapping("/countSimulations")
  public ResponseEntity<Long> countSimulationsForCurrentUser(OAuth2AuthenticationToken token) {
    String email = token.getPrincipal().getAttribute(EMAIL);
    long simulationCount = simulationService.countSimulationByEmail(email);
    return ResponseEntity.ok().body(simulationCount);
  }

  @PostMapping("/countUserSimulations")
  public ResponseEntity<Long> countSimulationsUserList(@RequestBody String email) {
    long simulationCount = simulationService.countSimulationByEmail(email);
    return ResponseEntity.ok().body(simulationCount);

  }


  /**
   * Updates the simulation.
   * This endpoint allows the author of the simulation to update the simulation.
   *
   * @param dto    The UpdateSimulationDTO containing
   *               the simulation ID, the wage, the new transportation cost,
   *               the new construction cost limit and the new simulation name.
   * @param token  The OAuth2AuthenticationToken of the user.
   * @return A ResponseEntity containing the updated simulation object if successful,
   *         or a 401 Unauthorized status if the user is not authorized to update the simulation.
   */
  @PostMapping(path = "/updateSimulation")
  public ResponseEntity<SimulationDTO> updateSimulation(
          @RequestBody UpdateSimulationDTO dto,
          OAuth2AuthenticationToken token
  ) {
    if(simulationService.getAuthorEmail(dto._id()).equals(token.getPrincipal().getAttribute(EMAIL))){
      if (Toolbelt.cityEdge(dto.wage(), dto.transportationCost()) > City.MAX_CITY_RADIUS) {
        throw new IllegalArgumentException("City edge exceeds the maximum size.");
      }
      SimulationDTO response = simulationService.updateSimulation(dto);
      return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
  }

  /**
   * Updates transportation cost for blocks in a simulation.
   * This endpoint allows the author of the simulation to update transportation costs for specific blocks.
   *
   * @param dto    The UpdateTransportationCostDTO containing
   *               the simulation ID, coordinates, and new transportation cost.
   * @param token  The OAuth2AuthenticationToken of the user.
   * @return A ResponseEntity containing the updated simulation object if successful,
   *         or a 401 Unauthorized status if the user is not authorized to update the simulation.
   */
  @PostMapping("/updateTransportationCost")
  public ResponseEntity<SimulationDTO> updateTransportationCostForBlocks(
          @RequestBody UpdateTransportationCostDTO dto,
          OAuth2AuthenticationToken token
  ) {
    if (simulationService.getAuthorEmail(dto.simulationId()).equals(
            token.getPrincipal().getAttribute(EMAIL))
    ) {
      SimulationDTO response = simulationService.updateTransportationCost(
              dto.simulationId(),
              dto.xCoordinates(),
              dto.yCoordinates(),
              dto.newTransportationCost()
      );
      return ResponseEntity.status(HttpStatus.CREATED).body(response);
    } else {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
  }

  /**
   * Updates construction cost limit for blocks in a simulation.
   * This endpoint allows the author of the simulation to update construction costs limit for specific blocks.
   *
   * @param dto    The UpdateConstructionCostDTO containing
   *               the simulation ID, coordinates, and new construction cost limit.
   * @param token  The OAuth2AuthenticationToken of the user.
   * @return A ResponseEntity containing the updated simulation object if successful,
   *         or a 401 Unauthorized status if the user is not authorized to update the simulation.
   */
  @PostMapping("/updateConstructionCost")
  public ResponseEntity<SimulationDTO> updateLocalConstructionCostLimit(
          @RequestBody UpdateConstructionCostDTO dto,
          OAuth2AuthenticationToken token
  ) {
    if (simulationService.getAuthorEmail(dto.simulationId()).equals(
            token.getPrincipal().getAttribute(EMAIL))
    ) {
      SimulationDTO response = simulationService.updateLocalConstructionCostLimit(
              dto.simulationId(),
              dto.xCoordinates(),
              dto.yCoordinates(),
              dto.newConstructionCostLimit()
      );
      return ResponseEntity.status(HttpStatus.CREATED).body(response);
    } else {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
  }

    /**
     * Updates rent limit for blocks in a simulation.
     * This endpoint allows the author of the simulation to update rent limit for specific blocks.
     *
     * @param dto    The UpdateRentLimitDTO containing
     *               the simulation ID, coordinates, and new rent limit.
     * @param token  The OAuth2AuthenticationToken of the user.
     * @return A ResponseEntity containing the updated simulation object if successful,
     *         or a 401 Unauthorized status if the user is not authorized to update the simulation.
     */
  @PostMapping("/updateRentLimit")
  public ResponseEntity<SimulationDTO> updateLocalRentLimit(
          @RequestBody UpdateRentLimitDTO dto,
          OAuth2AuthenticationToken token
  ) {
    if (simulationService.getAuthorEmail(dto.simulationId()).equals(
            token.getPrincipal().getAttribute(EMAIL))
    ) {
      SimulationDTO response = simulationService.updateLocalRentLimit(
              dto.simulationId(),
              dto.xCoordinates(),
              dto.yCoordinates(),
              dto.newRentLimit()
      );
      return ResponseEntity.status(HttpStatus.CREATED).body(response);
    } else {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
  }

  /**
   * Updates block type for blocks in a simulation.
   * This endpoint allows the author of the simulation to update block types for specific blocks.
   *
   * @param dto    The UpdateBlockTypeDTO containing
   *               the simulation ID, coordinates, and new block type.
   * @param token  The OAuth2AuthenticationToken of the user.
   * @return A ResponseEntity containing the updated simulation object if successful,
   *         or a 401 Unauthorized status if the user is not authorized to update the simulation.
   */
  @PostMapping("/updateBlockTypes")
  public ResponseEntity<SimulationDTO> updateBlockTypesForBlocks(
          @RequestBody UpdateBlockTypeDTO dto,
          OAuth2AuthenticationToken token
  ) {
    if (simulationService.getAuthorEmail(dto.simulationId()).equals(
            token.getPrincipal().getAttribute(EMAIL))
    ) {
      SimulationDTO response = simulationService.updateBlockTypes(
              dto.simulationId(),
              dto.xCoordinates(),
              dto.yCoordinates(),
              dto.newBlockType()
      );
      return ResponseEntity.status(HttpStatus.CREATED).body(response);
    } else {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
  }

  /**
   * Gets coordinates for blocks in a simulation.
   * This endpoint allows the author of the simulation to get x and y coordinates for specific blocks.
   *
   * @param dto    The FindBLockDTO containing x coordinate, y coordinate, and simulation id.
   * @param token  The OAuth2AuthenticationToken of the user.
   * @return A ResponseEntity containing the block object if successful,
   *         or a 401 Unauthorized status if the user is not authorized to get block coordinates.
   */
  @PostMapping (path = "/getBlockByCoordinates")
  public ResponseEntity<Block> getSimulation(@RequestBody FindBlockDTO dto, OAuth2AuthenticationToken token) {
    Simulation simulation = simulationService.getSimulationById(dto.simulationId());
    if (
            simulation.isPublic() ||
            simulation.getAuthorEmail().equals(token.getPrincipal().getAttribute(EMAIL))
    ) {
      Block block = simulationService.blockGetterFromSimulation(dto);
      return ResponseEntity.ok(block);
    }
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
  }


  /**
   * Makes the simulation with the given id public.
   *
   * @param simulationIdDTO the patch request for making simulation public.
   * @return if the making simulation public has been successful,a 200 OK with the link to the simulation.
   * If the simulation does not exist, it returns a bad request.
   * @spec.modifies the persisted simulation.
   */
  @PostMapping("/makePublic")
  public ResponseEntity<SimulationLinkDTO> makePublic(
          @RequestBody SimulationIdDTO simulationIdDTO,
          OAuth2AuthenticationToken token
  ) {
    if (simulationService.getAuthorEmail(simulationIdDTO.id()).equals(
            token.getPrincipal().getAttribute(EMAIL)
    )) {
      SimulationLinkDTO response = simulationService.makePublic(simulationIdDTO.id());
      return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
  }

  @PostMapping("/makePrivate")
  public ResponseEntity<SimulationLinkDTO> makePrivate(
          @RequestBody SimulationIdDTO simulationIdDTO,
          OAuth2AuthenticationToken token
  ) {
    if (simulationService.getAuthorEmail(simulationIdDTO.id()).equals(
            token.getPrincipal().getAttribute(EMAIL)
    )) {
      SimulationLinkDTO response = simulationService.makePrivate(simulationIdDTO.id());
      return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
  }

  @PostMapping("/my")
  public ResponseEntity<List<SimulationDTO>> getUserSimulation(
          OAuth2AuthenticationToken token,
          @RequestBody GetMySimulationsDTO dto
  ) {
    String email = token.getPrincipal().getAttribute(EMAIL);
    Sort sort;
    String prefix = "";
    String param = dto.param();

    if ("populationSize".equals(param) ||
            "wage".equals(param) ||
            "transportationCost".equals(param) ||
            "constructionCostLimit".equals(param) ||
            "rentLimit".equals(param)) {
      prefix = "city.";
    }

    boolean isAsc = dto.isAsc() != null && dto.isAsc();
    sort = Sort.by(isAsc ? Sort.Direction.ASC : Sort.Direction.DESC, prefix + param);

    List<SimulationDTO> simulations = simulationService.getUsersSimulations(email, sort, dto.limit(), dto.offset());
    return ResponseEntity.ok(simulations);
  }


  @GetMapping("/shared/{simulationId}")
  public ResponseEntity<SimulationDTO> getSharedSimulation(@PathVariable String simulationId){
    Simulation simulation = simulationService.getSimulationById(simulationId);
    if (simulation.isPublic()) {
      return ResponseEntity.ok(new SimulationDTO(simulation));
    }
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
  }


  @PostMapping("/deleteSimulation")
  public void  deleteSimulation(@RequestBody SimulationIdDTO simulationIdDTO, OAuth2AuthenticationToken token) {
    Simulation simulation = simulationService.getSimulationById(simulationIdDTO.id());
    if (simulation.getAuthorEmail().equals(token.getPrincipal().getAttribute(EMAIL))) {
      simulationService.deleteSimulation(simulationIdDTO.id());
      oldSimulationService.deleteSimulationsByParentId(simulationIdDTO.id());
    }
  }

  /**
   * Gets old simulations by their parent simulation id.
   *
   * @param parentSimulationId    The id of the parent simulation, which old simulations are associated with.
   * @param token  The OAuth2AuthenticationToken of the user.
   * @return A ResponseEntity containing the list of old simulations if successful,
   *         or a 401 Unauthorized status if the user is not authorized to get old simulation list.
   */
  @GetMapping("/getUserOldSimulations/{parentSimulationId}")
  public ResponseEntity<List<OldSimulationDTO>> getOldSimulations(@PathVariable String parentSimulationId,
                                                                  OAuth2AuthenticationToken token){
    String userEmail = token.getPrincipal().getAttribute(EMAIL);
    Simulation simulation = simulationService.getSimulationById(parentSimulationId);

    if (!simulation.getAuthorEmail().equals(userEmail)) {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
    }

    List<OldSimulationDTO> oldSimulations = oldSimulationService.getUserOldSimulations(parentSimulationId)
            .stream()
            .map(OldSimulationDTO::new)
            .toList();

    return ResponseEntity.ok(oldSimulations);
  }


  /**
   * Gets coordinates for old blocks in a simulation.
   * This endpoint allows the author of the simulation to get x and y coordinates for specific old blocks.
   *
   * @param dto    The FindBLockDTO containing x coordinate, y coordinate, and simulation id.
   * @param token  The OAuth2AuthenticationToken of the user.
   * @return A ResponseEntity containing the old block object if successful,
   *         or a 401 Unauthorized status if the user is not authorized to get old block coordinates.
   */
  @PostMapping (path = "/getOldBlockByCoordinates")
  public ResponseEntity<Block> getOldSimulation(@RequestBody FindBlockDTO dto, OAuth2AuthenticationToken token) {
    Simulation simulation = oldSimulationService.getSimulationById(dto.simulationId());
    if (simulation.isPublic() || simulation.getAuthorEmail().equals(token.getPrincipal().getAttribute(EMAIL))) {
      Block block = oldSimulationService.oldBlockGetterFromSimulation(dto);
      return ResponseEntity.ok(block);
    }
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
  }

}
