package ch.usi.inf.bsc.sa4.lab02spring.model;

/**
 * Enum representing different types of blocks.
 */
public enum BTypes {
    RESIDENTIALBLOCK,
    WATERBLOCK,
    PARKBLOCK
}
