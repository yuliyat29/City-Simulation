package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;

/**
 * An output DTO representing the link to a specific simulation.
 *
 * @param link the link to the simulation.
 */
public record SimulationLinkDTO(String link) {
  public SimulationLinkDTO(Simulation simulation) {
    this("http://localhost:3000/simulations/shared/" + simulation.get_id().toString());
  }
}
