package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import ch.usi.inf.bsc.sa4.lab02spring.model.BTypes;

import java.util.List;

/**
 *  Input DTO that is used to change the Block type within a simulation for one or multiple blocks
 * @param simulationId the simulation from where the blocks belong
 * @param xCoordinates list of x coordinates of the blocks
 * @param yCoordinates list of y coordinates of the blocks
 * @param newBlockType the block type that the block/blocks need to be changed into
 */
public record UpdateBlockTypeDTO(
        String simulationId,
        List<Integer> xCoordinates,
        List<Integer> yCoordinates,
        BTypes newBlockType) {

}
