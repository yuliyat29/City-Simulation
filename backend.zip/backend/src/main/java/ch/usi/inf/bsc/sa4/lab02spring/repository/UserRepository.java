package ch.usi.inf.bsc.sa4.lab02spring.repository;

import ch.usi.inf.bsc.sa4.lab02spring.model.User;
import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;

import org.bson.conversions.Bson;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends MongoRepository<User, String> {
  // You can implement complex "predefined" logic with specific conventions by specific method names
  // Documentation link:
  // https://docs.spring.io/spring-data/mongodb/docs/current/reference/html/#mongodb.repositories.queries
  List<User> findByNameContaining(String string);

  Optional<User> findByEmail(String email);

  @Query("{'email': { $ne: ?0 }}")
  List<User> findAllExceptMe(String emailToExclude,  Pageable pageable);

  @Query("{'email': { $ne: ?0 }}")
  List<User> findAllExceptMeUsers(String emailToExclude);




  // You can also implement arbitrary complex logic using a standard default method
  default List<User> somePeculiarLogic() {
    return this.findAll();
  }
}
