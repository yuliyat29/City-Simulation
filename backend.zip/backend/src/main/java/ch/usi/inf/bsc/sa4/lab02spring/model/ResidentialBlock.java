package ch.usi.inf.bsc.sa4.lab02spring.model;

/**
 * this class appears to be a component of a broader system
 * that models different types of blocks
 */
public class ResidentialBlock extends Block {

  /**
  * Height of this block
  */
  protected int height;
  /**
   * Number of people in this block
   */
  protected int numberOfPeople;
  /**
   * Transportation costs for this block
   */
  protected double transportationCost;
  /**
   * Cost of rent in this block
   */
  protected double costOfRent;
  /**
   * Cost of Land in this block
   */
  protected double costOfLand;
  /**
   * Construction costs for this block
   */
  protected double constructionCost;
  /**
   * Constructions costs limit for this block
   */
  protected double constructionCostLimit;
  /**
   * Rent limit for this block
   */
  protected double rentLimit;

  /**
   * creating a new ResidentialBlock object with specified parameters
   */
  public ResidentialBlock(
          int x,
          int y,
          int height,
          BTypes type,
          double transportationCost,
          int numberOfPeople,
          double costOfRent,
          double costOfLand,
          double rentLimit,
          double constructionCostLimit,
          double constructionCost
  ) {
    super(x, y, type);
    this.height = height;
    this.transportationCost = transportationCost;
    this.numberOfPeople = numberOfPeople;
    this.costOfRent = costOfRent;
    this.costOfLand = costOfLand;
    this.rentLimit = rentLimit;
    this.constructionCostLimit = constructionCostLimit;
    this.constructionCost = constructionCost;
  }

  /**
   * Returns the height of this block
   *
   * @return height of the block
   */
  public int getHeight() {
    return height;
  }

  /**
   * Returns the transportation costs of the block
   *
   * @return transportation costs of the block
   */
  public double getTransportationCost() {
    return transportationCost;
  }

  /**
   * Return the number of people in the block
   *
   * @return number of people in the block
   */
  public int getNumberOfPeople() {
    return numberOfPeople;
  }

  /**
   * Return the cost of rent in the block
   *
   * @return cost of rent in the block
   */
  public double getCostOfRent() {
    return costOfRent;
  }

  /**
   * Return the cost of land in the block
   *
   * @return cost of land in the block
   */
  public double getCostOfLand() {
    return costOfLand;
  }

  /**
   * Returns construction costs for this block
   *
   * @return construction costs for this block
   */
  public double getConstructionCost() {
    return this.constructionCost;
  }

  /**
   * Returns the rent limit for this block
   *
   * @return rent limit for this block
   */
  public double getRentLimit() {
    return this.rentLimit;
  }

  /**
   * Returns construction costs limit for this block
   *
   * @return constructions costs limit for this block
   */
  public double getConstructionCostLimit() {
    return this.constructionCostLimit;
  }

  /**
   * Return stets height of the block
   *
   * @param height a new height
   */
  public void setHeight(int height) {
    this.height = height;
  }

  /**
   * Sets the number of people fot the block
   *
   * @param numberOfPeople a new number of people
   */
  public void setNumberOfPeople(int numberOfPeople) {
    this.numberOfPeople = numberOfPeople;
  }

  /**
   * Sets the cost of rent for the block
   *
   * @param costOfRent a new cost of rent
   */
  public void setCostOfRent(double costOfRent) {
    this.costOfRent = costOfRent;
  }

  /**
   * Sets the construction costs for this block
   * @param constructionCost new construction costs for this block
   */
  public void setConstructionCost(double constructionCost) {
    this.constructionCost = constructionCost;
  }

  /**
   * Sets the transportation costs for the block
   *
   * @param transportationCost new transportation costs
   */
  public void setTransportationCost(double transportationCost) {
    this.transportationCost = transportationCost;
  }

  /**
   * Sets the rent limit for this block
   *
   * @param rentLimit new rent limit
   */
  public void setRentLimit(double rentLimit) {
    this.rentLimit = rentLimit;
  }

  /**
   * Sets the construction costs limit for this block
   *
   * @param constructionCostLimit new construction costs limti
   */
  public void setConstructionCostLimit(double constructionCostLimit) {
    this.constructionCostLimit = constructionCostLimit;
  }

}
