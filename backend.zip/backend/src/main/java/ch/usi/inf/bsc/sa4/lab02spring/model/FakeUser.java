package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class FakeUser implements OAuth2User {

  private HashMap< String, Object > attributesMap = new HashMap<>();
  private OAuth2AuthenticationToken token;

  public FakeUser(String email, String fullName) {
    this.attributesMap.put("email", email);
    this.attributesMap.put("name", fullName);
    this.token = new OAuth2AuthenticationToken(
            this,
            Collections.emptyList(),
            "dummy-registration-id");
  }

  @Override
  public < A > A getAttribute(String name) {
    return (A) this.attributesMap.get(name);
  }

  @Override
  public Map< String, Object > getAttributes() {
    return Collections.unmodifiableMap(this.getAttributes());
  }

  @Override
  public Collection< ? extends GrantedAuthority > getAuthorities() {
    return null;
  }

  @Override
  public String getName() {
    return (String) this.attributesMap.get("name");
  }

  public OAuth2AuthenticationToken getToken() {
    return this.token;
  }
}
