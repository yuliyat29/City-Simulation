package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

public record GetMySimulationsDTO(String param, Boolean isAsc, int offset, int limit) {
}
