package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import ch.usi.inf.bsc.sa4.lab02spring.model.City;
import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;

/**
 * An output DTO representing a simulation information.
 *
 * @param _id mongodb id field
 * @param populationSize the simulation populationSize
 * @param wage wage
 * @param transportationCost transportation cost
 * @param simulationName the name of newly generated simulation
 * @param authorEmail the author of simulation
 * @param isPublic public or private simulation
 * @param simulationPicture the small preview picture of simulation
 * @param city the json representation of city blocks
 *
 */
public record SimulationDTO(
        String _id,
        int populationSize,
        double wage,
        double transportationCost,
        double constructionCostLimit,
        double rentLimit,

        String simulationName,
        String authorEmail,
        boolean isPublic,
        String simulationPicture,
        City city) {
  public SimulationDTO(Simulation simulation) {
    this(
                simulation.get_id().toString(),
                simulation.getCity().getPopulationSize(),
                simulation.getCity().getWage(),
                simulation.getCity().getTransportationCost(),
                simulation.getCity().getConstructionCostLimit(),
                simulation.getCity().getRentLimit(),
                simulation.getSimulationName(),
                simulation.getAuthorEmail(),
                simulation.isPublic(),
                simulation.getSimulationPicture(),
                simulation.getCity()
        );
    }
}
