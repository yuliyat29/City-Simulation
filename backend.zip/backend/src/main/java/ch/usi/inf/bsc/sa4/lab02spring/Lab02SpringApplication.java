package ch.usi.inf.bsc.sa4.lab02spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Runs our application
 */
@SpringBootApplication
public class Lab02SpringApplication {
    /**
     * Main runs the application
     */
  public static void main(String[] args) {
      SpringApplication.run(Lab02SpringApplication.class, args);
  }
}
