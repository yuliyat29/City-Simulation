package ch.usi.inf.bsc.sa4.lab02spring.controller;

import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.GetMyUserListDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.GetUserDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UserDTO;
import ch.usi.inf.bsc.sa4.lab02spring.model.User;
import ch.usi.inf.bsc.sa4.lab02spring.service.UserService;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

/**
 * The controller for users.
 */
@RestController
@RequestMapping("/users")
public class UserController {

  private static final String EMAIL_ATTRIBUTE = "email";
  private final UserService userService;


  @Autowired
  public UserController(UserService userService) {
    this.userService = userService;
  }

  /**
   * Returns the attributes(fullName and email) of the user after SwitchEduID Authentication
   *
   * @return instance record class SwitchEduID
   */
  @GetMapping(path = "/createUser")
    public ResponseEntity< UserDTO > index(OAuth2AuthenticationToken authentication) {

    String fullName = authentication.getPrincipal().getAttribute("name");
    String email = authentication.getPrincipal().getAttribute(EMAIL_ATTRIBUTE);
    Optional<User> userExist = userService.getByEmail(email);

    if (userExist.isEmpty()) {
      User user = userService.createUser(fullName, email);
      UserDTO returnedUser = new UserDTO(user);
      return ResponseEntity.ok(returnedUser);
    } else {
      return ResponseEntity.ok().build();
    }
  }


  /**
   * Verifies if a user is authenticated
   * @param token the authentication token
   * @return the response of whether a user is authenticated
   */
  @GetMapping(path = "/isAuthenticated")
  public ResponseEntity<Boolean> isAuthenticated(OAuth2AuthenticationToken token) {
    boolean isAuthenticated = token != null;
    return ResponseEntity.ok(isAuthenticated);
  }

    /**
     * Returns the list of users except for the user in control
     * @param authentication the authentication token of the user
     * @return a list of existing users except the one in control
     */
  @PostMapping( path = "/getAllExceptMe" )
  public ResponseEntity<List<GetUserDTO>> getAllExceptMe(OAuth2AuthenticationToken authentication,
                                                         @RequestBody GetMyUserListDTO dto) {
    String email = authentication.getPrincipal().getAttribute(EMAIL_ATTRIBUTE);
    int limit = dto.limit();
    int offset = dto.offset();
    List<User> users = userService.getAllExceptMe(email, limit, offset);
    Stream<User> userStream = users.stream();
    List<GetUserDTO> listUsersDTO = userStream.map(GetUserDTO::new).toList();
    return ResponseEntity.ok(listUsersDTO);
  }

  @GetMapping(path = "/countUsers")
    public ResponseEntity<Long> countUsers(OAuth2AuthenticationToken token) {
    String email = token.getPrincipal().getAttribute(EMAIL_ATTRIBUTE);
    long userCount = userService.countAllUsersExceptMe(email);
    return ResponseEntity.ok().body(userCount);

  }

  /**
   * Returns the list of existing users.
   *
   * @return a list of existing users.
   */
  @GetMapping
    public ResponseEntity<List<UserDTO>> getAll() {
    List<UserDTO> listUsersDTO = userService.getAll().stream().map(UserDTO::new).toList();
    return ResponseEntity.ok(listUsersDTO);
  }

  /**
   * Returns the user in control
   * @param authenticationToken the authentication token
   * @return the info of the user in control of the current session
   */
  @GetMapping(path = "/getMe")
    public ResponseEntity<Optional<UserDTO>> getMe(OAuth2AuthenticationToken authenticationToken) {
    String email = authenticationToken.getPrincipal().getAttribute(EMAIL_ATTRIBUTE);
    Optional<UserDTO> user = userService.getByEmail(email).map(UserDTO::new);
    return ResponseEntity.ok(user);
  }


  /**
   *  Uploads a profile photo
   * @param photo the image file used as profile photo
   * @param authentication the authentication token
   * @return the user with the uploaded photo picture
   * @throws IOException if the photo is in an invalid format
   */
  @PostMapping(path = "/uploadProfilePhoto")
    public ResponseEntity<UserDTO> uploadProfilePhoto
            (@RequestParam("photo") MultipartFile photo, OAuth2AuthenticationToken authentication) throws IOException {
    String email = authentication.getPrincipal().getAttribute(EMAIL_ATTRIBUTE);
    String pictureUrl = userService.uploadPic(photo, email);
    User updatedUser = userService.uploadProfilePhoto(pictureUrl, email);
    UserDTO userDTO = new UserDTO(updatedUser);
    return ResponseEntity.ok(userDTO);
  }


  /**
   * Returns the user dto with the given id.
   *
   * @param userId a path variable containing the user's id.
   * @return a 200 OK if the user exists, a 404 NOT FOUND otherwise.
   */
  @GetMapping("/{userId}")
    public ResponseEntity<UserDTO> getById(@PathVariable String userId) {
    return ResponseEntity.of(userService.getById(userId).map(UserDTO::new));
  }
}




