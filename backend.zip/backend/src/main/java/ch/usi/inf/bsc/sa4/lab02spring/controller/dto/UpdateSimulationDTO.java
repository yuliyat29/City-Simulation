package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;
/**
 * An input DTO used to update an existing simulation.
 */
public record UpdateSimulationDTO(
        String _id,
        double wage,
        double transportationCost,
        double constructionCostLimit,
        double rentLimit,
        String simulationName) {
}
