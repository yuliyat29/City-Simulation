package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

public record GetMyUserListDTO(String param, Boolean isAsc, int offset, int limit) {
}
