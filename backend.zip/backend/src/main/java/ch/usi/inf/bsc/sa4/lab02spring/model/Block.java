package ch.usi.inf.bsc.sa4.lab02spring.model;

/**
 * Represents a Block in the simulation.
 *
 * A Block is an element that occupies a tile in the simulation.
 * It has coordinates (x, y) and a type that determines its appearance.
 */
public class Block {

  /**
   * the x coordinate of the block
   */
  protected int x;

  /**
   * the y coordinate of the block
   */
  protected int y;

  /**
   * what kind of area the block represent
   */
  protected BTypes type;

  /**
   * the taxicab distance from the CBD
   */
  protected int distanceFromCenter;

  /**
   * Constructs a Block with the given coordinates
   *
   * @param x    the x-coordinate of the block
   * @param y    the y-coordinate of the block
   * @param type the type of the block
   */
  public Block(int x, int y, BTypes type) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.distanceFromCenter = Toolbelt.taxicabDistance(this.x, this.y, 0, 0);
  }

  public int getX() {
    return x;
  }

  public int getY() {
    return y;
  }

  public BTypes getType() {
    return type;
  }

  public int getDistanceFromCenter() {
    return distanceFromCenter;
  }

  public void setX(int x) {
    this.x = x;
  }

  public void setY(int y) {
    this.y = y;
  }

  public void setType(BTypes type) {
    this.type = type;
  }
}
