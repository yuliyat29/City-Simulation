package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

/**
 * An output DTO representing the simulation id.
 *
 * @param id the simulation id
 */
public record SimulationIdDTO(String id) {
}
