package ch.usi.inf.bsc.sa4.lab02spring.model;

/**
 * A WaterBlock represents a block that is designated as a tiles filled with water.
 * It extends the Block class.
 */
public class WaterBlock extends Block {

  /**
   * Constructs a water block
   *
   * @param x the x coordinate of the block
   * @param y the y coordinate of the block
   * @param type the type of the block
   */
  public WaterBlock(int x, int y, BTypes type) {
    super(x, y, type);
  }

}
