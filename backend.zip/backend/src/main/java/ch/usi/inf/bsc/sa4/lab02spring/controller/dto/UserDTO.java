package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import ch.usi.inf.bsc.sa4.lab02spring.model.User;

/**
 * An output DTO representing a user's public information.
 *
 * @param email the user's email.
 * @param name the user's name.
 */
public record UserDTO(String name, String email, String profilePhoto) {
  public UserDTO(User user) {
    this(user.getName(), user.getEmail(), user.getProfilePhoto());
  }

}
