package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import java.util.List;

/**
 * An input DTO used to update construction costs of certain block of a city.
 *
 * @param simulationId id of the simulation that a user wants to update
 * @param xCoordinates list of x coordinates
 * @param yCoordinates list of y coordinates
 * @param newRentLimit new rent limit
 */
public record UpdateRentLimitDTO(
        String simulationId,
        List<Integer> xCoordinates,
        List<Integer> yCoordinates,
        double newRentLimit) {
}
