package ch.usi.inf.bsc.sa4.lab02spring.repository;

import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * defines methods for querying simulation entities
 */
@Repository
public interface SimulationRepository extends MongoRepository<Simulation, String> {

  /**
   * declares a method that counts the number of documents in the MongoDB
   * authorEmail matches the provided value
   */
  long countByAuthorEmail(String authorEmail);

  /**
   * Deletes an OldSimulation by its ID.
   *
   * @param id The ID of the OldSimulation to delete.
   */
  void deleteSimulationBy_id(ObjectId id);

  /**
   * executes the custom MongoDb query
   * a pageable parameter allows for pagination and sorting of the results
   * a list of simulation objects matching the criteria defined in the query
   */
  @Query(value = "{'authorEmail' :  ?0}")
  List<Simulation> findUsersSimulations(String email, Pageable pageable);
}
