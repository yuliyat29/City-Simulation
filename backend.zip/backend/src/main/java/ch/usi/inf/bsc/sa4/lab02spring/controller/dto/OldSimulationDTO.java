package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import ch.usi.inf.bsc.sa4.lab02spring.model.City;
import ch.usi.inf.bsc.sa4.lab02spring.model.OldSimulation;

import java.util.Date;

/**
 * An output DTO representing a simulation information.
 *
 * @param _id mongodb id field
 * @param parentId id of the parent simulation
 * @param simulationName the name of newly generated simulation
 * @param authorEmail the author of simulation
 * @param isPublic public or private simulation
 * @param city the json representation of city blocks
 * @param simulationPicture the small preview picture of simulation
 * @param updateDate the date when simulation was updated
 * @param populationSize the simulation populationSize
 * @param wage wage
 * @param transportationCost transportation cost
 * @param constructionCostLimit construction cost limit
 */
public record OldSimulationDTO(
        String _id,
        String parentId,
        String simulationName,
        String authorEmail,
        boolean isPublic,
        City city,
        String simulationPicture,
        Date updateDate,
        int populationSize,
        double wage,
        double transportationCost,
        double constructionCostLimit,
        double rentLimit) {
  public OldSimulationDTO(OldSimulation oldSimulation) {
    this(
            oldSimulation.get_id().toString(),
            oldSimulation.getParentId().toString(),
            oldSimulation.getSimulationName(),
            oldSimulation.getAuthorEmail(),
            oldSimulation.isPublic(),
            oldSimulation.getCity(),
            oldSimulation.getSimulationPicture(),
            oldSimulation.getUpdateDate(),
            oldSimulation.getCity().getPopulationSize(),
            oldSimulation.getCity().getWage(),
            oldSimulation.getCity().getTransportationCost(),
            oldSimulation.getCity().getConstructionCostLimit(),
            oldSimulation.getCity().getRentLimit()
    );
  }
}
