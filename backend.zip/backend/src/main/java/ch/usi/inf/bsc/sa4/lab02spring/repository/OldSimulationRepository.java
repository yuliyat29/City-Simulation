package ch.usi.inf.bsc.sa4.lab02spring.repository;

import ch.usi.inf.bsc.sa4.lab02spring.model.OldSimulation;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * Repository interface for interacting with the OldSimulation collection in the MongoDB database.
 */
@Repository
public interface OldSimulationRepository extends MongoRepository<OldSimulation, String> {


  /**
   * Retrieves a list of OldSimulations associated with the given parent simulation ID.
   *
   * @param parentSimulationId The ID of the parent simulation.
   * @return A list of OldSimulations belonging to the specified parent simulation.
   */
  @Query(value = "{ 'parentId' : ?0 }")
  List<OldSimulation> findUserOldSimulations(ObjectId parentSimulationId);


  /**
   * Deletes an OldSimulation by its ID.
   *
   * @param id The ID of the OldSimulation to delete.
   */
  void deleteBy_id(ObjectId id);


  /**
   * Deletes an OldSimulations by its ParentID.
   *
   * @param parentId The ParentID of the OldSimulations to delete.
   */
  void deleteByParentId(ObjectId parentId);
}
