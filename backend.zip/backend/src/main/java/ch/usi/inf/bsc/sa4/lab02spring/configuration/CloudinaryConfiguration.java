package ch.usi.inf.bsc.sa4.lab02spring.configuration;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * configured as a managed bean within the Spring application context
 */
@Configuration
@PropertySource("classpath:cloudinary.properties")
public class CloudinaryConfiguration {

  /**
   * declared a private instance variable
   */
  @Value("${cloudinary.cloud_name}")
  private String cloudName;

  /**
   * declared a private instance variable
   */
  @Value("${cloudinary.api_key}")
  private String apiKey;

  /**
   * declared a private instance variable
   */
  @Value("${cloudinary.api_secret}")
  private String apiSecret;

  /**
   * this method creates and configures a new Cloudinary instance based on the provided parameters
   */
  @Bean
  public Cloudinary cloudinary() {
    return new Cloudinary(ObjectUtils.asMap(
            "cloud_name", cloudName,
            "api_key", apiKey,
            "api_secret", apiSecret));
  }
}

