package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

/**
 * An input DTO used to find a block with the given coordinates inside a simulation with the given id.
 */
public record FindBlockDTO(int x, int y, String simulationId) {
}
