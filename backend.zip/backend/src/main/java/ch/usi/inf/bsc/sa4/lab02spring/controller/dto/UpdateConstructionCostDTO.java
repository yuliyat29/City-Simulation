package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import java.util.List;

/**
 * An input DTO used to update construction costs of certain block of a city.
 */
public record UpdateConstructionCostDTO (
        String simulationId,
        List<Integer> xCoordinates,
        List<Integer> yCoordinates,
        double newConstructionCostLimit) {
}

