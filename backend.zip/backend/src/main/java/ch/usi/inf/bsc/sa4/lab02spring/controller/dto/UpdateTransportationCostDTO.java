package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

import java.util.List;

/**
 * An input DTO used to update transportation costs of certain blocks of a city.
 */
public record UpdateTransportationCostDTO(
        String simulationId,
        List<Integer> xCoordinates,
        List<Integer> yCoordinates,
        double newTransportationCost) {
}

