package ch.usi.inf.bsc.sa4.lab02spring.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceCreator;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Objects;

/**
 * Represents a user.
 */
@Document(collection="users")
public class User {

  /**
   * Unique identifier for the user.
   */
  @Id
  protected ObjectId _id;

  /**
   * The name of the user.
   */
  private String name;

  /**
   * The email address of the user.
   */
  private final String email;

  /**
   * The URL of the user's profile photo.
   */
  private String profilePhoto;

  /**
   * Constructor for creating a User object.
   *
   * @param name         The name of the user.
   * @param email        The email address of the user.
   * @param profilePhoto The URL of the user's profile photo.
   */
  @PersistenceCreator
  public User(String name, String email, String profilePhoto) {
    this.name = name;
    this.email = email;
    this.profilePhoto = profilePhoto;
  }

  /**
   * Returns the unique identifier of the user.
   *
   * @return The unique identifier of the user.
   */
  public ObjectId getId() {
    return _id;
  }

  /**
   * Sets the unique identifier of the user.
   *
   * @param _id The unique identifier to set.
   */
  public void setId(ObjectId _id) {
    this._id = _id;
  }

  /**
   * Returns the name of the user.
   *
   * @return The name of the user.
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the name of the user.
   *
   * @param name The name to set.
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Returns the email address of the user.
   *
   * @return The email address of the user.
   */
  public String getEmail() {
    return email;
  }

  /**
   * Returns the profile photo URL of the user.
   *
   * @return The profile photo URL of the user.
   */
  public String getProfilePhoto() {
    return profilePhoto;
  }

  /**
   * Sets the profile photo URL of the user.
   *
   * @param profilePhoto The profile photo URL to set.
   */
  public void setProfilePhoto(String profilePhoto) {
    this.profilePhoto = profilePhoto;
  }

  /**
   * Generates the hash code for the user object based on its email address.
   *
   * @return The hash code for the user object.
   */
  @Override
  public int hashCode() {
    return Objects.hash(email);
  }

  /**
   * Checks if the current user object is equal to another object.
   *
   * @param other The object to compare for equality.
   * @return True if the objects are equal, false otherwise.
   */
  @Override
  public boolean equals(Object other) {
    if (this == other) {
      return true;
    }
    if (other == null || getClass() != other.getClass()) {
      return false;
    }
    final User otherUser = (User) other;
    return Objects.equals(email, otherUser.email);
  }

}
