package ch.usi.inf.bsc.sa4.lab02spring.service;

import ch.usi.inf.bsc.sa4.lab02spring.model.User;
import ch.usi.inf.bsc.sa4.lab02spring.repository.UserRepository;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;



/**
 * A service class to support user management.
 */
@Service
public class UserService {


  /**
   * profile photo string set as empty
   */
  private static final String EMPTY_PROFILE_PHOTO = "";

  /**
   * Repository interface for accessing and manipulating User entities in the database.
   */
  private final UserRepository userRepository;

  /**
   * An instance of Cloudinary used for handling cloud storage and image manipulation.
   */
  @Resource
  private Cloudinary cloudinary;

  /**
   * Constructs a new instance of UserService with the provided UserRepository.
   *
   * @param userRepository The repository for user-related operations.
   */
  @Autowired
  public UserService(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  /**
   * Returns all existing users.
   *
   * @return a list of all existing users.
   */
  public List<User> getAll() {
    return this.userRepository.findAll();
  }

  /**
   *  Returns all existing users except the one in control of the session
   * @param email the email of user in control
   * @return a list of all users except for the one in control
   */
  public List<User> getAllExceptMe(String email, int limit, int offset) {
    final Pageable pageable = PageRequest.of(offset / limit, limit);
    return this.userRepository.findAllExceptMe(email, pageable);
  }

  /**
   * Return the number of all users except me
   *
   * @param authorEmail the email of the author
   * @return number of all users except me
   */
  public long countAllUsersExceptMe(String authorEmail) {
    return userRepository.findAllExceptMeUsers(authorEmail).stream().count();
  }

  /**
   * Persists any change to a user identified by its own ID.
   *
   * @param user a user.
   * @return the updated user.
   * @spec.modifies the persisted user.
   */
  public User storeUser(User user) {
    return userRepository.save(user);
  }

  /**
   * Deletes all the users from the database
   *
   */
  public void cleanAllUsers() {userRepository.deleteAll();}


  /**
   *  Deletes a single user from the database
   * @param user the user that needs to be deleted
   */
  public void deleteUser(User user) { userRepository.delete(user); }

  /**
   * Creates a new user and persists it in the DB.
   *
   * @param fullName the fullName of user.
   * @param email the email of user.
   * @return the newly created user.
   */
  public User createUser(String fullName, String email) {
    final User newUser = new User(fullName, email, EMPTY_PROFILE_PHOTO);
    return this.storeUser(newUser);
  }

  /**
   * Looks for a user by its id.
   *
   * @param userId
   * @return an optional which contains the user with the given id if it exists, otherwise an empty optional.
   * @spec.requires <code>userId != null</code>
   */
  public Optional<User> getById(String userId) {
    return userRepository.findById(userId);
  }

  /**
   *  Returns a user found through his email
   * @param email the user's email
   * @return the user found by his email
   */
  public Optional<User> getByEmail(String email) {
    return userRepository.findByEmail(email);
  }


  /**
   * Deletes the old picture(if one already exists) from cloudinary storage in order to save space
   * Upload the picture and get its URL
   * @param photo the photo chosen by the user
   * @return the URL of the picture
   */
  public String uploadPic(MultipartFile photo, String email) throws IOException {

    final Optional<User> user = getByEmail(email);
    if (user.isPresent()) {
      final User updatedUser = user.get();
      final String profilePhoto = updatedUser.getProfilePhoto();
      if(!profilePhoto.isEmpty()) {
        final String[] parts = profilePhoto.split("/");
        final String publicId = parts[parts.length - 1].split("\\.")[0];
        cloudinary.uploader().destroy(publicId, ObjectUtils.emptyMap());
      }
    } else{
      throw new NoSuchElementException("User not found for email: " + email);
    }

    final Map<String, Object> uploadedFile = cloudinary.uploader().upload(photo.getBytes(), ObjectUtils.emptyMap());
    final String publicId = (String) uploadedFile.get("public_id");
    return cloudinary.url().secure(true).generate(publicId);

  }

  /**
   * The user in control uploads his picture as his profile photo and it gets added in the user database
   *
   * @param pictureUrl the URL of the picture
   * @param email the email of the user
   * @return the updated user, now with his photo info added
   */
  public User uploadProfilePhoto(String pictureUrl, String email) {
    final Optional<User> user = getByEmail(email);
    if (user.isPresent()) {
      final User updatedUser = user.get();
      updatedUser.setProfilePhoto(pictureUrl);
      return storeUser(updatedUser);
    } else{
      throw new NoSuchElementException("User not found for email: " + email);
    }
  }

}

