package ch.usi.inf.bsc.sa4.lab02spring.controller.dto;

/**
 * An input DTO used to create a new simulation.
 *
 */
public record CreateSimulationDTO(double wage,
                                  double transportationCost,
                                  double constructionCostLimit,
                                  double rentLimit,
                                  String simulationName) {
}
