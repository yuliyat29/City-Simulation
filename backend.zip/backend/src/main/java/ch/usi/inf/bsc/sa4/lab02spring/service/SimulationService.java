package ch.usi.inf.bsc.sa4.lab02spring.service;

import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.CreateSimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.FindBlockDTO;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.SimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.model.Block;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.SimulationLinkDTO;
import ch.usi.inf.bsc.sa4.lab02spring.model.City;
import ch.usi.inf.bsc.sa4.lab02spring.model.OldSimulation;
import ch.usi.inf.bsc.sa4.lab02spring.model.Simulation;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UpdateSimulationDTO;
import ch.usi.inf.bsc.sa4.lab02spring.repository.OldSimulationRepository;
import ch.usi.inf.bsc.sa4.lab02spring.repository.SimulationRepository;
import ch.usi.inf.bsc.sa4.lab02spring.controller.dto.UpdateBlockTypeDTO;

import ch.usi.inf.bsc.sa4.lab02spring.model.BTypes;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * A service class to support simulation management.
 */
@Service
public class SimulationService {
    private final SimulationRepository simulationRepository;
    private final OldSimulationService oldSimulationService;

    @Autowired
    public SimulationService(SimulationRepository simulationRepository, OldSimulationService oldSimulationService) {
        this.simulationRepository = simulationRepository;
        this.oldSimulationService = oldSimulationService;
    }

    /**
     * Creates a new simulation and persists it in the DB.
     *
     * @param dto The simulation dto with its fields.
     * @param email the email of a user
     * @return The newly created simulation along with its MongoDB _id
     */
    public SimulationDTO createSimulation(CreateSimulationDTO dto, String email) {
        String simulationPicture = "";
        Date data = new Date();
        boolean isPublic = false;
        Simulation simulation = new Simulation(
                dto.wage(),
                dto.transportationCost(),
                dto.constructionCostLimit(),
                dto.rentLimit(),
                dto.simulationName(),
                email,
                isPublic,
                simulationPicture,
                data,
                data
        );
        Simulation savedSimulation = this.storeSimulation(simulation);
        return new SimulationDTO(savedSimulation);
    }


    /**
     * Deletes the given OldSimulation entity using its _id field as the identifier.
     *
     * @param simulationId the id of the simulation to be deleted.
     */
    public void deleteSimulation(String simulationId) {
        simulationRepository.deleteSimulationBy_id(new ObjectId(simulationId));
    }

    /**
     * Persists any change to a simulation identified by its own ID.
     *
     * @param simulation a simulation.
     * @return the updated simulation.
     * @spec.modifies the persisted simulation.
     */
    public Simulation storeSimulation(Simulation simulation) {
        return simulationRepository.save(simulation);
    }




    /**
     * Updates the simulation, taking into account the wage, transportation cost and construction cost limit
     *
     * @param dto the Update Simulation DTO
     * @return the newly updated simulation
     */
    public SimulationDTO updateSimulation(UpdateSimulationDTO dto) {
        Simulation simulation = this.getSimulationById(dto._id());

        simulation.setUpdateDate(new Date());
        oldSimulationService.storeSimulationAsOld(simulation);

        simulation.setSimulationName(dto.simulationName());
        City updatedCity = new City(dto.wage(), dto.transportationCost(), dto.constructionCostLimit(), dto.rentLimit());
        simulation.setCity(updatedCity);
        this.storeSimulation(simulation);
        return new SimulationDTO(simulation);
    }

    /**
     * Updates the transportation cost for selected parcels of blocks in the city
     *
     * @param simulationId the simulation id
     * @param xCoordinates the list of x coordinates of blocks
     * @param yCoordinates the list of y coordinates of blocks
     * @param newTransportationCost new transportation cost
     * @return the newly updated simulation
     */
    public SimulationDTO updateTransportationCost(
            String simulationId,
            List<Integer> xCoordinates,
            List<Integer> yCoordinates,
            double newTransportationCost
    ) {
        Simulation simulation = getSimulationById(simulationId);

        simulation.setUpdateDate(new Date());
        oldSimulationService.storeSimulationAsOld(simulation);

        City city = simulation.getCity();
        city.updateBlocks(xCoordinates, yCoordinates, newTransportationCost);
        return new SimulationDTO(this.storeSimulation(simulation));
    }

    /**
     * Updates the construction cost limit for selected parcels of blocks in the city
     *
     * @param simulationId the simulation id
     * @param xCoordinates the list of x coordinates of blocks
     * @param yCoordinates the list of y coordinates of blocks
     * @param newConstructionCostLimit new construction cost limit
     * @return the newly updated simulation
     */
    public SimulationDTO updateLocalConstructionCostLimit(
            String simulationId,
            List<Integer> xCoordinates,
            List<Integer> yCoordinates,
            double newConstructionCostLimit
    ) {
        Simulation simulation = getSimulationById(simulationId);

        simulation.setUpdateDate(new Date());
        oldSimulationService.storeSimulationAsOld(simulation);

        City city = simulation.getCity();
        city.updateLocalConstructionLimit(xCoordinates, yCoordinates, newConstructionCostLimit);
        return new SimulationDTO(this.storeSimulation(simulation));
    }

    /**
     * Updates the rent limit for selected parcels of blocks in the city
     *
     * @param simulationId the simulation id
     * @param xCoordinates the list of x coordinates of blocks
     * @param yCoordinates the list of y coordinates of blocks
     * @param newRentLimit new rent limit
     * @return the newly updated simulation
     */
    public SimulationDTO updateLocalRentLimit(
            String simulationId,
            List<Integer> xCoordinates,
            List<Integer> yCoordinates,
            double newRentLimit
    ) {
        Simulation simulation = getSimulationById(simulationId);

        simulation.setUpdateDate(new Date());
        oldSimulationService.storeSimulationAsOld(simulation);

        City city = simulation.getCity();
        city.updateLocalRentLimits(xCoordinates, yCoordinates, newRentLimit);
        return new SimulationDTO(this.storeSimulation(simulation));
    }

    /**
     * Updates the block type for selected parcels of blocks in the city
     *
     * @param simulationId the simulation id
     * @param xCoordinates the list of x coordinates of blocks
     * @param yCoordinates the list of y coordinates of blocks
     * @param newBlockType new block type
     * @return the newly updated simulation
     */
    public SimulationDTO updateBlockTypes(
            String simulationId,
            List<Integer> xCoordinates,
            List<Integer> yCoordinates,
            BTypes newBlockType
    ) {
        Simulation simulation = getSimulationById(simulationId);

        simulation.setUpdateDate(new Date());
        oldSimulationService.storeSimulationAsOld(simulation);

        City city = simulation.getCity();
        city.changeBlockTypes(xCoordinates, yCoordinates, newBlockType);
        return new SimulationDTO(this.storeSimulation(simulation));
    }

    public Block blockGetterFromSimulation(FindBlockDTO dto) {
        Optional<Simulation> simulation = simulationRepository.findById(dto.simulationId());
        if (simulation.isPresent()) {
            City city = simulation.get().getCity();
            return City.findBlockByCoordinate(city, dto.x(), dto.y());
        }
        return null;
    }


    /**
     * Get simulation from db by its id
     *
     * @param simulationId the id of simulation
     * @return The object of simulation
     */
    public Simulation getSimulationById(String simulationId) {
        return simulationRepository.findById(simulationId).orElseThrow(null);
    }

    public long countSimulationByEmail(String authorEmail) {
        return simulationRepository.countByAuthorEmail(authorEmail);
    }

    /**
     * Returns the list of existing sims.
     *
     * @return a list of existing sims.
     */
    public List<Simulation> getAll() {
        return this.simulationRepository.findAll();
    }


    /**
     * Makes the simulation with the given id public.
     *
     * @param simulationId a simulation id.
     * @return a link to the simulation.
     * @throws IllegalArgumentException if a simulation is modified by the user who does not own the simulation.
     * @spec.requires <code>simulationId != null</code>
     * @spec.modifies the persisted simulation.
     */
    public SimulationLinkDTO makePublic(String simulationId) {
        Simulation simulation = this.getSimulationById(simulationId);
        simulation.makePublic();
        this.storeSimulation(simulation);
        return new SimulationLinkDTO(simulation);
    }

    /**
     * Makes the simulation with the given id private
     *
     *
     * @param simulationId a simulation id
     * @return a link to the simulation
     * @throws IllegalArgumentException if a simulation is modified by the user who does not own the simulation.
     * @spec.requires <code>simulationId != null</code>
     * @spec.modifies the persisted simulation.
     */
    public SimulationLinkDTO makePrivate(String simulationId) {
        Simulation simulation = this.getSimulationById(simulationId);
        simulation.makePrivate();
        this.storeSimulation(simulation);
        return new SimulationLinkDTO(simulation);
    }

    /**
     * Gets the list of simulations from a certain user
     * @param email the user's email
     * @param sort
     * @param limit
     * @param offset
     * @return all the simulations created by the user, found through his email
     * @spec.requires <code>email != ""</code>
     */
    public List<SimulationDTO> getUsersSimulations(String email, Sort sort, int limit, int offset){
        Pageable pageable = PageRequest.of(offset / limit, limit, sort);
        return simulationRepository.findUsersSimulations(email, pageable).stream().map(SimulationDTO::new).toList();
    }

    /**
     * Returns the email of the simulation's author
     * @param simulationId the id of the simulation
     * @return the email of the creator of the simulation
     * @spec.requires <code>simulationId != null</code>
     */
    public String getAuthorEmail(String simulationId){
        var simulation = simulationRepository.findById(simulationId);
        return simulation.map(Simulation::getAuthorEmail).orElse(null);
    }

    /**
     * Deletes all simulations from the database.
     */
    public void cleanAllSimulations() {
        simulationRepository.deleteAll();
    }

}
