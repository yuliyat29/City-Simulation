package ch.usi.inf.bsc.sa4.lab02spring.model;

/**
 * A ParkBlock represents a block that is designated as a park.
 * It extends the Block class.
 */
public class ParkBlock extends Block {

  /**
   * Constructs a park block
   *
   * @param x the x coordinate of the block
   * @param y the y coordinate of the block
   * @param type the type of the block
   */
  public ParkBlock(int x, int y, BTypes type) {
    super(x, y, type);
  }

}
